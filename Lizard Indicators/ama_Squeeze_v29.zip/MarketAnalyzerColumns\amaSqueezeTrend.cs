#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.LizardIndicators
{
	[Gui.CategoryOrder("Algorithmic Options", 0)]
	[Gui.CategoryOrder("Input Parameters", 10)]
	[Gui.CategoryOrder("Bollinger Squeeze", 20)]
	[Gui.CategoryOrder("Trend Filter", 30)]
	[Gui.CategoryOrder("Trade Signals", 40)]
	[Gui.CategoryOrder("Data Series", 50)]
	[Gui.CategoryOrder("Set up", 60)]
	[Gui.CategoryOrder("Time frame", 70)]
	[Gui.CategoryOrder("Visual", 80)]
	[Gui.CategoryOrder("Conditions", 90)]
	public class amaSqueezeTrend : MarketAnalyzerColumn
	{
		private NinjaTrader.NinjaScript.Indicators.LizardIndicators.amaSqueeze amaSQ;
		
		private int 				volaPeriod					= 20;
		private int					squeezePeriod				= 120;
		private int					minSqueezeBars				= 3;
		private int					maxTriggerBars				= 6;
		private int					fastMomentumPeriod			= 10;
		private int					slowMomentumPeriod			= 25;
		private	double 				stdDevMultiplier			= 2.0;
		private	double 				offsetMultiplier			= 1.5;
		private double				minSqueezeStrength			= 1.2;
		private amaSqueezeType		squeezeType					= amaSqueezeType.Full_Squeeze;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description										= @"";
				Name											= "amaSqueeze_Trend";
				Calculate										= Calculate.OnPriceChange;
				DataType   										= typeof(double);
        		IsEditable 										= false;
				BarsRequiredToPlot								= Math.Max(squeezePeriod + volaPeriod, slowMomentumPeriod);
				FormatDecimals 									= 0;
			}
			else if (State == State.DataLoaded)
			{
				amaSQ		= 	amaSqueeze(squeezeType, volaPeriod, stdDevMultiplier, offsetMultiplier, squeezePeriod, minSqueezeStrength, fastMomentumPeriod, slowMomentumPeriod, minSqueezeBars, maxTriggerBars);
			}
		}
		
		protected override void OnBarUpdate()
		{
		  	CurrentValue = amaSQ.Trend[0];
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Squeeze type", Description = "Select between three different squeeze algorithms", GroupName = "Algorithmic Options", Order = 0)]
		public amaSqueezeType SqueezeType
		{	
            get { return squeezeType; }
            set { squeezeType = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Lookback period", Description = "Sets the lookback period for Bollinger bands and Keltner channel", GroupName = "Input Parameters", Order = 0)]
		public int VolaPeriod
		{	
            get { return volaPeriod; }
            set { volaPeriod = value; }
		}
		
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Std. dev. multiplier", Description = "Select standard deviation multiplier for Bollinger Bands", GroupName = "Input Parameters", Order = 1)]
		public double StdDevMultiplier
		{	
            get { return stdDevMultiplier; }
            set { stdDevMultiplier = value; }
		}
		
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ATR multiplier", Description = "Select offset multiplier for Keltner Channel", GroupName = "Input Parameters", Order = 2)]
		public double OffsetMultiplier
		{	
            get { return offsetMultiplier; }
            set { offsetMultiplier = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Normalization period", Description = "Select lookback period for detecting the Bollinger squeeze", GroupName = "Bollinger Squeeze", Order = 0)]
		public int SqueezePeriod
		{	
            get { return squeezePeriod; }
            set { squeezePeriod = value; }
		}
			
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Squeeze strength", Description = "Sets the required strength for the Bollinger squeeze", GroupName = "Bollinger Squeeze", Order = 1)]
		public double MinSqueezeStrength
		{	
            get { return minSqueezeStrength; }
            set { minSqueezeStrength = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast momentum period", Description = "Sets the lookback period for the fast balanced momentum", GroupName = "Trend Filter", Order = 0)]
		public int FastMomentumPeriod
		{	
            get { return fastMomentumPeriod; }
            set { fastMomentumPeriod = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow momentum period", Description = "Sets the lookback period for the slow balanced momentum", GroupName = "Trend Filter", Order = 1)]
		public int SlowMomentumPeriod
		{	
            get { return slowMomentumPeriod; }
            set { slowMomentumPeriod = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Minimum squeeze bars", Description = "Sets the minimum number of squeeze bars necessary for generating a trade signal", GroupName = "Trade Signals", Order = 0)]
		public int MinSqueezeBars
		{	
            get { return minSqueezeBars; }
            set { minSqueezeBars = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Maximum trigger bars", Description = "Sets the maximum number of possible trigger bars after a squeeze ", GroupName = "Trade Signals", Order = 1)]
		public int MaxTriggerBars
		{	
            get { return maxTriggerBars; }
            set { maxTriggerBars = value; }
		}
		#endregion
	}
}
