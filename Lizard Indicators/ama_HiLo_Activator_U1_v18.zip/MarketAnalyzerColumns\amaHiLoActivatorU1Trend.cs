#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.LizardIndicators
{
	[Gui.CategoryOrder("Algorithmic Options", 1000100)]
	[Gui.CategoryOrder("Input Parameters", 1000200)]
	public class amaHiLoActivatorU1Trend : MarketAnalyzerColumn
	{
		private NinjaTrader.NinjaScript.Indicators.LizardIndicators.amaHiLoActivatorU1 amaHLAU1;
		
		private int 						basePeriod			= 50; 
		private bool						reverseIntraBar		= false;
		private amaHiLoActivatorU1BaseType 	thisBaseType		= amaHiLoActivatorU1BaseType.SMA; 

		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description										= @"";
				Name											= "amaHiLoActivatorU1_Trend";
				Calculate										= Calculate.OnPriceChange;
				DataType   										= typeof(double);
        		IsEditable 										= false;
				BarsRequiredToPlot 								= basePeriod;
				FormatDecimals 									= 0;
			}
			else if (State == State.DataLoaded)
			{
				amaHLAU1		= amaHiLoActivatorU1(thisBaseType, reverseIntraBar, basePeriod);
			}
		}
		
		protected override void OnBarUpdate()
		{
		  	CurrentValue = amaHLAU1.Trend[0];
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Baseline smoothing", Description = "Select moving average type or moving median type for the base line", GroupName = "Algorithmic Options", Order = 0)]
		public amaHiLoActivatorU1BaseType ThisBaseType
		{	
            get { return thisBaseType; }
            set { thisBaseType = value; }
		}
			
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Reverse intra-bar", Description = "Select between trend change intra-bar or at the bar close", GroupName = "Algorithmic Options", Order = 1)]
        public bool ReverseIntraBar
        {
            get { return reverseIntraBar; }
            set { reverseIntraBar = value; }
        }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Baseline period", Description = "Sets the lookback period for the baseline", GroupName = "Input Parameters", Order = 0)]
		public int BasePeriod
		{	
            get { return basePeriod; }
            set { basePeriod = value; }
		}
		#endregion
	}
}
