//+----------------------------------------------------------------------------------------------+
//| Copyright © <2021>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators.LizardIndicators;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The original wave consists of three exponential moving averages: an average of the bar highs, the bar lows and the bar midpoints. This indicator comes with several enhancements: The moving average
	///	The moving average can be selected from over 30 different algorithms. Furthermore the indicator allows for adjusting the width of the wave. The wave is colored according to the current trend. 
	///	An uptrend is detected when a price bar closes above the wave. a downtrend is detected when a price bar closes below the wave. Any bar closing inside the wave represents a neutral trend. 
	///	The trend information is exposed through a public data series and can be directly accessed via automated strategies or a market analyzer column. 		
	/// </summary>
	[Gui.CategoryOrder("Algorithmic Options", 1000100)]
	[Gui.CategoryOrder("Input Parameters", 1000200)]
	[Gui.CategoryOrder("Display Options", 1000300)]
	[Gui.CategoryOrder("Wave Shading", 8000100)]
	[Gui.CategoryOrder("Paint Bars", 8000200)]
	[Gui.CategoryOrder("Sound Alerts", 8000300)]
	[Gui.CategoryOrder("Version", 8000400)]
	public class amaMultiMAWave : Indicator
	{
		private int 								basePeriod					= 34; 
		private int									displacement				= 0;
		private int									totalBarsRequiredToPlot		= 0;
		private int									shift						= 0;
		private bool 								showMidband 				= true;
		private bool 								showChannel 				= true;
		private bool								waveFlooding				= true;
		private bool 								showPaintBars 				= true;
		private bool								soundAlerts					= false;
		private bool								waveIsFlooded				= false;
		private bool								calculateFromPriceData		= true;
		private bool								indicatorIsOnPricePanel		= true;
		private double								multiplier					= 1.0;
		private double								highBase					= 0.0;
		private double								lowBase						= 0.0;
		private double								midband						= 0.0;
		private double								bandwidth					= 0.0;
		private amaMultiMAWaveBaseType 				thisBaseType				= amaMultiMAWaveBaseType.EMA; 
		private SessionIterator						sessionIterator				= null;
		private int 								plot0Width 					= 1;
		private PlotStyle 							plot0Style					= PlotStyle.Line;
		private DashStyleHelper						dash0Style					= DashStyleHelper.Solid;
		private int 								plot1Width 					= 1;
		private PlotStyle 							plot1Style					= PlotStyle.Line;
		private DashStyleHelper						dash1Style					= DashStyleHelper.Solid;
		private int 								plot2Width 					= 1;
		private PlotStyle 							plot2Style					= PlotStyle.Line;
		private DashStyleHelper						dash2Style					= DashStyleHelper.Solid;
		private System.Windows.Media.Brush			upBrush						= Brushes.Navy;
		private System.Windows.Media.Brush			downBrush					= Brushes.Firebrick;
		private System.Windows.Media.Brush			neutralBrush				= Brushes.Goldenrod;
		private System.Windows.Media.Brush			waveBrushS					= Brushes.LightGray;
		private System.Windows.Media.Brush			waveBrush					= Brushes.Transparent;
		private System.Windows.Media.Brush			upBrushUp					= Brushes.Navy;
		private System.Windows.Media.Brush			upBrushDown					= Brushes.LightSkyBlue;
		private System.Windows.Media.Brush			downBrushUp					= Brushes.Firebrick;
		private System.Windows.Media.Brush			downBrushDown				= Brushes.Red;
		private System.Windows.Media.Brush			neutralBrushUp				= Brushes.Goldenrod;
		private System.Windows.Media.Brush			neutralBrushDown			= Brushes.Gold;
		private System.Windows.Media.Brush			upBrushOutline				= Brushes.Black;
		private System.Windows.Media.Brush			downBrushOutline			= Brushes.Black;
		private System.Windows.Media.Brush			neutralBrushOutline			= Brushes.Black;
		private System.Windows.Media.Brush			transparentBrush			= Brushes.Transparent;
		private SharpDX.Direct2D1.Brush 			waveBrushDX		 			= null;
		private System.Windows.Media.Brush			alertBackBrush				= Brushes.Black;
		private System.Windows.Media.Brush			errorBrush					= Brushes.Black;
		private SimpleFont							errorFont					= null;
		private string								errorText1					= "The amaMultiMAWave only works on price data.";
		private string								errorText2					= "The amaMultiMAWave cannot be used with a negative displacement.";
		private int									waveOpacity					= 40;
		private int									rearmTime					= 30;
		private string 								newUptrend					= "newuptrend.wav";
		private string 								newDowntrend				= "newdowntrend.wav";
		private string 								newNeutraltrend				= "newneutraltrend.wav";
		private string								pathNewUptrend				= "";
		private string								pathNewDowntrend			= "";
		private string								pathNewNeutraltrend			= "";
		private string								versionString				= "v 1.4  -  February 26, 2021";
		private Series<double>						trend;
		private Series<System.Windows.Media.Brush>	trendBrush;
		private ISeries<double>						highAverage;
		private ISeries<double>						lowAverage;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\nThe original wave consists of three exponential moving averages: an average of the bar highs, the bar lows and the bar midpoints. This indicator comes"
											  + " with several enhancements: The moving average can be selected from over 30 different algorithms. Furthermore the indicator allows for adjusting the width"
											  + " of the wave. The wave is colored according to the current trend. An uptrend is detected when a price bar closes above the wave. A downtrend is detected"
											  + " when a price bar closes below the wave. Any bar closing inside the wave represents a neutral trend. The trend information is exposed through a public"
											  + " data series and can be directly accessed via automated strategies or a market analyzer column."; 				
					
				Name						= "amaMultiMAWave";
				Calculate					= Calculate.OnPriceChange;
				IsSuspendedWhileInactive	= false;
				IsOverlay					= true;
				ArePlotsConfigurable		= false;
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "Upper Band");	
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "Midband");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "Lower Band");
				SetZOrder(-2);
			}
			else if (State == State.Configure)
			{
				if(Calculate == Calculate.OnPriceChange)
					switch(thisBaseType)
					{
						case amaMultiMAWaveBaseType.VWMA: 
							Calculate = Calculate.OnEachTick;
							break;
						default:
							break;
					}	
				displacement = Displacement;
				BarsRequiredToPlot = 3*basePeriod;
				totalBarsRequiredToPlot = BarsRequiredToPlot + displacement;
	
				Plots[0].PlotStyle = plot0Style;
				Plots[0].Width = plot0Width;
				Plots[0].DashStyleHelper = dash0Style;	
				Plots[1].PlotStyle = plot1Style;
				Plots[1].Width = plot1Width;
				Plots[1].DashStyleHelper = dash1Style;	
				Plots[2].PlotStyle = plot2Style;
				Plots[2].Width = plot2Width;
				Plots[2].DashStyleHelper = dash2Style;	
				waveBrush = waveBrushS.Clone();
				waveBrush.Opacity = (float) waveOpacity/100.0;
				waveBrush.Freeze();
			}
			else if (State == State.DataLoaded)
			{
				trend = new Series<double>(this, MaximumBarsLookBack.Infinite);
				trendBrush = new Series<System.Windows.Media.Brush>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				if(Input is PriceSeries)
					calculateFromPriceData = true;
				else
					calculateFromPriceData = false;
				switch (thisBaseType)
				{
					case amaMultiMAWaveBaseType.Adaptive_Laguerre: 
						highAverage = amaAdaptiveLaguerreFilter(Highs[0], basePeriod);
						lowAverage = amaAdaptiveLaguerreFilter(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.ADXVMA: 
						highAverage = amaADXVMA(Highs[0], basePeriod);
						lowAverage = amaADXVMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.Butterworth_2: 
						highAverage = amaButterworthFilter(Highs[0], 2, basePeriod);
						lowAverage = amaButterworthFilter(Lows[0], 2, basePeriod);
						break;
					case amaMultiMAWaveBaseType.Butterworth_3: 
						highAverage = amaButterworthFilter(Highs[0], 3, basePeriod);
						lowAverage = amaButterworthFilter(Lows[0], 3, basePeriod);
						break;
					case amaMultiMAWaveBaseType.DEMA: 
						highAverage = DEMA(Highs[0], basePeriod);
						lowAverage = DEMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.Distant_Coefficient_Filter: 
						highAverage = amaDistantCoefficientFilter(Highs[0], basePeriod);
						lowAverage = amaDistantCoefficientFilter(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.DWMA: 
						highAverage = amaDWMA(Highs[0], basePeriod);
						lowAverage = amaDWMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.EHMA: 
						highAverage = amaEHMA(Highs[0], basePeriod);
						lowAverage = amaEHMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.EMA: 
						highAverage = EMA(Highs[0], basePeriod);
						lowAverage = EMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.Gauss_2: 
						highAverage = amaGaussianFilter(Highs[0], 2, basePeriod);
						lowAverage = amaGaussianFilter(Lows[0], 2, basePeriod);
						break;
					case amaMultiMAWaveBaseType.Gauss_3: 
						highAverage = amaGaussianFilter(Highs[0], 3, basePeriod);
						lowAverage = amaGaussianFilter(Lows[0], 3, basePeriod);
						break;
					case amaMultiMAWaveBaseType.Gauss_4: 
						highAverage = amaGaussianFilter(Highs[0], 4, basePeriod);
						lowAverage = amaGaussianFilter(Lows[0], 4, basePeriod);
						break;
					case amaMultiMAWaveBaseType.HMA:
						if(basePeriod > 1)
						{	
							highAverage = HMA(Highs[0], basePeriod);
							lowAverage = HMA(Lows[0], basePeriod);
						}	
						else
						{	
							highAverage = Highs[0];
							lowAverage = Lows[0];
						}	
						break;
					case amaMultiMAWaveBaseType.HoltEMA: 
						highAverage = amaHoltEMA(Highs[0], basePeriod, basePeriod);
						lowAverage = amaHoltEMA(Lows[0], basePeriod, basePeriod);
						break;
					case amaMultiMAWaveBaseType.Laguerre: 
						highAverage = amaLaguerreFilter(Highs[0], basePeriod);
						lowAverage = amaLaguerreFilter(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.LinReg:
						if(basePeriod > 1)
						{	
							highAverage = LinReg(Highs[0], basePeriod);
							lowAverage= LinReg(Lows[0], basePeriod);
						}	
						else
						{	
							highAverage = Highs[0];
							lowAverage = Lows[0];
						}	
						break;
					case amaMultiMAWaveBaseType.Median: 
						highAverage = amaMovingMedian(Highs[0], basePeriod);
						lowAverage = amaMovingMedian(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.RWMA: 
						highAverage = amaRWMA(Highs[0], basePeriod);
						lowAverage =  amaRWMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.SMA: 
						highAverage = SMA(Highs[0], basePeriod);
						lowAverage = SMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.SuperSmoother_2: 
						highAverage = amaSuperSmoother(Highs[0], 2, basePeriod);
						lowAverage = amaSuperSmoother(Lows[0], 2, basePeriod);
						break;
					case amaMultiMAWaveBaseType.SuperSmoother_3: 
						highAverage = amaSuperSmoother(Highs[0], 3, basePeriod);
						lowAverage = amaSuperSmoother(Lows[0], 3, basePeriod);
						break;
					case amaMultiMAWaveBaseType.SWMA: 
						highAverage = amaSWMA(Highs[0], basePeriod);
						lowAverage = amaSWMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.TEMA: 
						highAverage = TEMA(Highs[0], basePeriod);
						lowAverage = TEMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.Tillson_T3: 
						highAverage = amaTillsonT3(Highs[0], amaT3CalcMode.Tillson, basePeriod, 0.7);
						lowAverage = amaTillsonT3(Lows[0], amaT3CalcMode.Tillson, basePeriod, 0.7);
						break;
					case amaMultiMAWaveBaseType.TMA: 
						highAverage = TMA(Highs[0], basePeriod);
						lowAverage = TMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.TWMA: 
						highAverage = amaTWMA(Highs[0], basePeriod);
						lowAverage = amaTWMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.VWMA: 
						highAverage = VWMA(Highs[0], basePeriod);
						lowAverage = VWMA(Lows[0], basePeriod);
						break;
					case amaMultiMAWaveBaseType.Wilder: 
						highAverage = EMA(Highs[0], 2*basePeriod-1);
						lowAverage = EMA(Lows[0], 2*basePeriod-1);
						break;
					case amaMultiMAWaveBaseType.WMA: 
						highAverage = WMA(Highs[0], basePeriod);
						lowAverage = WMA(Lows[0], basePeriod);
						break;
				}						
		    	sessionIterator = new SessionIterator(Bars);
			}
			else if (State == State.Historical)
			{
				waveIsFlooded = waveFlooding && waveOpacity > 0;
				waveBrush = waveBrushS.Clone();
				waveBrush.Opacity = (float) waveOpacity/100.0;
				waveBrush.Freeze();
				if(ChartBars != null)
				{	
					errorBrush = ChartControl.Properties.AxisPen.Brush;
					errorBrush.Freeze();
					errorFont = new SimpleFont("Arial", 24);
					indicatorIsOnPricePanel = (ChartPanel.PanelIndex == ChartBars.Panel);
				}	
				else
					indicatorIsOnPricePanel = false;
				pathNewUptrend = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, newUptrend);
				pathNewDowntrend = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, newDowntrend);
				pathNewNeutraltrend = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, newNeutraltrend);
			}	
		}

		protected override void OnBarUpdate()
        {
			if(!calculateFromPriceData)
			{
				DrawOnPricePanel = false;
				Draw.TextFixed(this, "error text 1", errorText1, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
				return;
			}
			if(displacement < 0)
			{
				DrawOnPricePanel = false;
				Draw.TextFixed(this, "error text 3", errorText2, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
				return;
			}
			
			highBase = highAverage[0];
			lowBase = lowAverage[0];
			midband = 0.5 * (highBase + lowBase);
			bandwidth = 0.5 * multiplier * (highBase - lowBase);
			UpperBand[0] = midband + bandwidth;;
			Midband[0] = midband;
			LowerBand[0] = midband - bandwidth;
			
			if(CurrentBar < basePeriod)
			{
				trend.Reset();
				return;
			}
			
			if(Close[0] > UpperBand[0])
			{	
				trend[0] = 1.0;
				trendBrush[0] = upBrush;
			}	
			else if (Close[0] < LowerBand[0])
			{
				trend[0] = -1.0;
				trendBrush[0] = downBrush;
			}
			else
			{
				trend[0] = 0.0;
				trendBrush[0] = neutralBrush;
			}
			if(showMidband)
				PlotBrushes[1][0] = trendBrush[0];
			else
				PlotBrushes[1][0] = transparentBrush;
			
			if(showChannel)
			{
				PlotBrushes[0][0] = trendBrush[0];
				PlotBrushes[2][0] = trendBrush[0];
			}
			else 
			{
				PlotBrushes[0][0] = transparentBrush;
				PlotBrushes[2][0] = transparentBrush;
			}
			
			if(showPaintBars && CurrentBar >= totalBarsRequiredToPlot)
			{
				if(displacement >= 0)
				{
					if(trend[displacement] > 0.5)
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = upBrushUp;
						else
							BarBrushes[0] = upBrushDown;
						CandleOutlineBrushes[0] = upBrushOutline;
					}	
					else if(trend[displacement] < -0.5)
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = downBrushUp;
						else
							BarBrushes[0] = downBrushDown;
						CandleOutlineBrushes[0] = downBrushOutline;
					}	
					else
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = neutralBrushUp;
						else
							BarBrushes[0] = neutralBrushDown;
						CandleOutlineBrushes[0] = neutralBrushOutline;
					}	
				}
				else 
				{
					if(trend[0] > 0.5)
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = upBrushUp;
						else
							BarBrushes[-displacement] = upBrushDown;
						CandleOutlineBrushes[-displacement] = upBrushOutline;
					}	
					else if(trend[0] < -0.5)
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = downBrushUp;
						else
							BarBrushes[-displacement] = downBrushDown;
						CandleOutlineBrushes[-displacement] = downBrushOutline;
					}	
					else
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = neutralBrushUp;
						else
							BarBrushes[-displacement] = neutralBrushDown;
						CandleOutlineBrushes[-displacement] = neutralBrushOutline;
					}
				}
			}	
			
			if (soundAlerts && State == State.Realtime && IsConnected())
			{
				if(trend[0] > 0.5 && trend[1] < 0.5)		
				{
					try
					{
							Alert("New_Uptrend", Priority.Medium,"New Uptrend", pathNewUptrend, rearmTime, alertBackBrush, upBrush);
					}
					catch{}
				}
				else if(trend[0] < -0.5 && trend[1] > -0.5)		
				{
					try
					{
							Alert("New_Downtrend", Priority.Medium,"New Downtrend", pathNewDowntrend, rearmTime, alertBackBrush, downBrush);
					}
					catch{}
				}
				else if (trend[0] > -0.5 && trend[0] < 0.5 && (trend[1] > 0.5 || trend[1] < -0.5))
				{
					try
					{
							Alert("New_Neutraltrend", Priority.Medium,"New Neutral Trend", pathNewNeutraltrend, rearmTime, alertBackBrush, neutralBrush);
					}
					catch{}
				}
 			}				
		}

		#region Properties
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> UpperBand
		{
			get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Midband
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> LowerBand
		{
			get { return Values[2]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Trend
		{
			get { return trend; }
		}
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Moving Average", Description = "Select moving average type or moving median type for the base line", GroupName = "Algorithmic Options", Order = 0)]
		public amaMultiMAWaveBaseType ThisBaseType
		{	
            get { return thisBaseType; }
            set { thisBaseType = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "MA period", Description = "Sets the lookback period for the moving average", GroupName = "Input Parameters", Order = 0)]
		public int BasePeriod
		{	
            get { return basePeriod; }
            set { basePeriod = value; }
		}
			
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Wave size", Description = "Select multiplier for adjusting size (thickness) of wave", GroupName = "Input Parameters", Order = 1)]
        public double Multiplier
        {
            get { return multiplier; }
            set { multiplier = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show midband", Description = "Displays the midband of the wave on the chart", GroupName = "Display Options", Order = 0)]
        public bool ShowMidband
        {
            get { return showMidband; }
            set { showMidband = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show channel lines", Description = "Displays the channel lines on the chart", GroupName = "Display Options", Order = 1)]
        public bool ShowChannel
        {
            get { return showChannel; }
            set { showChannel = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Wave flooding", Description = "Activates channel flooding", GroupName = "Display Options", Order = 2)]
        public bool WaveFlooding
        {
            get { return waveFlooding; }
            set { waveFlooding = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show paint bars", GroupName = "Display Options", Order = 3)]
        public bool ShowPaintBars
        {
            get { return showPaintBars; }
            set { showPaintBars = value; }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish trend", Description = "Sets the color for a bullish trend", GroupName = "Plots", Order = 0)]
		public System.Windows.Media.Brush UpBrush
		{ 
			get {return upBrush;}
			set {upBrush = value;}
		}

		[Browsable(false)]
		public string UpBrushSerializable
		{
			get { return Serialize.BrushToString(upBrush); }
			set { upBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish trend", Description = "Sets the color for a bearish trend", GroupName = "Plots", Order = 1)]
		public System.Windows.Media.Brush DownBrush
		{ 
			get {return downBrush;}
			set {downBrush = value;}
		}

		[Browsable(false)]
		public string DownBrushSerializable
		{
			get { return Serialize.BrushToString(downBrush); }
			set { downBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Neutral trend", Description = "Sets the color for a neutral trend", GroupName = "Plots", Order = 2)]
		public System.Windows.Media.Brush NeutralBrush
		{ 
			get {return neutralBrush;}
			set {neutralBrush = value;}
		}

		[Browsable(false)]
		public string NeutralBrushSerializable
		{
			get { return Serialize.BrushToString(neutralBrush); }
			set { neutralBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot style high average", Description = "Sets the plot style for the high average plot", GroupName = "Plots", Order = 3)]
		public PlotStyle Plot0Style
		{	
            get { return plot0Style; }
            set { plot0Style = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style high average", Description = "Sets the dash style for the high average plot", GroupName = "Plots", Order = 4)]
		public DashStyleHelper Dash0Style
		{
			get { return dash0Style; }
			set { dash0Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width high average", Description = "Sets the plot width for the high average plot", GroupName = "Plots", Order = 5)]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
			
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot style midband", Description = "Sets the plot style for the midband plot", GroupName = "Plots", Order = 3)]
		public PlotStyle Plot1Style
		{	
            get { return plot1Style; }
            set { plot1Style = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style midband", Description = "Sets the dash style for the midband plot", GroupName = "Plots", Order = 4)]
		public DashStyleHelper Dash1Style
		{
			get { return dash1Style; }
			set { dash1Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width midband", Description = "Sets the plot width for the midband plot", GroupName = "Plots", Order = 5)]
		public int Plot1Width
		{	
            get { return plot1Width; }
            set { plot1Width = value; }
		}
			
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot style low average", Description = "Sets the plot style for the low average plot", GroupName = "Plots", Order = 3)]
		public PlotStyle Plot2Style
		{	
            get { return plot2Style; }
            set { plot2Style = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style low average", Description = "Sets the dash style for the low average plot", GroupName = "Plots", Order = 4)]
		public DashStyleHelper Dash2Style
		{
			get { return dash2Style; }
			set { dash2Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width low average", Description = "Sets the plot width for the low average plot", GroupName = "Plots", Order = 5)]
		public int Plot2Width
		{	
            get { return plot2Width; }
            set { plot2Width = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Color for shading", Description = "Sets the color for the wave", GroupName = "Wave Shading", Order = 0)]
		public System.Windows.Media.Brush WaveBrushS
		{ 
			get {return waveBrushS;}
			set {waveBrushS = value;}
		}

		[Browsable(false)]
		public string WaveBrushSSerializable
		{
			get { return Serialize.BrushToString(waveBrushS); }
			set { waveBrushS = Serialize.StringToBrush(value); }
		}
		
		[Range(0, 100)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Opacity for shading", Description = "Select opacity between 0 (transparent) and 100 (no opacity)", GroupName = "Wave Shading", Order = 1)]
        public int WaveOpacity
        {
            get { return waveOpacity; }
            set { waveOpacity = value; }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish upclose", Description = "Sets the color for a bullish trend", GroupName = "Paint Bars", Order = 0)]
		public System.Windows.Media.Brush UpBrushUp
		{ 
			get {return upBrushUp;}
			set {upBrushUp = value;}
		}

		[Browsable(false)]
		public string UpBrushUpSerializable
		{
			get { return Serialize.BrushToString(upBrushUp); }
			set { upBrushUp = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish downclose", Description = "Sets the color for a bullish trend", GroupName = "Paint Bars", Order = 1)]
		public System.Windows.Media.Brush UpBrushDown
		{ 
			get {return upBrushDown;}
			set {upBrushDown = value;}
		}

		[Browsable(false)]
		public string UpBrushDownSerializable
		{
			get { return Serialize.BrushToString(upBrushDown); }
			set { upBrushDown = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish candle outline", Description = "Sets the color for candle outlines", GroupName = "Paint Bars", Order = 2)]
		public System.Windows.Media.Brush UpBrushOutline
		{ 
			get {return upBrushOutline;}
			set {upBrushOutline = value;}
		}

		[Browsable(false)]
		public string UpBrushOutlineSerializable
		{
			get { return Serialize.BrushToString(upBrushOutline); }
			set { upBrushOutline = Serialize.StringToBrush(value); }
		}					
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish upclose", Description = "Sets the color for a bearish trend", GroupName = "Paint Bars", Order = 3)]
		public System.Windows.Media.Brush DownBrushUp
		{ 
			get {return downBrushUp;}
			set {downBrushUp = value;}
		}

		[Browsable(false)]
		public string DownBrushUpSerializable
		{
			get { return Serialize.BrushToString(downBrushUp); }
			set { downBrushUp = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish downclose", Description = "Sets the color for a bearish trend", GroupName = "Paint Bars", Order = 4)]
		public System.Windows.Media.Brush DownBrushDown
		{ 
			get {return downBrushDown;}
			set {downBrushDown = value;}
		}

		[Browsable(false)]
		public string DownBrushDownSerializable
		{
			get { return Serialize.BrushToString(downBrushDown); }
			set { downBrushDown = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish candle outline", Description = "Sets the color for candle outlines", GroupName = "Paint Bars", Order = 5)]
		public System.Windows.Media.Brush DownBrushOutline
		{ 
			get {return downBrushOutline;}
			set {downBrushOutline = value;}
		}

		[Browsable(false)]
		public string DownBrushOutlineSerializable
		{
			get { return Serialize.BrushToString(downBrushOutline); }
			set { downBrushOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Neutral upclose", Description = "Sets the color for a neutral trend", GroupName = "Paint Bars", Order = 6)]
		public System.Windows.Media.Brush NeutralBrushUp
		{ 
			get {return neutralBrushUp;}
			set {neutralBrushUp = value;}
		}

		[Browsable(false)]
		public string NeutralBrushUpSerializable
		{
			get { return Serialize.BrushToString(neutralBrushUp); }
			set { neutralBrushUp = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Neutral downclose", Description = "Sets the color for a neutral trend", GroupName = "Paint Bars", Order = 7)]
		public System.Windows.Media.Brush NeutralBrushDown
		{ 
			get {return neutralBrushDown;}
			set {neutralBrushDown = value;}
		}

		[Browsable(false)]
		public string NeutralBrushDownSerializable
		{
			get { return Serialize.BrushToString(neutralBrushDown); }
			set { neutralBrushDown = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Neutral candle outline", Description = "Sets the color for candle outlines", GroupName = "Paint Bars", Order = 8)]
		public System.Windows.Media.Brush NeutralBrushOutline
		{ 
			get {return neutralBrushOutline;}
			set {neutralBrushOutline = value;}
		}

		[Browsable(false)]
		public string NeutralBrushOutlineSerializable
		{
			get { return Serialize.BrushToString(neutralBrushOutline); }
			set { neutralBrushOutline = Serialize.StringToBrush(value); }
		}

		[Display(ResourceType = typeof(Custom.Resource), Name = "Sound alerts", GroupName = "Sound Alerts", Order = 0)]
        public bool SoundAlerts
        {
            get { return soundAlerts; }
            set { soundAlerts = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "New uptrend", Description = "Sound file for new uptrend", GroupName = "Sound Alerts", Order = 1)]
		public string NewUptrend
		{	
            get { return newUptrend; }
            set { newUptrend = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "New downtrend", Description = "Sound file for new downtrend", GroupName = "Sound Alerts", Order = 2)]
		public string NewDowntrend
		{	
            get { return newDowntrend; }
            set { newDowntrend = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "New neutral trend", Description = "Sound file for new neutral trend", GroupName = "Sound Alerts", Order = 3)]
		public string NewNeutraltrend
		{	
            get { return newNeutraltrend; }
            set { newNeutraltrend = value; }
		}		
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rearm time", Description = "Rearm time for alerts in seconds", GroupName = "Sound Alerts", Order = 4)]
		public int RearmTime
		{	
            get { return rearmTime; }
            set { rearmTime = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
		
		#region Miscellaneous

		public override string FormatPriceMarker(double price)
		{
			if(indicatorIsOnPricePanel)
				return Instrument.MasterInstrument.FormatPrice(Instrument.MasterInstrument.RoundToTickSize(price));
			else
				return base.FormatPriceMarker(price);
		}
		
		private bool IsConnected()
        {
			if ( Bars != null && Bars.Instrument.GetMarketDataConnection().PriceStatus == NinjaTrader.Cbi.ConnectionStatus.Connected
					&& sessionIterator.IsInSession(Now, true, true))
				return true;
			else
            	return false;
        }
		
		private DateTime Now
		{
          get 
			{ 
				DateTime now = (Bars.Instrument.GetMarketDataConnection().Options.Provider == NinjaTrader.Cbi.Provider.Playback ? Bars.Instrument.GetMarketDataConnection().Now : DateTime.Now); 

				if (now.Millisecond > 0)
					now = NinjaTrader.Core.Globals.MinDate.AddSeconds((long) System.Math.Floor(now.Subtract(NinjaTrader.Core.Globals.MinDate).TotalSeconds));

				return now;
			}
		}
		
		public override void OnRenderTargetChanged()
		{
			if (waveBrushDX != null)
				waveBrushDX.Dispose();

			if (RenderTarget != null)
			{
				try
				{
					waveBrushDX = waveBrush.ToDxBrush(RenderTarget);
				}
				catch (Exception e) { }
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (ChartBars == null || BarsArray[0].Count < ChartBars.ToIndex || ChartBars.ToIndex < BarsRequiredToPlot || !IsVisible) return;
			int	lastBarPainted = ChartBars.ToIndex;
			if(lastBarPainted  < 0 || BarsArray[0].Count < lastBarPainted) return;

			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
	        ChartPanel panel = chartControl.ChartPanels[ChartPanel.PanelIndex];
			
			bool nonEquidistant 	= (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti);
			int lastBarCounted		= Input.Count - 1;
			int	lastBarOnUpdate		= lastBarCounted - (Calculate == Calculate.OnBarClose ? 1 : 0);
			int	lastBarIndex		= Math.Min(lastBarPainted, lastBarOnUpdate);
			int firstBarPainted	 	= ChartBars.FromIndex;
			int firstBarIndex  	 	= Math.Max(BarsRequiredToPlot, firstBarPainted);
			int lastIndex			= 0;
			int x 					= 0;
			int y1 					= 0;
			int y2 					= 0;
			int y 					= 0;
			int lastX 				= 0;
			int lastY0 				= 0;
			int lastY1 				= 0;
			int lastY 				= 0;
			int startBar 			= 0;
			int priorStartBar 		= 0;
			int returnBar 			= 0;
			int count	 			= 0;
			double barWidth			= 0;
			
			bool firstLoop 			= true;
			Vector2[] cloudArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			Vector2[] plotArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			
			if(lastBarIndex + displacement > firstBarIndex)
			{	
				if (displacement >= 0)
					lastIndex = lastBarIndex + displacement;
				else
					lastIndex = Math.Min(lastBarIndex, lastBarOnUpdate + displacement);
				if(nonEquidistant && lastIndex > lastBarOnUpdate)
					barWidth = Convert.ToDouble(ChartControl.GetXByBarIndex(ChartBars, lastBarPainted) - ChartControl.GetXByBarIndex(ChartBars, lastBarPainted - displacement))/displacement;
				lastY0	= chartScale.GetYByValue(UpperBand.GetValueAt(lastIndex - displacement));
				lastY1	= chartScale.GetYByValue(LowerBand.GetValueAt(lastIndex - displacement));
				
				//Background flooding for wave
				if(waveIsFlooded)
				{	
					lastY = lastY1;
					startBar = lastIndex;
					firstLoop = true;
					
					do
					{
						SharpDX.Direct2D1.PathGeometry 	path;
						SharpDX.Direct2D1.GeometrySink 	sink;
						path = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (path)
						{
							priorStartBar = startBar;
							if(firstLoop)
								count = -1;
							else
							{	
								count = 0;
								cloudArray[count] = new Vector2(lastX, lastY);
							}	
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(UpperBand.GetValueAt(idx - displacement));   
								count = count + 1;
								cloudArray[count] = new Vector2(x,y);
								returnBar = idx;
							}
							startBar = returnBar;
							for (int idx = returnBar ; idx <= priorStartBar; idx ++)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(LowerBand.GetValueAt(idx - displacement));   
								count = count + 1;
								cloudArray[count] = new Vector2(x,y);
							}
							sink = path.Open();
							sink.BeginFigure(cloudArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sink.AddLine(cloudArray[i]);
							sink.EndFigure(FigureEnd.Closed);
			        		sink.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
		 					RenderTarget.FillGeometry(path, waveBrushDX);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						path.Dispose();
						sink.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex);
				}
			}			
			base.OnRender(chartControl, chartScale);
		}				
		#endregion
	}
}

#region Global Enums

public enum amaMultiMAWaveBaseType 
{
	Adaptive_Laguerre, 
	ADXVMA, 
	Butterworth_2, 
	Butterworth_3, 
	DEMA, 
	Distant_Coefficient_Filter, 
	DWMA, 
	EHMA, 
	EMA, 
	Gauss_2, 
	Gauss_3, 
	Gauss_4, 
	HMA, 
	HoltEMA, 
	Laguerre, 
	LinReg,
	Median,
	RWMA, 
	SMA, 
	SuperSmoother_2, 
	SuperSmoother_3, 
	SWMA, 
	TEMA, 
	Tillson_T3, 
	TMA, 
	TWMA, 
	VWMA, 
	Wilder, 
	WMA, 
}

#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaMultiMAWave[] cacheamaMultiMAWave;
		public LizardIndicators.amaMultiMAWave amaMultiMAWave(amaMultiMAWaveBaseType thisBaseType, int basePeriod, double multiplier)
		{
			return amaMultiMAWave(Input, thisBaseType, basePeriod, multiplier);
		}

		public LizardIndicators.amaMultiMAWave amaMultiMAWave(ISeries<double> input, amaMultiMAWaveBaseType thisBaseType, int basePeriod, double multiplier)
		{
			if (cacheamaMultiMAWave != null)
				for (int idx = 0; idx < cacheamaMultiMAWave.Length; idx++)
					if (cacheamaMultiMAWave[idx] != null && cacheamaMultiMAWave[idx].ThisBaseType == thisBaseType && cacheamaMultiMAWave[idx].BasePeriod == basePeriod && cacheamaMultiMAWave[idx].Multiplier == multiplier && cacheamaMultiMAWave[idx].EqualsInput(input))
						return cacheamaMultiMAWave[idx];
			return CacheIndicator<LizardIndicators.amaMultiMAWave>(new LizardIndicators.amaMultiMAWave(){ ThisBaseType = thisBaseType, BasePeriod = basePeriod, Multiplier = multiplier }, input, ref cacheamaMultiMAWave);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaMultiMAWave amaMultiMAWave(amaMultiMAWaveBaseType thisBaseType, int basePeriod, double multiplier)
		{
			return indicator.amaMultiMAWave(Input, thisBaseType, basePeriod, multiplier);
		}

		public Indicators.LizardIndicators.amaMultiMAWave amaMultiMAWave(ISeries<double> input , amaMultiMAWaveBaseType thisBaseType, int basePeriod, double multiplier)
		{
			return indicator.amaMultiMAWave(input, thisBaseType, basePeriod, multiplier);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaMultiMAWave amaMultiMAWave(amaMultiMAWaveBaseType thisBaseType, int basePeriod, double multiplier)
		{
			return indicator.amaMultiMAWave(Input, thisBaseType, basePeriod, multiplier);
		}

		public Indicators.LizardIndicators.amaMultiMAWave amaMultiMAWave(ISeries<double> input , amaMultiMAWaveBaseType thisBaseType, int basePeriod, double multiplier)
		{
			return indicator.amaMultiMAWave(input, thisBaseType, basePeriod, multiplier);
		}
	}
}

#endregion
