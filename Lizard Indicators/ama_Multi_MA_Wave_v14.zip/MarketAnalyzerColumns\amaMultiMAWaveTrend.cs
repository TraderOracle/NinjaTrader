#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.LizardIndicators
{
	[Gui.CategoryOrder("Algorithmic Options", 1000100)]
	[Gui.CategoryOrder("Input Parameters", 1000200)]
	public class amaMultiMAWaveTrend : MarketAnalyzerColumn
	{
		private NinjaTrader.NinjaScript.Indicators.LizardIndicators.amaMultiMAWave amaMAW;
		
		private int 						basePeriod				= 34; 
		private double						multiplier				= 1.0;
		private amaMultiMAWaveBaseType 		thisBaseType			= amaMultiMAWaveBaseType.EMA; 
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description											= @"";
				Name												= "amaMultiMAWave_Trend";
				Calculate											= Calculate.OnPriceChange;
				DataType   											= typeof(double);
        		IsEditable 											= false;
				BarsRequiredToPlot									= 3*basePeriod;
				FormatDecimals 										= 0;
			}
			else if (State == State.DataLoaded)
			{
				amaMAW	= amaMultiMAWave(thisBaseType, basePeriod, multiplier);
			}
		}
		
		protected override void OnBarUpdate()
		{
		  	CurrentValue = amaMAW.Trend[0];
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Moving Average", Description = "Select moving average type or moving median type for the base line", GroupName = "Algorithmic Options", Order = 0)]
		public amaMultiMAWaveBaseType ThisBaseType
		{	
            get { return thisBaseType; }
            set { thisBaseType = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "MA period", Description = "Sets the lookback period for the moving average", GroupName = "Input Parameters", Order = 0)]
		public int BasePeriod
		{	
            get { return basePeriod; }
            set { basePeriod = value; }
		}
			
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Wave size", Description = "Select multiplier for adjusting size (thickness) of wave", GroupName = "Input Parameters", Order = 1)]
        public double Multiplier
        {
            get { return multiplier; }
            set { multiplier = value; }
        }
		#endregion
	}
}
