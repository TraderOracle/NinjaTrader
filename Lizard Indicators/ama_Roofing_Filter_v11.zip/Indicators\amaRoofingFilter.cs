//+----------------------------------------------------------------------------------------------+
//| Copyright © <2020>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// This is an implementation of the Roofing Filter, as published by John F. Ehlers in his publication 'Spectral Dilation - Codifying the Fractal Nature of Market Data.
	/// The Roofing Filter is designed for preprocessing data for use with any other oscillator that may follow. It may also be used as an indicator in its own right.
	/// </summary>
	[Gui.CategoryOrder("Input Parameters", 1000100)]
	[Gui.CategoryOrder("Version", 8000100)]
	public class amaRoofingFilter : Indicator
	{
        private int 				hpPeriod 					= 48;
        private int 				ssPeriod 					= 10;
		private double 				alpha1 						= 0.0;
		private double				sq2							= 0.0;
		private double				sq3							= 0.0;
        private double 				a1 							= 0.0;
        private double 				b1 							= 0.0;
        private double 				c1 							= 0.0;
        private double 				c2 							= 0.0;
        private double 				c3 							= 0.0;
		private double 				coeff1 						= 0.0;
 		private double 				coeff2 						= 0.0;
		private double 				coeff3 						= 0.0;
		private double 				recurrentHP 				= 0.0;
		private double 				recurrentFilter				= 0.0;
		private string				versionString				= "v 1.2  -  March 9, 2020";
		private Series<double>		highPass;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\nThis is an implementation of the Roofing Filter, as published by John F. Ehlers in his publication 'Spectral Dilation - Codifying the Fractal Nature of Market Data.'"
												+ " The Roofing Filter is designed for preprocessing data for use with any other oscillator that may follow. It may also be used as an indicator in its own right.";
				Name						= "amaRoofingFilter";
				IsSuspendedWhileInactive	= true;
				AddPlot(new Stroke(Brushes.MediumBlue, 2), PlotStyle.Line, "Roofing Filter");	
				AddLine(new Stroke(Brushes.Gray, 1), 0, "Zeroline");
			}
			else if (State == State.Configure)
			{
				BarsRequiredToPlot	= 2 * (hpPeriod + ssPeriod);
				highPass = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
			}	
			else if(State == State.Historical)
			{	
				const double pi = Math.PI;
				sq2 = Math.Sqrt(2.0);
				alpha1 = (Math.Cos(sq2*pi/hpPeriod) + Math.Sin(sq2*pi/hpPeriod) - 1) / Math.Cos(sq2*pi/hpPeriod);
				coeff1 = (1.0 - 0.5*alpha1)*(1 - 0.5*alpha1);
				coeff2 = (1.0 - alpha1);
				coeff3 = coeff2 * coeff2;
				a1 = Math.Exp(-sq2*pi/ssPeriod);
				b1 = 2.0 * a1*Math.Cos(sq2*pi/ssPeriod);
				c2 = b1;
				c3 = -a1*a1;
				c1 = 1.0 - c2 - c3;
			}
		}

		protected override void OnBarUpdate()
		{
            if (CurrentBar < 2)
            {
                highPass[0] = 0.0;
				RoofingFilter[0] = 0.0;;
				return;
            }
          	if (IsFirstTickOfBar)
			{
				recurrentHP = coeff1 * (- 2.0 *Input[1] + Input[2]) + 2.0 * coeff2 * highPass[1] - coeff3 * highPass[2];
				recurrentFilter = 0.5 * c1 * highPass[1] + c2 * RoofingFilter[1] + c3 * RoofingFilter[2];
			}	
			highPass[0] = coeff1 * Input[0] + recurrentHP;				
			RoofingFilter[0] = 0.5 * c1 * highPass[0] + recurrentFilter;
		}

		#region Properties
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> RoofingFilter
		{
			get { return Values[0]; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "High pass period", GroupName = "Input Parameters", Order = 0)]
		public int HPPeriod
		{	
            get { return hpPeriod; }
            set { hpPeriod = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Supersmoother period", GroupName = "Input Parameters", Order = 1)]
		public int SSPeriod
		{	
            get { return ssPeriod; }
            set { ssPeriod = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaRoofingFilter[] cacheamaRoofingFilter;
		public LizardIndicators.amaRoofingFilter amaRoofingFilter(int hPPeriod, int sSPeriod)
		{
			return amaRoofingFilter(Input, hPPeriod, sSPeriod);
		}

		public LizardIndicators.amaRoofingFilter amaRoofingFilter(ISeries<double> input, int hPPeriod, int sSPeriod)
		{
			if (cacheamaRoofingFilter != null)
				for (int idx = 0; idx < cacheamaRoofingFilter.Length; idx++)
					if (cacheamaRoofingFilter[idx] != null && cacheamaRoofingFilter[idx].HPPeriod == hPPeriod && cacheamaRoofingFilter[idx].SSPeriod == sSPeriod && cacheamaRoofingFilter[idx].EqualsInput(input))
						return cacheamaRoofingFilter[idx];
			return CacheIndicator<LizardIndicators.amaRoofingFilter>(new LizardIndicators.amaRoofingFilter(){ HPPeriod = hPPeriod, SSPeriod = sSPeriod }, input, ref cacheamaRoofingFilter);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaRoofingFilter amaRoofingFilter(int hPPeriod, int sSPeriod)
		{
			return indicator.amaRoofingFilter(Input, hPPeriod, sSPeriod);
		}

		public Indicators.LizardIndicators.amaRoofingFilter amaRoofingFilter(ISeries<double> input , int hPPeriod, int sSPeriod)
		{
			return indicator.amaRoofingFilter(input, hPPeriod, sSPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaRoofingFilter amaRoofingFilter(int hPPeriod, int sSPeriod)
		{
			return indicator.amaRoofingFilter(Input, hPPeriod, sSPeriod);
		}

		public Indicators.LizardIndicators.amaRoofingFilter amaRoofingFilter(ISeries<double> input , int hPPeriod, int sSPeriod)
		{
			return indicator.amaRoofingFilter(input, hPPeriod, sSPeriod);
		}
	}
}

#endregion
