#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.LizardIndicators
{
	[Gui.CategoryOrder("Algorithmic Options", 1000100)]
	[Gui.CategoryOrder("Input Parameters", 1000200)]
	public class amaATRTrailingStopTrend : MarketAnalyzerColumn
	{
		private NinjaTrader.NinjaScript.Indicators.LizardIndicators.amaATRTrailingStop amaATRTS;
		
        private int 				rangePeriod					= 10; 
		private double 				multiplier 					= 3.5; 
		private bool				useModifiedATR				= false;
		private bool				reverseIntraBar				= false;

		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "amaATRTrailingStop_Trend";
				Calculate									= Calculate.OnPriceChange;
				DataType   									= typeof(double);
        		IsEditable 									= false;
				BarsRequiredToPlot 							= 3*rangePeriod;
				FormatDecimals 								= 0;
			}
			else if (State == State.DataLoaded)
			{
				amaATRTS	= amaATRTrailingStop(useModifiedATR, reverseIntraBar, rangePeriod, multiplier);
			}
		}
		
		protected override void OnBarUpdate()
		{
		  	CurrentValue = amaATRTS.Trend[0];
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Use modified ATR", Description = "When set to 'true', the trailing stop is calculated with the modified ATR, otherwise it is calculated with Wilder's ATR.", GroupName = "Algorithmic Options", Order = 0)]
        public bool UseModifiedATR
        {
            get { return useModifiedATR; }
            set { useModifiedATR = value; }
        }
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Reverse intra-bar", Description = "When set to 'true', reversal signals are triggered intra-bar", GroupName = "Algorithmic Options", Order = 1)]
        public bool ReverseIntraBar
        {
            get { return reverseIntraBar; }
            set { reverseIntraBar = value; }
        }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ATR period", Description = "Sets the lookback period for the average true range", GroupName = "Input Parameters", Order = 0)]
		public int RangePeriod
		{	
            get { return rangePeriod; }
            set { rangePeriod = value; }
		}
			
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ATR multiplier", Description = "Sets the multiplier for the average true range", GroupName = "Input Parameters", Order = 1)]
		public double Multiplier
		{	
            get { return multiplier; }
            set { multiplier = value; }
		}
		#endregion
	}
}
