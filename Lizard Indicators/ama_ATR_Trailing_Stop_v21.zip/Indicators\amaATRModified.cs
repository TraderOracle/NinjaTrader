//+----------------------------------------------------------------------------------------------+
//| Copyright © <2020>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The Average True Range (ATR) is a measure of volatility. It was introduced by Welles Wilder in his book 'New Concepts in Technical Trading Systems'.
	/// This version uses a modified algorithm suggested by Sylvain Vervoort in the June 2009 issue of 'Technical Analysis of Stocks and Commodities.
	/// </summary>
	[Gui.CategoryOrder("Algorithmic Options", 1000100)]
	[Gui.CategoryOrder("Input Parameters", 1000200)]
	[Gui.CategoryOrder("Version", 8000100)]
	public class amaATRModified : Indicator
	{
		private int					period						= 14;
		private double				high0						= 0.0;
		private double				low0						= 0.0;
		private double				range0						= 0.0;
		private double				high1						= 0.0;
		private double				low1						= 0.0;
		private double				close1						= 0.0;
		private double				input1						= 0.0;
		private double				maxRange					= 0.0;
		private double				modRange					= 0.0;
		private double				extRange					= 0.0;
		private bool				calculateFromPriceData		= true;		
		private amaATRModCalcMode	calcMode					= amaATRModCalcMode.Wilder;
		private string				versionString				= "v 1.2  -  March 7, 2020";
		private SMA					averageRange;
		private Series<double>		modTrueRange;
		private ISeries<double>		averageTrueRange;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\nThe Average True Range (ATR) is a measure of volatility. It was introduced by Welles Wilder in his book 'New Concepts in Technical Trading Systems'. "
												+ " This version uses a modified algorithm suggested by Sylvain Vervoort in the June 2009 issue of 'Technical Analysis of Stocks and Commodities."; 
				Name						= "amaATRModified";
				IsSuspendedWhileInactive	= true;
				AddPlot(new Stroke(Brushes.Green, 2), PlotStyle.Line, "ATR");
			}
			else if (State == State.Configure)
			{
				if(calcMode	== amaATRModCalcMode.Arithmetic)
					BarsRequiredToPlot = period;	
				else if(calcMode == amaATRModCalcMode.Exponential)
					BarsRequiredToPlot = 3*period;
				else
					BarsRequiredToPlot = 6*period - 2;	
			}
			else if (State == State.DataLoaded)
			{	
				modTrueRange = new Series<double>(this, period < 125 ? MaximumBarsLookBack.TwoHundredFiftySix : MaximumBarsLookBack.Infinite);
				averageRange = SMA(Range(), period);
				if(Input is PriceSeries)
				{	
					averageRange = SMA(Range(), period);
					calculateFromPriceData = true;
				}	
				else
					calculateFromPriceData = false;
				if(calcMode	== amaATRModCalcMode.Arithmetic)
					averageTrueRange = SMA(modTrueRange, period);
				else if(calcMode == amaATRModCalcMode.Exponential)
					averageTrueRange = EMA(modTrueRange, period);
				else
					averageTrueRange = EMA(modTrueRange, 2*period - 1);
			}
		}

		protected override void OnBarUpdate()
		{
			if(calculateFromPriceData)
			{
				high0	= High[0];
				low0	= Low[0];
				range0 =  high0 -low0;
				if (CurrentBar == 0)
				{	
					modTrueRange[0] = high0 - low0;
					ATRModified[0]	= high0 - low0;
				}
				else
				{
					if(IsFirstTickOfBar)
					{
						high1		= High[1];
						low1		= Low[1];
						close1		= Close[1];
						maxRange 	= 1.5*averageRange[1];
					}	
					if(range0 < maxRange)
						modRange = range0;
					else
						modRange = maxRange;
					if(low0 > high1)
						extRange = high0 - close1 - (low0 - high1)/2;
					else if (high0 < low1)
						extRange = close1 - low0 - (low1 - high0)/2;
					else
						extRange = Math.Max(high0 - close1, close1 - low0);
					modTrueRange[0] = Math.Max(modRange, extRange);
					ATRModified[0] 	= averageTrueRange[0];
				}					
			}	
			else
			{	
				if (CurrentBar == 0)
				{	
					modTrueRange[0] = 0;
					ATRModified[0]	= 0;
				}
				else 
				{
					if(IsFirstTickOfBar)
						input1 = Input[1];
					modTrueRange[0] = Math.Abs(Input[0] - input1);
					ATRModified[0] 	= averageTrueRange[0];
				}
			}
		}

		#region Properties
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> ATRModified
		{
			get { return Values[0]; }
		}
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ATR formula", Description = "Select ATR formula", GroupName = "Algorithmic Options", Order = 0)]
		public amaATRModCalcMode CalcMode
		{	
            get { return calcMode; }
            set { calcMode = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ATR period", Description = "Sets the period for the average true range", GroupName = "Input Parameters", Order = 0)]
		public int Period
		{	
            get { return period; }
            set { period = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
	}
}
	
#region Global Enums

public enum amaATRModCalcMode {Arithmetic, Exponential, Wilder}

#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaATRModified[] cacheamaATRModified;
		public LizardIndicators.amaATRModified amaATRModified(amaATRModCalcMode calcMode, int period)
		{
			return amaATRModified(Input, calcMode, period);
		}

		public LizardIndicators.amaATRModified amaATRModified(ISeries<double> input, amaATRModCalcMode calcMode, int period)
		{
			if (cacheamaATRModified != null)
				for (int idx = 0; idx < cacheamaATRModified.Length; idx++)
					if (cacheamaATRModified[idx] != null && cacheamaATRModified[idx].CalcMode == calcMode && cacheamaATRModified[idx].Period == period && cacheamaATRModified[idx].EqualsInput(input))
						return cacheamaATRModified[idx];
			return CacheIndicator<LizardIndicators.amaATRModified>(new LizardIndicators.amaATRModified(){ CalcMode = calcMode, Period = period }, input, ref cacheamaATRModified);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaATRModified amaATRModified(amaATRModCalcMode calcMode, int period)
		{
			return indicator.amaATRModified(Input, calcMode, period);
		}

		public Indicators.LizardIndicators.amaATRModified amaATRModified(ISeries<double> input , amaATRModCalcMode calcMode, int period)
		{
			return indicator.amaATRModified(input, calcMode, period);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaATRModified amaATRModified(amaATRModCalcMode calcMode, int period)
		{
			return indicator.amaATRModified(Input, calcMode, period);
		}

		public Indicators.LizardIndicators.amaATRModified amaATRModified(ISeries<double> input , amaATRModCalcMode calcMode, int period)
		{
			return indicator.amaATRModified(input, calcMode, period);
		}
	}
}

#endregion
