//+----------------------------------------------------------------------------------------------+
//| Copyright © <2021>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The Laguerre RSI is a RSI built from a Laguerre filter. The Laguerre filter delays lower frequency components of price more than the high frequency components.
	/// The Easy Language version of the Laguerre RSI was published by Jochen Ehlers in his paper 'Time Warp without Space Travel'.
	/// </summary>
	[Gui.CategoryOrder("Input Parameters", 1000100)]
	[Gui.CategoryOrder("Threshold Values", 1000200)]
	[Gui.CategoryOrder("Display Options", 1000300)]
	[Gui.CategoryOrder("Laguerre RSI Plot", 8000100)]
	[Gui.CategoryOrder("Average Plot", 8000200)]
	[Gui.CategoryOrder("Version", 8000300)]
	public class amaLaguerreRSI : Indicator
	{
		private int								smoothingPeriod					= 7;
		private int								displacement					= 0;
		private int								totalBarsRequiredToPlot			= 0;
		private double 							gamma							= 0.5;
		private double							alpha							= 0.0;
		private double							recurrentPart0					= 0.0;
		private double							recurrentPart1					= 0.0;
		private double							recurrentPart2					= 0.0;
		private double							recurrentPart3					= 0.0;
		private double 							l0								= 0.0;
		private double 							l1								= 0.0;
		private double 							l2								= 0.0;
		private double 							l3								= 0.0;
		private double 							cu								= 0.0;
		private double 							cd								= 0.0;
		private double							k 								= 0.0;
		private double							laguerreRSI						= 0.0;
		private double							rsiAvg							= 0.0;
		private double							upperlineValue					= 80;
		private double							midlineValue					= 50;
		private double							lowerlineValue					= 20;
		private bool							showLaguerreRSI					= true;
		private bool							showAvg							= true;
		private bool							showLaguerreRSIShading			= true;
		private bool							showAvgShading					= true;
		private bool							applyAvgShading					= true;
		private bool							applyRSIShading					= true;
		private bool							calculateFromPriceData			= true;
		private System.Windows.Media.Brush		rsiOverboughtBrush				= Brushes.MediumBlue;
		private System.Windows.Media.Brush		rsiOversoldBrush				= Brushes.MediumBlue;
		private System.Windows.Media.Brush		rsiNeutralBrush					= Brushes.MediumBlue;
		private System.Windows.Media.Brush		avgOverboughtBrush				= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		avgOversoldBrush				= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		avgNeutralBrush					= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		rsiOverboughtAreaBrush			= Brushes.Lime;
		private System.Windows.Media.Brush		rsiOversoldAreaBrush			= Brushes.Red;
		private System.Windows.Media.Brush		avgOverboughtAreaBrush			= Brushes.DarkGreen;
		private System.Windows.Media.Brush		avgOversoldAreaBrush			= Brushes.DarkRed;
		private System.Windows.Media.Brush		rsiOverboughtAreaBrushOpaque	= null;
		private System.Windows.Media.Brush		rsiOversoldAreaBrushOpaque		= null;
		private System.Windows.Media.Brush		avgOverboughtAreaBrushOpaque	= null;
		private System.Windows.Media.Brush		avgOversoldAreaBrushOpaque		= null;
		private System.Windows.Media.Brush		upperlineBrush					= Brushes.DarkGreen;
		private System.Windows.Media.Brush		midlineBrush					= Brushes.Navy;
		private System.Windows.Media.Brush		lowerlineBrush					= Brushes.DarkRed;
		private	SharpDX.Direct2D1.Brush 		avgOverboughtBrushDX;
		private	SharpDX.Direct2D1.Brush 		avgOversoldBrushDX;
		private	SharpDX.Direct2D1.Brush 		avgNeutralBrushDX;
		private	SharpDX.Direct2D1.Brush 		rsiOverboughtBrushDX;
		private	SharpDX.Direct2D1.Brush 		rsiOversoldBrushDX;
		private	SharpDX.Direct2D1.Brush 		rsiNeutralBrushDX;
		private	SharpDX.Direct2D1.Brush 		avgOverboughtAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		avgOversoldAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		rsiOverboughtAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		rsiOversoldAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		upperlineBrushDX;
		private	SharpDX.Direct2D1.Brush 		midlineBrushDX;
		private	SharpDX.Direct2D1.Brush 		lowerlineBrushDX;
		private PlotStyle						plot0Style						= PlotStyle.Line;
		private DashStyleHelper					dash0Style						= DashStyleHelper.Solid;
		private int								plot0Width						= 2;
		private PlotStyle						plot1Style						= PlotStyle.Line;
		private DashStyleHelper					dash1Style						= DashStyleHelper.Dash;
		private int								plot1Width						= 2;
		private DashStyleHelper					upperlineStyle					= DashStyleHelper.Solid;
		private int								upperlineWidth					= 1;
		private DashStyleHelper					midlineStyle					= DashStyleHelper.Solid;
		private int								midlineWidth					= 1;
		private DashStyleHelper					lowerlineStyle					= DashStyleHelper.Solid;
		private int								lowerlineWidth					= 1;
		private int								avgAreaOpacity					= 100;
		private int								rsiAreaOpacity					= 80;
		private string							versionString					= "v 1.5  -  February 26, 2021";
		private Series<double>					ls0;
		private Series<double>					ls1;
		private Series<double>					ls2;
		private Series<double>					ls3;
		private Series<double>					rsiTrend;
		private Series<double>					avgTrend;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\n The Laguerre RSI is a RSI built from a Laguerre filter. The Laguerre filter delays lower frequency components of price more than the high frequency components. "
												+ "The Easy Language version of the 4 element Laguerre RSI was published by Jochen Ehlers in his paper 'Time Warp without Space Travel'.";
				IsSuspendedWhileInactive 	= true;
				ArePlotsConfigurable		= false;
				AreLinesConfigurable		= false;
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "Laguerre RSI");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "Average");
				AddLine(new Stroke(Brushes.Gray, 1), 80, "Upper Line");
				AddLine(new Stroke(Brushes.Gray, 1), 50, "Midline");
				AddLine(new Stroke(Brushes.Gray, 1), 20, "Lower Line");
			}
			
			else if (State == State.Configure)
			{
				BarsRequiredToPlot = (int)(3*(1+gamma)/(1-gamma)) + 3*smoothingPeriod;
				totalBarsRequiredToPlot = Math.Max(0, BarsRequiredToPlot + displacement);
				if(showLaguerreRSI)
				{	
					Plots[0].PlotStyle = plot0Style;
					Plots[0].DashStyleHelper = dash0Style;
					Plots[0].Width = plot0Width;
				}	
				if(showAvg)
				{	
					Plots[1].PlotStyle = plot1Style;
					Plots[1].DashStyleHelper = dash1Style;
					Plots[1].Width = plot1Width;
				}	
				Lines[0].Value = upperlineValue;
				Lines[0].Brush = upperlineBrush;
				Lines[0].DashStyleHelper = upperlineStyle;
				Lines[0].Width = upperlineWidth;
				Lines[1].Value = midlineValue;
				Lines[1].Brush = midlineBrush;
				Lines[1].DashStyleHelper = midlineStyle;
				Lines[1].Width = midlineWidth;
				Lines[2].Value = lowerlineValue;
				Lines[2].Brush = lowerlineBrush;
				Lines[2].DashStyleHelper = lowerlineStyle;
				Lines[2].Width = lowerlineWidth;
				avgOverboughtAreaBrushOpaque = avgOverboughtAreaBrush.Clone(); 
				avgOverboughtAreaBrushOpaque.Opacity = (float)avgAreaOpacity/100.0;
				avgOverboughtAreaBrushOpaque.Freeze();
				avgOversoldAreaBrushOpaque = avgOversoldAreaBrush.Clone(); 
				avgOversoldAreaBrushOpaque.Opacity = (float) avgAreaOpacity/100.0;
				avgOversoldAreaBrushOpaque.Freeze();
				rsiOverboughtAreaBrushOpaque = rsiOverboughtAreaBrush.Clone(); 
				rsiOverboughtAreaBrushOpaque.Opacity = (float) rsiAreaOpacity/100.0;
				rsiOverboughtAreaBrushOpaque.Freeze();
				rsiOversoldAreaBrushOpaque = rsiOversoldAreaBrush.Clone(); 
				rsiOversoldAreaBrushOpaque.Opacity = (float) rsiAreaOpacity/100.0;
				rsiOversoldAreaBrushOpaque.Freeze();
			}	
			else if (State == State.DataLoaded)
			{
				ls0	= new Series<double>(this);
				ls1	= new Series<double>(this);
				ls2	= new Series<double>(this);
				ls3	= new Series<double>(this);
				rsiTrend = new Series<double>(this, MaximumBarsLookBack.Infinite);
				avgTrend = new Series<double>(this, MaximumBarsLookBack.Infinite);
			}	
			else if (State == State.Historical)
			{
				alpha = 1 - gamma;
				k = 2.0/(1 + smoothingPeriod);
				applyRSIShading = showLaguerreRSI && showLaguerreRSIShading && rsiAreaOpacity > 0;
				applyAvgShading = showAvg && showAvgShading && avgAreaOpacity > 0;
				avgOverboughtAreaBrushOpaque = avgOverboughtAreaBrush.Clone(); 
				avgOverboughtAreaBrushOpaque.Opacity = (float)avgAreaOpacity/100.0;
				avgOverboughtAreaBrushOpaque.Freeze();
				avgOversoldAreaBrushOpaque = avgOversoldAreaBrush.Clone(); 
				avgOversoldAreaBrushOpaque.Opacity = (float) avgAreaOpacity/100.0;
				avgOversoldAreaBrushOpaque.Freeze();
				rsiOverboughtAreaBrushOpaque = rsiOverboughtAreaBrush.Clone(); 
				rsiOverboughtAreaBrushOpaque.Opacity = (float) rsiAreaOpacity/100.0;
				rsiOverboughtAreaBrushOpaque.Freeze();
				rsiOversoldAreaBrushOpaque = rsiOversoldAreaBrush.Clone(); 
				rsiOversoldAreaBrushOpaque.Opacity = (float) rsiAreaOpacity/100.0;
				rsiOversoldAreaBrushOpaque.Freeze();
			}
		}
		
		protected override void OnBarUpdate()
		{
			if(CurrentBar == 0)
			{
				ls0[0] = Input[0];
				ls1[0] = Input[0];
				ls2[0] = Input[0];
				ls3[0] = Input[0];
				LaguerreRSI[0] = 50;
                Average[0] = 50;
			}	
			else
			{
				if (IsFirstTickOfBar)
				{
					recurrentPart0 = gamma * ls0[1];
					recurrentPart1 = ls0[1] + gamma * ls1[1];
					recurrentPart2 = ls1[1] + gamma * ls2[1];
					recurrentPart3 = ls2[1] + gamma * ls3[1];
				}
				l0 = alpha * Input[0] + recurrentPart0;
				l1 = -gamma * l0 + recurrentPart1;
				l2 = -gamma * l1 + recurrentPart2;
				l3 = -gamma * l2 + recurrentPart3;				
				ls0[0] = l0;
				ls1[0] = l1;
				ls2[0] = l2;
				ls3[0] = l3;
				
				cu = 0.0;
				cd = 0.0;
				if (l0 >= l1)
					cu = l0 - l1;
				else
					cd = l1 - l0;
				if (l1 >= l2)
					cu += l1 - l2;
				else
					cd += l2 - l1;
				if (l2 >= l3)
					cu += l2 - l3;
				else
					cd += l3 - l2;
				if((cu + cd).ApproxCompare(0) == 0)
					laguerreRSI = LaguerreRSI[1];
				else
					laguerreRSI = 100 * cu / (cu + cd);
				rsiAvg = k * laguerreRSI + (1 - k) * Average[1];
				LaguerreRSI[0] = laguerreRSI;
				Average[0] = rsiAvg;			
			}	
			
			if(showLaguerreRSI)
			{
				if(laguerreRSI > upperlineValue)
				{	
					rsiTrend[0] = 1.0;
					PlotBrushes[0][0] = rsiOverboughtBrush;
				}	
				else if(laguerreRSI < lowerlineValue)
				{	
					rsiTrend[0] = -1.0;
					PlotBrushes[0][0] = rsiOversoldBrush;
				}	
				else
				{	
					rsiTrend[0] = 0.0;
					PlotBrushes[0][0] = rsiNeutralBrush;
				}	
			}
			else
			{	
				if(laguerreRSI > upperlineValue)
					rsiTrend[0] = 1.0;
				else if(laguerreRSI < lowerlineValue)
					rsiTrend[0] = -1.0;
				else
					rsiTrend[0] = 0.0;
				PlotBrushes[0][0] = Brushes.Transparent;
			}
			
			if(showAvg)
			{
				if(rsiAvg > upperlineValue)
				{	
					avgTrend[0] = 1.0;
					PlotBrushes[1][0] = avgOverboughtBrush;
				}	
				else if(rsiAvg < lowerlineValue)
				{	
					avgTrend[0] = -1.0;
					PlotBrushes[1][0] = avgOversoldBrush;
				}	
				else
				{	
					avgTrend[0] = 0.0;
					PlotBrushes[1][0] = avgNeutralBrush;
				}	
			}
			else
			{	
				if(rsiAvg > upperlineValue)
					avgTrend[0] = 1.0;
				else if(rsiAvg < lowerlineValue)
					avgTrend[0] = -1.0;
				else
					avgTrend[0] = 0.0;
				PlotBrushes[1][0] = Brushes.Transparent;
			}
		}

		#region Properties
        [Browsable(false)]	
        [XmlIgnore()]		
        public Series<double> LaguerreRSI
        {
            get { return Values[0]; }
        }
		
       	[Browsable(false)]	
        [XmlIgnore()]		
        public Series<double> Average
        {
            get { return Values[1]; }
        }

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> RSITrend
		{
			get { return rsiTrend; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> AvgTrend
		{
			get { return avgTrend; }
		}
		
		[Range(0.0, 0.99), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Gamma", Description = "Sets gamma parameter for calculating the Laguerre RSI", GroupName = "Input Parameters", Order = 0)]
		public double Gamma
		{	
            get { return gamma; }
            set { gamma = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Smoothing period", Description = "Sets period for calculating the Laguerre RSI Average", GroupName = "Input Parameters", Order = 1)]
		public int SmoothingPeriod
		{	
            get { return smoothingPeriod; }
            set { smoothingPeriod = value; }
		}
		
		[Range(50, 100), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Overbought line", Description = "Sets the overbought level ffor the two oscillators", GroupName = "Threshold Values", Order = 0)]
		public double UpperlineValue
		{	
            get { return upperlineValue; }
            set { upperlineValue = value; }
		}
		
		[Range(0, 50), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Oversold line", Description = "Sets the oversold level for the two oscillators", GroupName = "Threshold Values", Order = 1)]
		public double LowerlineValue
		{	
            get { return lowerlineValue; }
            set { lowerlineValue = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show Laguerre RSI", Description = "Displays RSI", GroupName = "Display Options", Order = 0)]
      	public bool ShowLaguerreRSI
        {
            get { return showLaguerreRSI; }
            set { showLaguerreRSI = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show RSI shading", Description = "Displays RSI shading", GroupName = "Display Options", Order = 1)]
      	public bool ShowLaguerreRSIShading
        {
            get { return showLaguerreRSIShading; }
            set { showLaguerreRSIShading = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show average", Description = "Displays average", GroupName = "Display Options", Order = 2)]
      	public bool ShowAvg
        {
            get { return showAvg; }
            set { showAvg = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show average shading", Description = "Displays average shading", GroupName = "Display Options", Order = 3)]
      	public bool ShowAvgShading
        {
            get { return showAvgShading; }
            set { showAvgShading = value; }
        }
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "RSI overbought", Description = "Sets the color for the RSI when overbought", GroupName = "Laguerre RSI Plot", Order = 0)]
		public System.Windows.Media.Brush RSIOverboughtBrush
		{ 
			get {return rsiOverboughtBrush;}
			set {rsiOverboughtBrush = value;}
		}

		[Browsable(false)]
		public string RSIOverboughtBrushSerializable
		{
			get { return Serialize.BrushToString(rsiOverboughtBrush); }
			set { rsiOverboughtBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "RSI neutral", Description = "Sets the color for the RSI when neutral", GroupName = "Laguerre RSI Plot", Order = 1)]
		public System.Windows.Media.Brush RSINeutralBrush
		{ 
			get {return rsiNeutralBrush;}
			set {rsiNeutralBrush = value;}
		}

		[Browsable(false)]
		public string RSINeutralBrushSerializable
		{
			get { return Serialize.BrushToString(rsiNeutralBrush); }
			set { rsiNeutralBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "RSI oversold", Description = "Sets the color for the RSI when oversold", GroupName = "Laguerre RSI Plot", Order = 2)]
		public System.Windows.Media.Brush RSIOversoldBrush
		{ 
			get {return rsiOversoldBrush;}
			set {rsiOversoldBrush = value;}
		}

		[Browsable(false)]
		public string RSIOversoldBrushSerializable
		{
			get { return Serialize.BrushToString(rsiOversoldBrush); }
			set { rsiOversoldBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style RSI", Description = "Sets the dash style for the RSI", GroupName = "Laguerre RSI Plot", Order = 3)]
		public DashStyleHelper Dash0Style
		{
			get { return dash0Style; }
			set { dash0Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width RSI", Description = "Sets the plot width for the RSI", GroupName = "Laguerre RSI Plot", Order = 4)]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "RSI overbought area", Description = "Sets the color for the RSI area when overbought", GroupName = "Laguerre RSI Plot", Order = 5)]
		public System.Windows.Media.Brush RSIOverboughtAreaBrush
		{ 
			get {return rsiOverboughtAreaBrush;}
			set {rsiOverboughtAreaBrush = value;}
		}

		[Browsable(false)]
		public string RSIOverboughtAreaBrushSerializable
		{
			get { return Serialize.BrushToString(rsiOverboughtAreaBrush); }
			set { rsiOverboughtAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "RSI oversold area", Description = "Sets the color for the RSI area when oversold", GroupName = "Laguerre RSI Plot", Order = 6)]
		public System.Windows.Media.Brush RSIOversoldAreaBrush
		{ 
			get {return rsiOversoldAreaBrush;}
			set {rsiOversoldAreaBrush = value;}
		}

		[Browsable(false)]
		public string RSIOversoldAreaBrushSerializable
		{
			get { return Serialize.BrushToString(rsiOversoldAreaBrush); }
			set { rsiOversoldAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(0, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Area opacity", Description = "Sets the opacity for the overbought and oversold areas", GroupName = "Laguerre RSI Plot", Order = 7)]
		public int RSIAreaOpacity
		{	
            get { return rsiAreaOpacity; }
            set { rsiAreaOpacity = value; }
		}		
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Average overbought", Description = "Sets the color for the average when overbought", GroupName = "Average Plot", Order = 0)]
		public System.Windows.Media.Brush AvgOverboughtBrush
		{ 
			get {return avgOverboughtBrush;}
			set {avgOverboughtBrush = value;}
		}

		[Browsable(false)]
		public string AvgOverboughtBrushSerializable
		{
			get { return Serialize.BrushToString(avgOverboughtBrush); }
			set { avgOverboughtBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Average neutral", Description = "Sets the color for the average when neutral", GroupName = "Average Plot", Order = 1)]
		public System.Windows.Media.Brush AvgNeutralBrush
		{ 
			get {return avgNeutralBrush;}
			set {avgNeutralBrush = value;}
		}

		[Browsable(false)]
		public string AvgNeutralBrushSerializable
		{
			get { return Serialize.BrushToString(avgNeutralBrush); }
			set { avgNeutralBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Average oversold", Description = "Sets the color for the average when oversold", GroupName = "Average Plot", Order = 2)]
		public System.Windows.Media.Brush AvgOversoldBrush
		{ 
			get {return avgOversoldBrush;}
			set {avgOversoldBrush = value;}
		}

		[Browsable(false)]
		public string AvgOversoldBrushSerializable
		{
			get { return Serialize.BrushToString(avgOversoldBrush); }
			set { avgOversoldBrush = Serialize.StringToBrush(value); }
		}

		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style average", Description = "Sets the dash style for the average", GroupName = "Average Plot", Order = 3)]
		public DashStyleHelper Dash1Style
		{
			get { return dash1Style; }
			set { dash1Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width average", Description = "Sets the plot width for the average", GroupName = "Average Plot", Order = 4)]
		public int Plot1Width
		{	
            get { return plot1Width; }
            set { plot1Width = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Average overbought area", Description = "Sets the color for the average area when overbought", GroupName = "Average Plot", Order = 5)]
		public System.Windows.Media.Brush AvgOverboughtAreaBrush
		{ 
			get {return avgOverboughtAreaBrush;}
			set {avgOverboughtAreaBrush = value;}
		}

		[Browsable(false)]
		public string AvgOverboughtAreaBrushSerializable
		{
			get { return Serialize.BrushToString(avgOverboughtAreaBrush); }
			set { avgOverboughtAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Average oversold area", Description = "Sets the color for the average area when oversold", GroupName = "Average Plot", Order = 6)]
		public System.Windows.Media.Brush AvgOversoldAreaBrush
		{ 
			get {return avgOversoldAreaBrush;}
			set {avgOversoldAreaBrush = value;}
		}

		[Browsable(false)]
		public string AvgOversoldAreaBrushSerializable
		{
			get { return Serialize.BrushToString(avgOversoldAreaBrush); }
			set { avgOversoldAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(0, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Area opacity", Description = "Sets the opacity for the overbought and oversold areas", GroupName = "Average Plot", Order = 7)]
		public int AvgAreaOpacity
		{	
            get { return avgAreaOpacity; }
            set { avgAreaOpacity = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upper line", Description = "Sets the color for the average area when oversold", GroupName = "Lines", Order = 0)]
		public System.Windows.Media.Brush UpperlineBrush
		{ 
			get {return upperlineBrush;}
			set {upperlineBrush = value;}
		}

		[Browsable(false)]
		public string UpperlineBrushSerializable
		{
			get { return Serialize.BrushToString(upperlineBrush); }
			set { upperlineBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style upper line", Description = "Sets the dash style for the upper line", GroupName = "Lines", Order = 1)]
		public DashStyleHelper UpperlineStyle
		{
			get { return upperlineStyle; }
			set { upperlineStyle = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width upper line", Description = "Sets the plot width for the upper line", GroupName = "Lines", Order = 2)]
		public int UpperlineWidth
		{	
            get { return upperlineWidth; }
            set { upperlineWidth = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Midline", Description = "Sets the color for the average area when oversold", GroupName = "Lines", Order = 3)]
		public System.Windows.Media.Brush MidlineBrush
		{ 
			get {return midlineBrush;}
			set {midlineBrush = value;}
		}

		[Browsable(false)]
		public string MidlineBrushSerializable
		{
			get { return Serialize.BrushToString(midlineBrush); }
			set { midlineBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style midline", Description = "Sets the dash style for the midline", GroupName = "Lines", Order = 4)]
		public DashStyleHelper MidlineStyle
		{
			get { return midlineStyle; }
			set { midlineStyle = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width midline", Description = "Sets the plot width for the midline", GroupName = "Lines", Order = 5)]
		public int MidlineWidth
		{	
            get { return midlineWidth; }
            set { midlineWidth = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Lower line", Description = "Sets the color for the average area when oversold", GroupName = "Lines", Order = 6)]
		public System.Windows.Media.Brush LowerlineBrush
		{ 
			get {return lowerlineBrush;}
			set {lowerlineBrush = value;}
		}

		[Browsable(false)]
		public string LowerlineBrushSerializable
		{
			get { return Serialize.BrushToString(lowerlineBrush); }
			set { lowerlineBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style lower line", Description = "Sets the dash style for the lower line", GroupName = "Lines", Order = 7)]
		public DashStyleHelper LowerlineStyle
		{
			get { return lowerlineStyle; }
			set { lowerlineStyle = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width lower line", Description = "Sets the plot width for the lower line", GroupName = "Lines", Order = 8)]
		public int LowerlineWidth
		{	
            get { return lowerlineWidth; }
            set { lowerlineWidth = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
		
		#region Miscellaneous
		
		public override void OnRenderTargetChanged()
		{
			if (avgOverboughtBrushDX != null)
				avgOverboughtBrushDX.Dispose();
			if (avgOversoldBrushDX != null)
				avgOversoldBrushDX.Dispose();
			if (avgNeutralBrushDX != null)
				avgNeutralBrushDX.Dispose();
			if (rsiOverboughtBrushDX != null)
				rsiOverboughtBrushDX.Dispose();
			if (rsiOversoldBrushDX != null)
				rsiOversoldBrushDX.Dispose();
			if (rsiNeutralBrushDX != null)
				rsiNeutralBrushDX.Dispose();
			if (avgOverboughtAreaBrushDX != null)
				avgOverboughtAreaBrushDX.Dispose();
			if (avgOversoldAreaBrushDX != null)
				avgOversoldAreaBrushDX.Dispose();
			if (rsiOverboughtAreaBrushDX != null)
				rsiOverboughtAreaBrushDX.Dispose();
			if (rsiOversoldAreaBrushDX != null)
				rsiOversoldAreaBrushDX.Dispose();
			if (upperlineBrushDX != null)
				upperlineBrushDX.Dispose();
			if (midlineBrushDX != null)
				midlineBrushDX.Dispose();
			if (lowerlineBrushDX != null)
				lowerlineBrushDX.Dispose();
			
			if (RenderTarget != null)
			{
				try
				{
					avgOverboughtBrushDX = avgOverboughtBrush.ToDxBrush(RenderTarget);
					avgOversoldBrushDX = avgOversoldBrush.ToDxBrush(RenderTarget);
					avgNeutralBrushDX = avgNeutralBrush.ToDxBrush(RenderTarget);
					rsiOverboughtBrushDX = rsiOverboughtBrush.ToDxBrush(RenderTarget);
					rsiOversoldBrushDX = rsiOversoldBrush.ToDxBrush(RenderTarget);
					rsiNeutralBrushDX = rsiNeutralBrush.ToDxBrush(RenderTarget);
					avgOverboughtAreaBrushDX = avgOverboughtAreaBrushOpaque.ToDxBrush(RenderTarget);
					avgOversoldAreaBrushDX = avgOversoldAreaBrushOpaque.ToDxBrush(RenderTarget);
					rsiOverboughtAreaBrushDX = rsiOverboughtAreaBrushOpaque.ToDxBrush(RenderTarget);
					rsiOversoldAreaBrushDX = rsiOversoldAreaBrushOpaque.ToDxBrush(RenderTarget);
					upperlineBrushDX = upperlineBrush.ToDxBrush(RenderTarget);
					midlineBrushDX = midlineBrush.ToDxBrush(RenderTarget);
					lowerlineBrushDX = lowerlineBrush.ToDxBrush(RenderTarget);
				}
				catch (Exception e) { }
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (Bars == null || ChartControl == null || ChartBars.ToIndex < BarsRequiredToPlot || !IsVisible) return;
			int	lastBarPainted = ChartBars.ToIndex;
			if(lastBarPainted  < 0 || BarsArray[0].Count < lastBarPainted) return;
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
	        ChartPanel panel = chartControl.ChartPanels[ChartPanel.PanelIndex];
			
			bool nonEquidistant 	= (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti);
			int lastBarCounted		= Close.Count - 1;
			int	lastBarOnUpdate		= lastBarCounted - (Calculate == Calculate.OnBarClose ? 1 : 0);
			int	lastBarIndex		= Math.Min(lastBarPainted, lastBarOnUpdate);
			int firstBarPainted	 	= ChartBars.FromIndex;
			int firstBarIndex  	 	= Math.Max(totalBarsRequiredToPlot, firstBarPainted); 
			int lastIndex			= 0;
			int x 					= 0;
			int y0	 				= 0;
			int y1 					= 0;
			int yUpper 				= 0;
			int yMid 				= 0;
			int yLower 				= 0;
			int y 					= 0;
			int t					= 0;
			int lastX 				= 0;
			int lastY1 				= 0;
			int lastY2 				= 0;
			int lastY 				= 0;
			int sign 				= 0;
			int lastSign 			= 0;
			int startBar 			= 0;
			int returnBar 			= 0;
			int count	 			= 0;
			double barWidth			= 0;
			bool firstLoop 			= true;
			SharpDX.Vector2 startPointDX;
			SharpDX.Vector2 endPointDX;
			Vector2[] plotArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			
			if(lastBarIndex + displacement > firstBarIndex)
			{	
				if (displacement >= 0)
					lastIndex = lastBarIndex + displacement;
				else
					lastIndex = Math.Min(lastBarIndex, lastBarOnUpdate + displacement);
				if(nonEquidistant && lastIndex > lastBarOnUpdate)
					barWidth = Convert.ToDouble(ChartControl.GetXByBarIndex(ChartBars, lastBarPainted) - ChartControl.GetXByBarIndex(ChartBars, lastBarPainted - displacement))/displacement;
				lastY1	= chartScale.GetYByValue(Average.GetValueAt(lastIndex - displacement));
				lastY2	= chartScale.GetYByValue(LaguerreRSI.GetValueAt(lastIndex - displacement));
				yUpper  = chartScale.GetYByValue(upperlineValue);
				yMid  = chartScale.GetYByValue(midlineValue);
				yLower  = chartScale.GetYByValue(lowerlineValue);
				
				//Lines
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yUpper);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yUpper);
				RenderTarget.DrawLine(startPointDX, endPointDX, upperlineBrushDX, upperlineWidth, Lines[0].StrokeStyle);
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yMid);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yMid);
				RenderTarget.DrawLine(startPointDX, endPointDX, midlineBrushDX, midlineWidth, Lines[1].StrokeStyle);
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yLower);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yLower);
				RenderTarget.DrawLine(startPointDX, endPointDX, lowerlineBrushDX, lowerlineWidth, Lines[2].StrokeStyle);
				
				// Average Shading
				if(applyAvgShading)
				{	
					lastY = lastY1;
					lastSign = (int) AvgTrend.GetValueAt(lastIndex - displacement);
					startBar = lastIndex;
					firstLoop = true;
					do
					{
						SharpDX.Direct2D1.PathGeometry 	pathF;
						SharpDX.Direct2D1.GeometrySink 	sinkF;
						pathF = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (pathF)
						{
							if(firstLoop)
							{	
								count = 0;						
								if(nonEquidistant && displacement > 0 && startBar > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((startBar - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, startBar);
								if (lastSign == 1)
									plotArray[count] = new Vector2(x, yUpper);
								else if(lastSign == -1)
									plotArray[count] = new Vector2(x, yLower);
							}	
							else
							{	
								count = 0;
								plotArray[count] = new Vector2(lastX, lastY);
							}
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(Average.GetValueAt(idx - displacement));   
								t = (int) AvgTrend.GetValueAt(idx - displacement);
								count = count + 1;
								if(t == lastSign)
								{
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = t;
									lastX = x;
									lastY = y;
								}	
								else if (t == 0 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 0 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
								else if (t == 1 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
							}
							if(sign == 0)
							{	
								firstLoop = false;
								continue;
							}	
							if(startBar == firstBarIndex)
							{
								count = count + 1;
								if(sign == 1)
									plotArray[count] = new Vector2(lastX, yUpper);
								else if(sign == -1)
									plotArray[count] = new Vector2(lastX, yLower);
							}	
							sinkF = pathF.Open();
							sinkF.BeginFigure(plotArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sinkF.AddLine(plotArray[i]);
							sinkF.EndFigure(FigureEnd.Closed);
			        		sinkF.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
							if(sign == 1)
		 						RenderTarget.FillGeometry(pathF, avgOverboughtAreaBrushDX);
							else if(sign == -1) 
		 						RenderTarget.FillGeometry(pathF, avgOversoldAreaBrushDX);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						pathF.Dispose();
						sinkF.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex && Average.IsValidDataPointAt(startBar - displacement));
				}
				
				// Laguerre RSI Shading
				if(applyRSIShading)
				{	
					lastY = lastY2;
					lastSign = (int) RSITrend.GetValueAt(lastIndex - displacement);
					startBar = lastIndex;
					firstLoop = true;
					do
					{
						SharpDX.Direct2D1.PathGeometry 	pathF;
						SharpDX.Direct2D1.GeometrySink 	sinkF;
						pathF = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (pathF)
						{
							if(firstLoop)
							{	
								count = 0;						
								if(nonEquidistant && displacement > 0 && startBar > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((startBar - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, startBar);
								if (lastSign == 1)
									plotArray[count] = new Vector2(x, yUpper);
								else if(lastSign == -1)
									plotArray[count] = new Vector2(x, yLower);
							}	
							else
							{	
								count = 0;
								plotArray[count] = new Vector2(lastX, lastY);
							}
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(LaguerreRSI.GetValueAt(idx - displacement));   
								t = (int) RSITrend.GetValueAt(idx - displacement);
								count = count + 1;
								if(t == lastSign)
								{
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = t;
									lastX = x;
									lastY = y;
								}	
								else if (t == 0 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 0 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
								else if (t == 1 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
							}
							if(sign == 0)
							{	
								firstLoop = false;
								continue;
							}	
							if(startBar == firstBarIndex)
							{
								count = count + 1;
								if(sign == 1)
									plotArray[count] = new Vector2(lastX, yUpper);
								else if(sign == -1)
									plotArray[count] = new Vector2(lastX, yLower);
							}	
							sinkF = pathF.Open();
							sinkF.BeginFigure(plotArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sinkF.AddLine(plotArray[i]);
							sinkF.EndFigure(FigureEnd.Closed);
			        		sinkF.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
							if(sign == 1)
		 						RenderTarget.FillGeometry(pathF, rsiOverboughtAreaBrushDX);
							else if(sign == -1) 
		 						RenderTarget.FillGeometry(pathF, rsiOversoldAreaBrushDX);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						pathF.Dispose();
						sinkF.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex && LaguerreRSI.IsValidDataPointAt(startBar - displacement));
				}
				
				// Laguerre RSI Average
				if(showAvg)
				{	
					lastY = lastY1;
					lastSign = 5;
					startBar = lastIndex;
					firstLoop = true;
					do
					{
						SharpDX.Direct2D1.PathGeometry 	pathE;
						SharpDX.Direct2D1.GeometrySink 	sinkE;
						pathE = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (pathE)
						{
							count = 0;
							plotArray[count] = new Vector2(lastX, lastY);
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(Average.GetValueAt(idx - displacement));   
								t = (int) AvgTrend.GetValueAt(idx - displacement);
								count = count + 1;
								if(t == lastSign)
								{
									plotArray[count] = new Vector2(x,y);
									sign = t;
									startBar = idx;
									lastX = x;
									lastY = y;
								}	
								else if(lastSign == 5)
								{	
									plotArray[count] = new Vector2(x,y);
									sign = 5;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}	
								else if (t == 0 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 0 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
								else if (t == 1 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
							}
							sinkE = pathE.Open();
							if(firstLoop)
								sinkE.BeginFigure(plotArray[1], FigureBegin.Filled);
							else
								sinkE.BeginFigure(plotArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sinkE.AddLine(plotArray[i]);
							sinkE.EndFigure(FigureEnd.Open);
			        		sinkE.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
							if(sign == 1)
		 						RenderTarget.DrawGeometry(pathE, avgOverboughtBrushDX, Plots[1].Width, Plots[1].StrokeStyle);
							else if(sign == 0) 
		 						RenderTarget.DrawGeometry(pathE, avgNeutralBrushDX, Plots[1].Width, Plots[1].StrokeStyle);
							else if(sign == -1) 
		 						RenderTarget.DrawGeometry(pathE, avgOversoldBrushDX, Plots[1].Width, Plots[1].StrokeStyle);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						pathE.Dispose();
						sinkE.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex && Average.IsValidDataPointAt(startBar - displacement));
				}

				// Laguerre RSI
				if(showLaguerreRSI)
				{	
					lastY = lastY2;
					lastSign = 5;
					startBar = lastIndex;
					firstLoop = true;
					do
					{
						SharpDX.Direct2D1.PathGeometry 	pathE;
						SharpDX.Direct2D1.GeometrySink 	sinkE;
						pathE = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (pathE)
						{
							count = 0;
							plotArray[count] = new Vector2(lastX, lastY);
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(LaguerreRSI.GetValueAt(idx - displacement));   
								t = (int) RSITrend.GetValueAt(idx - displacement);
								count = count + 1;
								if(t == lastSign)
								{
									plotArray[count] = new Vector2(x,y);
									sign = t;
									startBar = idx;
									lastX = x;
									lastY = y;
								}	
								else if(lastSign == 5)
								{	
									plotArray[count] = new Vector2(x,y);
									sign = 5;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}	
								else if (t == 0 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 0 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
								else if (t == 1 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
							}
							sinkE = pathE.Open();
							if(firstLoop)
								sinkE.BeginFigure(plotArray[1], FigureBegin.Filled);
							else
								sinkE.BeginFigure(plotArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sinkE.AddLine(plotArray[i]);
							sinkE.EndFigure(FigureEnd.Open);
			        		sinkE.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
							if(sign == 1)
		 						RenderTarget.DrawGeometry(pathE, rsiOverboughtBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
							else if(sign == 0) 
		 						RenderTarget.DrawGeometry(pathE, rsiNeutralBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
							else if(sign == -1) 
		 						RenderTarget.DrawGeometry(pathE, rsiOversoldBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						pathE.Dispose();
						sinkE.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex && LaguerreRSI.IsValidDataPointAt(startBar - displacement));
				}			
			}
		}		
		#endregion		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaLaguerreRSI[] cacheamaLaguerreRSI;
		public LizardIndicators.amaLaguerreRSI amaLaguerreRSI(double gamma, int smoothingPeriod, double upperlineValue, double lowerlineValue)
		{
			return amaLaguerreRSI(Input, gamma, smoothingPeriod, upperlineValue, lowerlineValue);
		}

		public LizardIndicators.amaLaguerreRSI amaLaguerreRSI(ISeries<double> input, double gamma, int smoothingPeriod, double upperlineValue, double lowerlineValue)
		{
			if (cacheamaLaguerreRSI != null)
				for (int idx = 0; idx < cacheamaLaguerreRSI.Length; idx++)
					if (cacheamaLaguerreRSI[idx] != null && cacheamaLaguerreRSI[idx].Gamma == gamma && cacheamaLaguerreRSI[idx].SmoothingPeriod == smoothingPeriod && cacheamaLaguerreRSI[idx].UpperlineValue == upperlineValue && cacheamaLaguerreRSI[idx].LowerlineValue == lowerlineValue && cacheamaLaguerreRSI[idx].EqualsInput(input))
						return cacheamaLaguerreRSI[idx];
			return CacheIndicator<LizardIndicators.amaLaguerreRSI>(new LizardIndicators.amaLaguerreRSI(){ Gamma = gamma, SmoothingPeriod = smoothingPeriod, UpperlineValue = upperlineValue, LowerlineValue = lowerlineValue }, input, ref cacheamaLaguerreRSI);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaLaguerreRSI amaLaguerreRSI(double gamma, int smoothingPeriod, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaLaguerreRSI(Input, gamma, smoothingPeriod, upperlineValue, lowerlineValue);
		}

		public Indicators.LizardIndicators.amaLaguerreRSI amaLaguerreRSI(ISeries<double> input , double gamma, int smoothingPeriod, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaLaguerreRSI(input, gamma, smoothingPeriod, upperlineValue, lowerlineValue);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaLaguerreRSI amaLaguerreRSI(double gamma, int smoothingPeriod, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaLaguerreRSI(Input, gamma, smoothingPeriod, upperlineValue, lowerlineValue);
		}

		public Indicators.LizardIndicators.amaLaguerreRSI amaLaguerreRSI(ISeries<double> input , double gamma, int smoothingPeriod, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaLaguerreRSI(input, gamma, smoothingPeriod, upperlineValue, lowerlineValue);
		}
	}
}

#endregion
