#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.LizardIndicators
{
	[Gui.CategoryOrder("Algorithmic Options", 1000100)]
	[Gui.CategoryOrder("Input Parameters", 1000200)]
	public class amaSuperTrendU11Trend : MarketAnalyzerColumn
	{
		private NinjaTrader.NinjaScript.Indicators.LizardIndicators.amaSuperTrendU11 amaSTU11;
		
		private int 						basePeriod			= 8; 
        private int 						volaPeriod			= 15; 
		private double 						multiplier 			= 2.5; 
		private bool						reverseIntraBar		= false;
		private amaSuperTrendU11BaseType 	thisBaseType		= amaSuperTrendU11BaseType.Median; 
		private amaSuperTrendU11OffsetType 	thisOffsetType		= amaSuperTrendU11OffsetType.Wilder; 
		private amaSuperTrendU11VolaType 	thisVolaType		= amaSuperTrendU11VolaType.True_Range; 

		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description										= @"";
				Name											= "amaSuperTrendU11_Trend";
				Calculate										= Calculate.OnPriceChange;
				DataType   										= typeof(double);
        		IsEditable 										= false;
				BarsRequiredToPlot 								= Math.Max(basePeriod, 6*volaPeriod);
				FormatDecimals 									= 0;
			}
			else if (State == State.DataLoaded)
			{
				amaSTU11		= amaSuperTrendU11(thisBaseType, thisVolaType, thisOffsetType, reverseIntraBar, basePeriod, volaPeriod, multiplier);
			}
		}
		
		protected override void OnBarUpdate()
		{
		  	CurrentValue = amaSTU11.Trend[0];
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Baseline smoothing", Description = "Select moving average type or moving median type for the base line", GroupName = "Algorithmic Options", Order = 0)]
		public amaSuperTrendU11BaseType ThisBaseType
		{	
            get { return thisBaseType; }
            set { thisBaseType = value; }
		}
			
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Offset formula", Description = "Select volatility formula used for offset smoothing", GroupName = "Algorithmic Options", Order = 1)]
 		[RefreshProperties(RefreshProperties.All)] 
		public amaSuperTrendU11VolaType ThisVolaType
		{	
            get { return thisVolaType; }
            set { thisVolaType = value; }
		}
			
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Offset smoothing", Description = "Select moving average type or moving median type for the offset", GroupName = "Algorithmic Options", Order = 2)]
		public amaSuperTrendU11OffsetType ThisOffsetType
		{	
            get { return thisOffsetType; }
            set { thisOffsetType = value; }
		}
			
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Reverse intra-bar", Description = "Select between trend change intra-bar or at the bar close", GroupName = "Algorithmic Options", Order = 3)]
        public bool ReverseIntraBar
        {
            get { return reverseIntraBar; }
            set { reverseIntraBar = value; }
        }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Baseline period", Description = "Sets the lookback period for the baseline", GroupName = "Input Parameters", Order = 0)]
		public int BasePeriod
		{	
            get { return basePeriod; }
            set { basePeriod = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Offset period", Description = "Sets the lookback period for the volatility measure", GroupName = "Input Parameters", Order = 1)]
		public int RangePeriod
		{	
            get { return volaPeriod; }
            set { volaPeriod = value; }
		}
			
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Offset multiplier", Description = "Sets the multiplier for the volatility offset", GroupName = "Input Parameters", Order = 2)]
		public double Multiplier
		{	
            get { return multiplier; }
            set { multiplier = value; }
		}
		#endregion
	}
}
