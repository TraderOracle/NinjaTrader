//+----------------------------------------------------------------------------------------------+
//| Copyright © <2021>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Core;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators.LizardIndicators;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points. 
	/// The indicator was introduced by Dr. Alexander Elder in his classic book 'Trading for a Living'. This version of the indicator comes with two additional options.
	/// It may be calculated from relative volume instead of absolute volume. Furthermore there is an option to show the Force Index normalized over a set lookback period.
	[Gui.CategoryOrder("Volume Input", 1000100)]
	[Gui.CategoryOrder("Algorithmic Options", 1000200)]
	[Gui.CategoryOrder("Input Parameters", 1000300)]
	[Gui.CategoryOrder("Display Options", 1000400)]
	[Gui.CategoryOrder("Plot Colors", 8000100)]
	[Gui.CategoryOrder("Plot Parameters", 8000200)]
	[Gui.CategoryOrder("Lines", 8000300)]
	[Gui.CategoryOrder("Version", 8000400)]
	[TypeConverter("NinjaTrader.NinjaScript.Indicators.amaForceIndexTypeConverter")]
	public class amaForceIndex : Indicator
	{
		private int 							period 						= 13;
		private int								normalizationPeriod			= 26;
		private int								days						= 40;
		private int 							weeks						= 8;
		private int 							upperThreshold				= 120;
		private int 							lowerThreshold				= 80;
		private int								displacement				= 0;
		private int								totalBarsRequiredToPlot		= 0;
		private double 							constant1					= 0.0;
		private double 							constant2					= 0.0;
		private double 							upperlineValue				= 2.5;
		private double 							lowerlineValue				= -2.5;
		private double							currentInput				= 0.0;
		private double							priorInput					= 0.0;
		private double 							priorMean					= 0.0;
		private double							priorSquareMean				= 0.0;
		private double							variance					= 0.0;
		private bool							normalizeOscillator			= false;
		private bool							showForceIndex				= true;
		private bool							showForceIndexAsArea		= true;
		private bool							breakAtEOD					= true;
		private bool							calculateFromPriceData		= true;
		private bool							errorMessage				= false;
		private bool							basicError					= false;
		private bool							sundaySessionError			= false;
		private DateTime						sessionDateTmp				= Globals.MinDate;
		private DateTime						cacheSessionEndTmp			= Globals.MinDate;
		private DateTime						lastBarTimeStamp			= Globals.MinDate;
		private DateTime						currentDate					= Globals.MinDate;
		private amaForceIndexType				volumeType					= amaForceIndexType.Absolute_Volume;
		private amaRVCalcMode					calcMode					= amaRVCalcMode.All_Days;
		private SessionIterator					sessionIterator				= null;
		private System.Windows.Media.Brush		bullishBrush				= Brushes.Navy;
		private System.Windows.Media.Brush		bearishBrush				= Brushes.Maroon;
		private System.Windows.Media.Brush		bullishAreaBrush			= Brushes.LightSkyBlue;
		private System.Windows.Media.Brush		bearishAreaBrush			= Brushes.Red;
		private System.Windows.Media.Brush		bullishAreaBrushOpaque		= null;
		private System.Windows.Media.Brush		bearishAreaBrushOpaque		= null;
		private System.Windows.Media.Brush		zerolineBrush				= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		upperlineBrush				= Brushes.Maroon;
		private System.Windows.Media.Brush		lowerlineBrush				= Brushes.Navy;
		private System.Windows.Media.Brush		errorBrush					= Brushes.Black;
		private	SharpDX.Direct2D1.Brush 		bullishBrushDX;
		private	SharpDX.Direct2D1.Brush 		bearishBrushDX;
		private	SharpDX.Direct2D1.Brush 		bullishAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		bearishAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		zerolineBrushDX;
		private	SharpDX.Direct2D1.Brush 		upperlineBrushDX;
		private	SharpDX.Direct2D1.Brush 		lowerlineBrushDX;
		private SimpleFont						errorFont;
		private string							errorText1					= "The amaForceIndex indicator can only be used with relative volume when applied to minute, daily or weekly bars.";
		private string							errorText2					= "Please set the amaForceIndex indicator to calculation mode 'All_Days' when used with relative volume and weekly data.";
		private string							errorText3					= "The amaForceIndex indicator cannot be used with relative volume when the 'Break at EOD' data series property is unselected.";
		private string							errorText4					= "The amaForceIndex cannot be used with a negative displacement.";
		private string							errorText5					= "When set to 'All_Days', the amaForceIndex indicator can only be used with session templates adapted to the trading hours of the instrument.";
		private string							errorText6					= "amaForceIndex: Insufficient historical data. Please increase chart lookback period to calculate relative volume.";
		private PlotStyle						plot0Style					= PlotStyle.Line;
		private DashStyleHelper					dash0Style					= DashStyleHelper.Solid;
		private int								plot0Width					= 1;
		private DashStyleHelper					line0Style					= DashStyleHelper.Solid;
		private int								line0Width					= 1;
		private DashStyleHelper					line1Style					= DashStyleHelper.Solid;
		private int								line1Width					= 1;
		private DashStyleHelper					line2Style					= DashStyleHelper.Solid;
		private int								line2Width					= 1;
		private int								areaOpacity					= 65;
		private Series<double>					force;
		private Series<double>					rawForceIndex;
		private Series<double>					forceUpDown;
		private Series<double>					squares;
		private Series<double>					mean;
		private Series<double>					squareMean;
		private amaRelativeVolume				relativeVolume;
		private string							versionString				= "v 1.5  - February 26, 2021";

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\n  The Force Index is an indicator that uses price and volume to assess the power behind a move or identify possible turning points. The indicator" 
												+ " was introduced by Dr. Alexander Elder in his classic book 'Trading for a Living'. This version of the indicator comes with two additional options."
												+ " It may be calculated from relative volume instead of absolute volume. Furthermore there is an option to show the Force Index normalized over a set lookback period.";
				Name						= "amaForceIndex";
				IsSuspendedWhileInactive	= true;
				ArePlotsConfigurable		= false;
				AreLinesConfigurable		= false;
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "Force Index");
				AddLine(new Stroke(Brushes.Gray, 1), 0, "Zeroline");
				AddLine(new Stroke(Brushes.Gray, 1), 2, "Upper Line");
				AddLine(new Stroke(Brushes.Gray, 1), -2, "Lower Line");
			}
			else if (State == State.Configure)
			{
				displacement = Displacement;
				BarsRequiredToPlot = period + normalizationPeriod;
				totalBarsRequiredToPlot = Math.Max(0, BarsRequiredToPlot + displacement);
				if(Calculate == Calculate.OnPriceChange)
					Calculate = Calculate.OnEachTick;
				Plots[0].PlotStyle = plot0Style;
				Plots[0].DashStyleHelper = dash0Style;
				Plots[0].Width = plot0Width;
				Lines[0].Brush = zerolineBrush;
				Lines[0].DashStyleHelper = line0Style;
				Lines[0].Width = line0Width;
				if(normalizeOscillator)
				{	
					Lines[1].Value = upperlineValue;
					Lines[1].Brush = upperlineBrush;
					Lines[1].DashStyleHelper = line1Style;
					Lines[1].Width = line1Width;
					Lines[2].Value = lowerlineValue;
					Lines[2].Brush = lowerlineBrush;
					Lines[2].DashStyleHelper = line2Style;
					Lines[2].Width = line2Width;
				}
				else
				{
					Lines[1].Brush = Brushes.Transparent;
					Lines[2].Brush = Brushes.Transparent;
				}	
				bullishAreaBrushOpaque = bullishAreaBrush.Clone(); ;
				bullishAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				bullishAreaBrushOpaque.Freeze();
				bearishAreaBrushOpaque = bearishAreaBrush.Clone(); 
				bearishAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				bearishAreaBrushOpaque.Freeze();
			}	
			else if (State == State.DataLoaded)
			{	
				force = new Series<double>(this, MaximumBarsLookBack.Infinite);
				rawForceIndex = new Series<double>(this, MaximumBarsLookBack.Infinite);
				forceUpDown = new Series<double>(this, MaximumBarsLookBack.Infinite);
				squares = new Series<double>(this, NormalizationPeriod < 250 ? MaximumBarsLookBack.TwoHundredFiftySix : MaximumBarsLookBack.Infinite);
				mean = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				squareMean = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				if(volumeType == amaForceIndexType.Relative_Volume)
					relativeVolume = amaRelativeVolume(calcMode, days, weeks, 120, 80);
				if(Input is PriceSeries)
					calculateFromPriceData = true;
				else
					calculateFromPriceData = false;
		    	sessionIterator = new SessionIterator(Bars);
			}
			else if (State == State.Historical)
			{
				constant1 = 2.0 / (1 + period);
				constant2 = 1 - (2.0 / (1 + period));
				bullishAreaBrushOpaque = bullishAreaBrush.Clone(); ;
				bullishAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				bullishAreaBrushOpaque.Freeze();
				bearishAreaBrushOpaque = bearishAreaBrush.Clone(); 
				bearishAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				bearishAreaBrushOpaque.Freeze();
				if(ChartBars != null)
				{	
					breakAtEOD = ChartBars.Bars.IsResetOnNewTradingDay;
					errorBrush = ChartControl.Properties.AxisPen.Brush;
					errorBrush.Freeze();
					errorFont = new SimpleFont("Arial", 24);
					if(volumeType == amaForceIndexType.Relative_Volume && Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Minute && Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Day 
						&& Bars.BarsPeriod.BarsPeriodType != BarsPeriodType.Week)
					{
						Draw.TextFixed(this, "error text 1", errorText1, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
						errorMessage = true;
						basicError = true;
					}
					else if (Bars.BarsPeriod.BarsPeriodType == BarsPeriodType.Week && calcMode == amaRVCalcMode.Day_Of_Week)
					{
						Draw.TextFixed(this, "error text 2", errorText2, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
						errorMessage = true;
						basicError = true;
					}
					else if(volumeType == amaForceIndexType.Relative_Volume && !breakAtEOD)
					{
						Draw.TextFixed(this, "error text 3", errorText3, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
						errorMessage = true;
						basicError = true;
					}
					else if(displacement < 0)
					{
						Draw.TextFixed(this, "error text 4", errorText4, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
						errorMessage = true;
						basicError = true;
					}
				}	
			}		
		}

		protected override void OnBarUpdate()
		{
			if(IsFirstTickOfBar)
			{	
				if(errorMessage)
				{	
					if(basicError)
						return;
					else if(sundaySessionError)
					{	
						Draw.TextFixed(this, "error text 5", errorText5, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);
						return;
					}	
				}
				
				if(calcMode == amaRVCalcMode.All_Days)
				{	
					lastBarTimeStamp = GetLastBarSessionDate(Time[0]);
					if(lastBarTimeStamp > currentDate)
					{	
						if(lastBarTimeStamp.DayOfWeek == DayOfWeek.Sunday)
						{
							sundaySessionError = true;
							errorMessage = true;
							return;
						}
						currentDate = lastBarTimeStamp;
					}
				}
			}
			else if(errorMessage)
				return;
			
			if(CurrentBar == 0)
			{	
				force[0] = 0.0;
				rawForceIndex[0] = 0.0;
				if(normalizeOscillator)
				{
					squares[0] = 0.0;
					mean[0] = 0.0;
					squareMean[0] = 0.0;
				}	
				ForceIndex.Reset();
				forceUpDown[0] = 0.0;
			}
			else if(volumeType == amaForceIndexType.Absolute_Volume)
			{
				if(calculateFromPriceData)
					force[0] = Volume[0] * (Close[0]- Close[1]);
				else	
					force[0] = Volume[0] * (Input[0]- Input[1]);
				if(normalizeOscillator)
				{	
					rawForceIndex[0] = force[0] * constant1 + constant2 * rawForceIndex[1];
					currentInput = rawForceIndex[0];
					if(IsFirstTickOfBar)
					{
						priorMean = mean[1];
						priorSquareMean = squareMean[1];
					}	
					squares[0] = currentInput * currentInput;
					if(CurrentBar < normalizationPeriod)
					{
						mean[0] = (CurrentBar * priorMean + currentInput)/(CurrentBar + 1);
						squareMean[0] = (CurrentBar * priorSquareMean + squares[0])/(CurrentBar + 1);
					}
					else
					{
						priorInput = rawForceIndex[normalizationPeriod];
						mean[0] = priorMean + (currentInput - priorInput)/normalizationPeriod;
						squareMean[0] = priorSquareMean + (squares[0] - squares[normalizationPeriod])/normalizationPeriod;
					}	
					variance = squareMean[0] - mean[0] * mean[0];
					if(variance.ApproxCompare(0) > 0)
						ForceIndex[0] = (currentInput - mean[0])/Math.Sqrt(variance);
					else
						ForceIndex[0] = 0.0;
				}	
				else	
					ForceIndex[0] = force[0] * constant1 + constant2 * ForceIndex[1];
				if(ForceIndex[0] > 0)
				{	
					forceUpDown[0] = 1.0;
					PlotBrushes[0][0] = bullishBrush;
				}	
				else if(ForceIndex[0] < 0)
				{	
					forceUpDown[0] = -1.0;
					PlotBrushes[0][0] = bearishBrush;
				}	
				else
				{	
					forceUpDown[0] = forceUpDown[1];
					PlotBrushes[0][0] = PlotBrushes[0][1];
				}	
			}	
			else if(volumeType == amaForceIndexType.Relative_Volume && relativeVolume.IsValidDataPoint(0))
			{
				if(calculateFromPriceData)
					force[0] = relativeVolume[0] * (Close[0]- Close[1]);
				else
					force[0] = relativeVolume[0] * (Input[0]- Input[1]);
				if(normalizeOscillator)
				{	
					rawForceIndex[0] = force[0] * constant1 + constant2 * rawForceIndex[1];
					currentInput = rawForceIndex[0];
					if(IsFirstTickOfBar)
					{
						priorMean = mean[1];
						priorSquareMean = squareMean[1];
					}	
					squares[0] = currentInput * currentInput;
					if(CurrentBar < normalizationPeriod)
					{
						mean[0] = (CurrentBar * priorMean + currentInput)/(CurrentBar + 1);
						squareMean[0] = (CurrentBar * priorSquareMean + squares[0])/(CurrentBar + 1);
					}
					else
					{
						priorInput = rawForceIndex[normalizationPeriod];
						mean[0] = priorMean + (currentInput - priorInput)/normalizationPeriod;
						squareMean[0] = priorSquareMean + (squares[0] - squares[normalizationPeriod])/normalizationPeriod;
					}	
					variance = squareMean[0] - mean[0] * mean[0];
					if(variance.ApproxCompare(0) > 0)
						ForceIndex[0] = (currentInput - mean[0])/Math.Sqrt(variance);
					else
						ForceIndex[0] = 0.0;
				}	
				else	
					ForceIndex[0] = force[0] * constant1 + constant2 * ForceIndex[1];
				if(ForceIndex[0] > 0)
				{	
					forceUpDown[0] = 1.0;
					PlotBrushes[0][0] = bullishBrush;
				}	
				else if(ForceIndex[0] < 0)
				{	
					forceUpDown[0] = -1.0;
					PlotBrushes[0][0] = bearishBrush;
				}	
				else
				{	
					forceUpDown[0] = forceUpDown[1];
					PlotBrushes[0][0] = PlotBrushes[0][1];
				}	
			}	
			else
			{	
				force[0] = 0.0;
				rawForceIndex[0] = 0.0;
				if(normalizeOscillator)
				{
					squares[0] = 0.0;
					mean[0] = 0.0;
					squareMean[0] = 0.0;
				}	
				ForceIndex.Reset();
				forceUpDown[0] = 0.0;
			}	
		}

		#region Properties
		
        [Browsable(false)]	
        [XmlIgnore()]		
        public Series<double> ForceIndex
        {
            get { return Values[0]; }
        }
		
        [Browsable(false)]	
        [XmlIgnore()]		
        public Series<double> ForceUpDown
        {
            get { return forceUpDown; }
        }
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Volume base", Description = "Select between absolute and relative volume", GroupName = "Volume Input", Order = 0)]
 		[RefreshProperties(RefreshProperties.All)] 
		public amaForceIndexType VolumeType
		{	
            get { return volumeType; }
            set { volumeType = value; }
		}
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Calculation mode", Description = "Select between comparing current volume to average volume of all days or same day of week only", GroupName = "Volume Input", Order = 1)]
 		[RefreshProperties(RefreshProperties.All)] 
		public amaRVCalcMode CalcMode
		{	
            get { return calcMode; }
            set { calcMode = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Reference period in days",  Description = "Sets the reference period which is used for calculating relative volume", GroupName = "Volume Input", Order = 2)]
		public int Days
		{
			get { return days; }
			set { days = Math.Max(1, value); }
		}

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Reference period in weeks", Description = "Sets the reference period which is used for calculating relative volume", GroupName = "Volume Input", Order = 3)]
		public int Weeks
		{
			get { return weeks; }
			set { weeks = Math.Max(1, value); }
		}

		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Normalize oscillator", Description = "Indicator will be normalized when set to 'true'", GroupName = "Algorithmic Options", Order = 0)]
 		[RefreshProperties(RefreshProperties.All)] 
		public bool NormalizeOscillator
		{	
            get { return normalizeOscillator; }
            set { normalizeOscillator = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Indicator period", Description = "Lookback period used for the force index", GroupName = "Input Parameters", Order = 0)]
		public int Period
		{	
            get { return period; }
            set { period = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Normalization period", Description = "Lookback period used for normalizing the force index", GroupName = "Input Parameters", Order = 1)]
		public int NormalizationPeriod
		{	
            get { return normalizationPeriod; }
            set { normalizationPeriod = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show force index", Description = "Shows plot for force index", GroupName = "Display Options", Order = 0)]
        public bool ShowForceIndex
        {
            get { return showForceIndex; }
            set { showForceIndex = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show shaded area", Description = "Shows force index as shaded area", GroupName = "Display Options", Order = 1)]
        public bool ShowForceIndexAsArea
        {
            get { return showForceIndexAsArea; }
            set { showForceIndexAsArea = value; }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Force index bullish", Description = "Sets the color for the force index when bullish", GroupName = "Plot Colors", Order = 0)]
		public System.Windows.Media.Brush BullishBrush
		{ 
			get {return bullishBrush;}
			set {bullishBrush = value;}
		}

		[Browsable(false)]
		public string BullishBrushSerializable
		{
			get { return Serialize.BrushToString(bullishBrush); }
			set { bullishBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Force index bearish", Description = "Sets the color for the force index when bearish", GroupName = "Plot Colors", Order = 1)]
		public System.Windows.Media.Brush BearishBrush
		{ 
			get {return bearishBrush;}
			set {bearishBrush = value;}
		}

		[Browsable(false)]
		public string BearishBrushSerializable
		{
			get { return Serialize.BrushToString(bearishBrush); }
			set { bearishBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish shading", Description = "Sets the color for bullish areas", GroupName = "Plot Colors", Order = 2)]
		public System.Windows.Media.Brush BullishAreaBrush
		{ 
			get {return bullishAreaBrush;}
			set {bullishAreaBrush = value;}
		}

		[Browsable(false)]
		public string BullishAreaBrushSerializable
		{
			get { return Serialize.BrushToString(bullishAreaBrush); }
			set { bullishAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish shading", Description = "Sets the color for bearish areas", GroupName = "Plot Colors", Order = 3)]
		public System.Windows.Media.Brush BearishAreaBrush
		{ 
			get {return bearishAreaBrush;}
			set {bearishAreaBrush = value;}
		}

		[Browsable(false)]
		public string BearishAreaBrushSerializable
		{
			get { return Serialize.BrushToString(bearishAreaBrush); }
			set { bearishAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot style", Description = "Sets the plot style for the force index", GroupName = "Plot Parameters", Order = 0)]
		public PlotStyle Plot0Style
		{	
            get { return plot0Style; }
            set { plot0Style = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style", Description = "Sets the dash style for the force index", GroupName = "Plot Parameters", Order = 1)]
		public DashStyleHelper Dash0Style
		{
			get { return dash0Style; }
			set { dash0Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width", Description = "Sets the plot width for the force index", GroupName = "Plot Parameters", Order = 2)]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
			
		[Range(0, 100)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Area opacity", Description = "Sets the opacity for the areas below and above the zeroline", GroupName = "Plot Parameters", Order = 3)]
		public int AreaOpacity
		{	
            get { return areaOpacity; }
            set { areaOpacity = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Zeroline", Description = "Sets the color for the zeroline", GroupName = "Lines", Order = 0)]
		public System.Windows.Media.Brush ZerolineBrush
		{ 
			get {return zerolineBrush;}
			set {zerolineBrush = value;}
		}

		[Browsable(false)]
		public string ZerolineBrushSerializable
		{
			get { return Serialize.BrushToString(zerolineBrush); }
			set { zerolineBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dashstyle zeroline", Description = "Sets the dash style for the zeroline", GroupName = "Lines", Order = 1)]
		public DashStyleHelper Line0Style
		{	
            get { return line0Style; }
            set { line0Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Width zeroline", Description = "Sets the width for the zeroline", GroupName = "Lines", Order = 2)]
		public int Line0Width
		{	
            get { return line0Width; }
            set { line0Width = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upper line", Description = "Sets the color for the upper line", GroupName = "Lines", Order = 3)]
		public System.Windows.Media.Brush UpperlineBrush
		{ 
			get {return upperlineBrush;}
			set {upperlineBrush = value;}
		}

		[Browsable(false)]
		public string UpperlineBrushSerializable
		{
			get { return Serialize.BrushToString(upperlineBrush); }
			set { upperlineBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upper line value", Description = "Sets the the numerical value for the upper line", GroupName = "Lines", Order = 4)]
		public double UpperlineValue
		{	
            get { return upperlineValue; }
            set { upperlineValue = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dashstyle upper line", Description = "Sets the dash style for the upper line", GroupName = "Lines", Order = 5)]
		public DashStyleHelper Line1Style
		{	
            get { return line1Style; }
            set { line1Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Width upper line", Description = "Sets the width for the upper", GroupName = "Lines", Order = 6)]
		public int Line1Width
		{	
            get { return line1Width; }
            set { line1Width = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Lower line", Description = "Sets the color for the lower line", GroupName = "Lines", Order = 7)]
		public System.Windows.Media.Brush LowerlineBrush
		{ 
			get {return lowerlineBrush;}
			set {lowerlineBrush = value;}
		}

		[Browsable(false)]
		public string LowerlineBrushSerializable
		{
			get { return Serialize.BrushToString(lowerlineBrush); }
			set { lowerlineBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(double.MinValue, 0), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Lower line value", Description = "Sets the the numerical value for the lower line", GroupName = "Lines", Order = 8)]
		public double LowerlineValue
		{	
            get { return lowerlineValue; }
            set { lowerlineValue = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dashstyle lower line", Description = "Sets the dash style for the lower line", GroupName = "Lines", Order = 9)]
		public DashStyleHelper Line2Style
		{	
            get { return line2Style; }
            set { line2Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Width lower line", Description = "Sets the width for the lower line", GroupName = "Lines", Order = 10)]
		public int Line2Width
		{	
            get { return line2Width; }
            set { line2Width = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
		
		#region Miscellaneous
		
		private DateTime GetLastBarSessionDate(DateTime time)
		{
			if (time > cacheSessionEndTmp) 
			{
				if (Bars.BarsType.IsIntraday)
				{	
					sessionIterator.CalculateTradingDay(time, true);
					sessionDateTmp = sessionIterator.ActualTradingDayExchange;
					cacheSessionEndTmp = sessionIterator.ActualSessionEnd;
				}	
				else
				{	
					sessionDateTmp = time.Date;
					cacheSessionEndTmp = time.Date;
				}	
			}
			return sessionDateTmp;			
		}		
		
		public override void OnRenderTargetChanged()
		{
			if (bullishBrushDX != null)
				bullishBrushDX.Dispose();
			if (bearishBrushDX != null)
				bearishBrushDX.Dispose();
			if (bullishAreaBrushDX != null)
				bullishAreaBrushDX.Dispose();
			if (bearishAreaBrushDX != null)
				bearishAreaBrushDX.Dispose();
			if (zerolineBrushDX != null)
				zerolineBrushDX.Dispose();
			if (upperlineBrushDX != null)
				upperlineBrushDX.Dispose();
			if (lowerlineBrushDX != null)
				lowerlineBrushDX.Dispose();
			
			if (RenderTarget != null)
			{
				try
				{
					bullishBrushDX 	= bullishBrush.ToDxBrush(RenderTarget);
					bearishBrushDX = bearishBrush.ToDxBrush(RenderTarget);
					bullishAreaBrushDX 	= bullishAreaBrushOpaque.ToDxBrush(RenderTarget);
					bearishAreaBrushDX = bearishAreaBrushOpaque.ToDxBrush(RenderTarget);
					zerolineBrushDX = zerolineBrush.ToDxBrush(RenderTarget);
					upperlineBrushDX = upperlineBrush.ToDxBrush(RenderTarget);
					lowerlineBrushDX = lowerlineBrush.ToDxBrush(RenderTarget);
				}
				catch (Exception e) { }
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (Bars == null || ChartControl == null || ChartBars.ToIndex < BarsRequiredToPlot || !IsVisible) return;
			int	lastBarPainted = ChartBars.ToIndex;
			if(lastBarPainted  < 0 || BarsArray[0].Count < lastBarPainted) return;
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
	        ChartPanel panel = chartControl.ChartPanels[ChartPanel.PanelIndex];
			
			bool nonEquidistant 	= (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti);
			int lastBarCounted		= Input.Count - 1;
			int	lastBarOnUpdate		= lastBarCounted - (Calculate == Calculate.OnBarClose ? 1 : 0);
			int	lastBarIndex		= Math.Min(lastBarPainted, lastBarOnUpdate);
			int firstBarPainted	 	= ChartBars.FromIndex;
			int firstBarIndex  	 	= Math.Max(totalBarsRequiredToPlot, firstBarPainted);
			int lastIndex			= 0;
			int x 					= 0;
			int y0	 				= 0;
			int y1 					= 0;
			int yUpper 				= 0;
			int yLower 				= 0;
			int y 					= 0;
			int t					= 0;
			int lastX 				= 0;
			int lastY0 				= 0;
			int lastY1 				= 0;
			int lastY2 				= 0;
			int lastY 				= 0;
			int sign 				= 0;
			int lastSign 			= 0;
			int startBar 			= 0;
			int priorStartBar 		= 0;
			int returnBar 			= 0;
			int count	 			= 0;
			double barWidth			= 0;
			bool firstLoop 			= true;
			SharpDX.Vector2 startPointDX;
			SharpDX.Vector2 endPointDX;
			Vector2[] plotArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			
			if(volumeType == amaForceIndexType.Relative_Volume)
			{	
				if (!ForceIndex.IsValidDataPointAt(lastBarIndex))
				{
					if(!errorMessage)
					{	
						SharpDX.Direct2D1.Brush errorBrushDX = errorBrush.ToDxBrush(RenderTarget);
						TextFormat textFormat2 = new TextFormat(Globals.DirectWriteFactory, "Arial", 20.0f);		
						SharpDX.DirectWrite.TextLayout textLayout2 = new SharpDX.DirectWrite.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, errorText6, textFormat2, 1000, 20.0f);
						SharpDX.Vector2 lowerTextPoint = new SharpDX.Vector2(ChartPanel.W/2 - textLayout2.Metrics.Width/2, ChartPanel.Y + (ChartPanel.H/2)); 
						RenderTarget.DrawTextLayout(lowerTextPoint, textLayout2, errorBrushDX, SharpDX.Direct2D1.DrawTextOptions.NoSnap);
						errorBrushDX.Dispose();
						textFormat2.Dispose();
						textLayout2.Dispose();
					}	
					return;
				}
				else if(lastBarCounted == firstBarPainted) 
					return;
				else
					while (!ForceIndex.IsValidDataPointAt(firstBarIndex))
					 	firstBarIndex = firstBarIndex + 1;	
			}
			
			if(lastBarIndex + displacement > firstBarIndex)
			{	
				if (displacement >= 0)
					lastIndex = lastBarIndex + displacement;
				else
					lastIndex = Math.Min(lastBarIndex, lastBarOnUpdate + displacement);
				if(nonEquidistant && lastIndex > lastBarOnUpdate)
					barWidth = Convert.ToDouble(ChartControl.GetXByBarIndex(ChartBars, lastBarPainted) - ChartControl.GetXByBarIndex(ChartBars, lastBarPainted - displacement))/displacement;
				lastY0	= chartScale.GetYByValue(ForceIndex.GetValueAt(lastIndex - displacement));
				y0  = chartScale.GetYByValue(0.0);
				yUpper  = chartScale.GetYByValue(upperlineValue);
				yLower  = chartScale.GetYByValue(lowerlineValue);
				lastSign = (int) ForceUpDown.GetValueAt(lastIndex - displacement);
				
				//Lines
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)y0);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)y0);
				RenderTarget.DrawLine(startPointDX, endPointDX, zerolineBrushDX, line0Width, Lines[0].StrokeStyle);
				if(normalizeOscillator)
				{	
					startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yUpper);
					endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yUpper);
					RenderTarget.DrawLine(startPointDX, endPointDX, upperlineBrushDX, line1Width, Lines[1].StrokeStyle);
					startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yLower);
					endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yLower);
					RenderTarget.DrawLine(startPointDX, endPointDX, lowerlineBrushDX, line2Width, Lines[2].StrokeStyle);
				}	
				
				//Plots
				if(showForceIndexAsArea)
				{	
					lastY = lastY0;
					startBar = lastIndex;
					firstLoop = true;
					do
					{
						SharpDX.Direct2D1.PathGeometry 	pathF;
						SharpDX.Direct2D1.GeometrySink 	sinkF;
						pathF = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (pathF)
						{
							priorStartBar = startBar;
							if(firstLoop)
							{	
								count = 0;						
								if(nonEquidistant && displacement > 0 && startBar > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((startBar - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, startBar);
								plotArray[count] = new Vector2(x, y0);
							}	
							else
							{	
								count = 0;
								plotArray[count] = new Vector2(lastX, lastY);
							}
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(ForceIndex.GetValueAt(idx - displacement));   
								t = (int) ForceUpDown.GetValueAt(idx - displacement);
								count = count + 1;
								if(t == lastSign)
								{
									plotArray[count] = new Vector2(x,y);
									sign = t;
									startBar = idx;
									lastX = x;
									lastY = y;
								}	
								else
								{	
									double lastDiff = Convert.ToDouble(y0 - lastY);
									double diff = Convert.ToDouble(y0 - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = y0;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
							}
							if(startBar == firstBarIndex)
							{
								count = count + 1;
								plotArray[count] = new Vector2(lastX, y0);
							}	
							sinkF = pathF.Open();
							sinkF.BeginFigure(plotArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sinkF.AddLine(plotArray[i]);
							sinkF.EndFigure(FigureEnd.Closed);
			        		sinkF.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
							if(sign == 1)
		 						RenderTarget.FillGeometry(pathF, bullishAreaBrushDX);
							else if(sign == -1) 
		 						RenderTarget.FillGeometry(pathF, bearishAreaBrushDX);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						pathF.Dispose();
						sinkF.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex && ForceIndex.IsValidDataPointAt(startBar - displacement));
				}
				
				if(showForceIndex)
				{	
					lastY = lastY0;
					lastSign = 0;
					startBar = lastIndex;
					firstLoop = true;
					do
					{
						SharpDX.Direct2D1.PathGeometry 	pathE;
						SharpDX.Direct2D1.GeometrySink 	sinkE;
						pathE = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (pathE)
						{
							priorStartBar = startBar;
							if(firstLoop)
							{	
								count = 0;						
								if(nonEquidistant && displacement > 0 && startBar > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((startBar - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, startBar);
								plotArray[count] = new Vector2(x, y0);
							}
							if(firstLoop)
								count = -1;
							else
							{	
								count = 0;
								plotArray[count] = new Vector2(lastX, lastY);
							}
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(ForceIndex.GetValueAt(idx - displacement));   
								t = (int) ForceUpDown.GetValueAt(idx - displacement);
								count = count + 1;
								if(t == lastSign)
								{
									plotArray[count] = new Vector2(x,y);
									sign = t;
									startBar = idx;
									lastX = x;
									lastY = y;
								}	
								else if(lastSign == 0)
								{	
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else
								{	
									double lastDiff = Convert.ToDouble(y0 - lastY);
									double diff = Convert.ToDouble(y0 - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = y0;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
							}
							sinkE = pathE.Open();
							if(firstLoop)
								sinkE.BeginFigure(plotArray[1], FigureBegin.Filled);
							else
								sinkE.BeginFigure(plotArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sinkE.AddLine(plotArray[i]);
							sinkE.EndFigure(FigureEnd.Open);
			        		sinkE.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
							if(sign == 1)
		 						RenderTarget.DrawGeometry(pathE, bullishBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
							else if(sign == -1) 
		 						RenderTarget.DrawGeometry(pathE, bearishBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						pathE.Dispose();
						sinkE.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex && ForceIndex.IsValidDataPointAt(startBar - displacement));
				}
			}
		}		
		#endregion		
	}
}


namespace NinjaTrader.NinjaScript.Indicators
{		
	public class amaForceIndexTypeConverter : NinjaTrader.NinjaScript.IndicatorBaseConverter
	{
		public override bool GetPropertiesSupported(ITypeDescriptorContext context) { return true; }

		public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object value, Attribute[] attributes)
		{
			PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context) ? base.GetProperties(context, value, attributes) : TypeDescriptor.GetProperties(value, attributes);

			amaForceIndex				thisForceIndexInstance				= (amaForceIndex) value;
			bool						normalizeOscillatorFromInstance		= thisForceIndexInstance.NormalizeOscillator;
			amaForceIndexType			volumeTypeFromInstance				= thisForceIndexInstance.VolumeType;
			amaRVCalcMode				calcModeFromInstance				= thisForceIndexInstance.CalcMode;
			
			PropertyDescriptorCollection adjusted = new PropertyDescriptorCollection(null);
			
			foreach (PropertyDescriptor thisDescriptor in propertyDescriptorCollection)
			{
				if (!normalizeOscillatorFromInstance && (thisDescriptor.Name == "NormalizationPeriod" || thisDescriptor.Name == "UpperlineBrush" || thisDescriptor.Name == "UpperlineValue" || thisDescriptor.Name == "Line1Style" 
					|| thisDescriptor.Name == "Line1Width" || thisDescriptor.Name == "LowerlineBrush" || thisDescriptor.Name == "LowerlineValue" || thisDescriptor.Name == "Line2Style" || thisDescriptor.Name == "Line2Width"))
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (volumeTypeFromInstance == amaForceIndexType.Absolute_Volume && (thisDescriptor.Name == "CalcMode" || thisDescriptor.Name == "Weeks" || thisDescriptor.Name == "Days"))
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (calcModeFromInstance == amaRVCalcMode.All_Days && thisDescriptor.Name == "Weeks")
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else if (calcModeFromInstance == amaRVCalcMode.Day_Of_Week && thisDescriptor.Name == "Days")
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else	
					adjusted.Add(thisDescriptor);
			}
			return adjusted;
		}
	}
}

#region Public Enums
public enum amaForceIndexType 
{
	Absolute_Volume, 
	Relative_Volume,
}
#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaForceIndex[] cacheamaForceIndex;
		public LizardIndicators.amaForceIndex amaForceIndex(amaForceIndexType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool normalizeOscillator, int period, int normalizationPeriod, double upperlineValue, double lowerlineValue)
		{
			return amaForceIndex(Input, volumeType, calcMode, days, weeks, normalizeOscillator, period, normalizationPeriod, upperlineValue, lowerlineValue);
		}

		public LizardIndicators.amaForceIndex amaForceIndex(ISeries<double> input, amaForceIndexType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool normalizeOscillator, int period, int normalizationPeriod, double upperlineValue, double lowerlineValue)
		{
			if (cacheamaForceIndex != null)
				for (int idx = 0; idx < cacheamaForceIndex.Length; idx++)
					if (cacheamaForceIndex[idx] != null && cacheamaForceIndex[idx].VolumeType == volumeType && cacheamaForceIndex[idx].CalcMode == calcMode && cacheamaForceIndex[idx].Days == days && cacheamaForceIndex[idx].Weeks == weeks && cacheamaForceIndex[idx].NormalizeOscillator == normalizeOscillator && cacheamaForceIndex[idx].Period == period && cacheamaForceIndex[idx].NormalizationPeriod == normalizationPeriod && cacheamaForceIndex[idx].UpperlineValue == upperlineValue && cacheamaForceIndex[idx].LowerlineValue == lowerlineValue && cacheamaForceIndex[idx].EqualsInput(input))
						return cacheamaForceIndex[idx];
			return CacheIndicator<LizardIndicators.amaForceIndex>(new LizardIndicators.amaForceIndex(){ VolumeType = volumeType, CalcMode = calcMode, Days = days, Weeks = weeks, NormalizeOscillator = normalizeOscillator, Period = period, NormalizationPeriod = normalizationPeriod, UpperlineValue = upperlineValue, LowerlineValue = lowerlineValue }, input, ref cacheamaForceIndex);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaForceIndex amaForceIndex(amaForceIndexType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool normalizeOscillator, int period, int normalizationPeriod, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaForceIndex(Input, volumeType, calcMode, days, weeks, normalizeOscillator, period, normalizationPeriod, upperlineValue, lowerlineValue);
		}

		public Indicators.LizardIndicators.amaForceIndex amaForceIndex(ISeries<double> input , amaForceIndexType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool normalizeOscillator, int period, int normalizationPeriod, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaForceIndex(input, volumeType, calcMode, days, weeks, normalizeOscillator, period, normalizationPeriod, upperlineValue, lowerlineValue);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaForceIndex amaForceIndex(amaForceIndexType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool normalizeOscillator, int period, int normalizationPeriod, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaForceIndex(Input, volumeType, calcMode, days, weeks, normalizeOscillator, period, normalizationPeriod, upperlineValue, lowerlineValue);
		}

		public Indicators.LizardIndicators.amaForceIndex amaForceIndex(ISeries<double> input , amaForceIndexType volumeType, amaRVCalcMode calcMode, int days, int weeks, bool normalizeOscillator, int period, int normalizationPeriod, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaForceIndex(input, volumeType, calcMode, days, weeks, normalizeOscillator, period, normalizationPeriod, upperlineValue, lowerlineValue);
		}
	}
}

#endregion
