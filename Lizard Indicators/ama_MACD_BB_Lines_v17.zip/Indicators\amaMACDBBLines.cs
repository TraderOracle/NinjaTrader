//+----------------------------------------------------------------------------------------------+
//| Copyright © <2021>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	///  The MACDBBLines indicator is a standard MACD (moving average convergence divergence) indicator with Bollinger Bands added.
	/// </summary>
	[Gui.CategoryOrder("Input Parameters", 1000100)]
	[Gui.CategoryOrder("Display Options", 1000200)]
	[Gui.CategoryOrder("Plot Colors", 8000100)]
	[Gui.CategoryOrder("Plot Parameters", 8000200)]
	[Gui.CategoryOrder("Paint Bars - Upcloses", 8000300)]
	[Gui.CategoryOrder("Paint Bars - Downcloses", 8000400)]
	[Gui.CategoryOrder("Paint Bars - Outlines", 8000500)]
	[Gui.CategoryOrder("Zeroline", 8000600)]
	[Gui.CategoryOrder("Sound Alerts", 8000700)]
	[Gui.CategoryOrder("Version", 8000800)]
	public class amaMACDBBLines : Indicator
	{
		private int								fast						= 12;
		private int								slow						= 26;
		private int								bandPeriod 					= 10;
		private int								displacement				= 0;
		private int								totalBarsRequiredToPlot		= 0;
		private int								lookback					= 0;
		private double							stdDevMultiplier			= 1.0;
		private double							macdValue					= 0.0;
		private double							average						= 0.0;
		private double							stdDevValue					= 0.0;
		private double							upperValue					= 0.0;
		private double							lowerValue					= 0.0;
		private bool							showAverage					= true;
		private bool							showChannel					= true;
		private bool							channelFlooding				= true;
		private bool							showPaintBars				= true;
		private bool							showZerolineCrosses			= true;
		private bool							soundAlerts					= false;
		private bool							channelIsFilled				= true;
		private bool							upperViolation				= false;
		private bool							lowerViolation				= false;
		private bool							zerolineCrossFromBelow		= false;
		private bool							zerolineCrossFromAbove		= false;
		private SessionIterator					sessionIterator				= null;
		private int								channelOpacity				= 20;
		private int 							plot0Width 					= 2;
		private DashStyleHelper					dash0Style					= DashStyleHelper.Solid;
		private int 							plot1Width 					= 10;
		private DashStyleHelper					dash1Style					= DashStyleHelper.Dot;
		private int 							plot2Width 					= 1;
		private DashStyleHelper					dash2Style					= DashStyleHelper.Dash;
		private int 							plot3Width 					= 1;
		private DashStyleHelper					dash3Style					= DashStyleHelper.Solid;
		private int 							plot7Width 					= 2;
		private DashStyleHelper					dash6Style					= DashStyleHelper.Dot;
		private int 							zerolineWidth 				= 1;
		private DashStyleHelper					zerolineStyle				= DashStyleHelper.Solid;
		private System.Windows.Media.Brush		dotsUpOutside				= Brushes.Lime;
		private System.Windows.Media.Brush  	dotsUpInside				= Brushes.Yellow;
		private System.Windows.Media.Brush		dotsDownOutside				= Brushes.Red;
		private System.Windows.Media.Brush  	dotsDownInside				= Brushes.DarkOrange;
		private System.Windows.Media.Brush		dotsUpOutsideUpclose		= Brushes.Lime;
		private System.Windows.Media.Brush  	dotsUpInsideUpclose			= Brushes.Yellow;
		private System.Windows.Media.Brush		dotsDownOutsideUpclose		= Brushes.DarkRed;
		private System.Windows.Media.Brush  	dotsDownInsideUpclose		= Brushes.Chocolate;
		private System.Windows.Media.Brush		dotsUpOutsideDownclose		= Brushes.LimeGreen;
		private System.Windows.Media.Brush  	dotsUpInsideDownclose		= Brushes.Gold;
		private System.Windows.Media.Brush		dotsDownOutsideDownclose	= Brushes.Red;
		private System.Windows.Media.Brush  	dotsDownInsideDownclose		= Brushes.DarkOrange;
		private System.Windows.Media.Brush		dotsUpOutsideOutline		= Brushes.Black;
		private System.Windows.Media.Brush  	dotsUpInsideOutline			= Brushes.Black;
		private System.Windows.Media.Brush		dotsDownOutsideOutline		= Brushes.Black;
		private System.Windows.Media.Brush  	dotsDownInsideOutline		= Brushes.Black;
		private System.Windows.Media.Brush		dotFrame 					= Brushes.Black;
		private System.Windows.Media.Brush		connector 					= Brushes.Black;
		private System.Windows.Media.Brush		bbAverage 					= Brushes.MidnightBlue;
		private System.Windows.Media.Brush		bbUpper 					= Brushes.MidnightBlue;
		private System.Windows.Media.Brush		bbLower 					= Brushes.MidnightBlue;
		private System.Windows.Media.Brush		channelFillBrush			= Brushes.MidnightBlue;
		private System.Windows.Media.Brush		channelFillBrushS			= Brushes.MidnightBlue;
		private System.Windows.Media.Brush		zerolineCrossUp				= Brushes.DeepSkyBlue;
		private System.Windows.Media.Brush		zerolineCrossDown			= Brushes.MediumVioletRed;
		private System.Windows.Media.Brush		zerolineBrush				= Brushes.Black;
		private int								rearmTime					= 30;
		private string 							upperBandViolation			= "upperbandviolation.wav";
		private string 							lowerBandViolation			= "lowerbandviolation.wav";
		private string 							bullishZeroCross			= "bullishzerocross.wav";
		private string 							bearishZeroCross			= "bearishzerocross.wav";
		private string							pathUpperBandViolation		= "";
		private string							pathLowerBandViolation		= "";
		private string							pathBullishZeroCross		= "";
		private string							pathBearishZeroCross		= "";
		private string							versionString				= "v 1.7  -  February 26, 2021";
		private Series<double>					trend;
		private Series<double>					longSignal;
		private Series<double>					shortSignal;
		private MACD 							bMACD;
		private amaStdDev						stdDevBB;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\nThe MACDBBLines is a standard MACD (moving average convergence divergence) indicator with Bollinger Bands added.";
				Name						= "amaMACDBBLines";
				IsSuspendedWhileInactive	= false;
				IsOverlay					= false;
				ArePlotsConfigurable		= false;
				AreLinesConfigurable		= false;
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "BBMACD");
				AddPlot(new Stroke(Brushes.Gray, 8), PlotStyle.Dot, "Zeroline Cross");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "Average");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "Upper BB");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "Lower BB");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "BBMACDLine");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "BBMACDFrame");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "BBMACDDots");
				AddLine(new Stroke(Brushes.Black, 1), 0, "Zeroline");
			}
			else if (State == State.Configure)
			{
				displacement = Displacement;
				BarsRequiredToPlot	= Math.Max(bandPeriod + Math.Max(fast, slow), -displacement);
				totalBarsRequiredToPlot = Math.Max(0, BarsRequiredToPlot + displacement);
				Plots[0].Brush = connector.Clone();
				if(showAverage)
					Plots[2].Brush = bbAverage.Clone();
				else
					Plots[2].Brush = Brushes.Transparent;
				if(showChannel)
				{	
					Plots[3].Brush = bbUpper.Clone();
					Plots[4].Brush = bbLower.Clone();
				}
				else
				{	
					Plots[3].Brush = Brushes.Transparent;
					Plots[4].Brush = Brushes.Transparent;
				}
				Plots[5].Brush = connector.Clone();
				Plots[6].Brush = dotFrame.Clone();
				Plots[0].Width = plot0Width;
				Plots[0].DashStyleHelper = dash0Style;
				Plots[1].Width = plot1Width;
				Plots[1].DashStyleHelper = dash1Style;
				Plots[2].Width = plot2Width;
				Plots[2].DashStyleHelper = dash2Style;
				Plots[3].Width = plot3Width;
				Plots[3].DashStyleHelper = dash3Style;
				Plots[4].Width = plot3Width;
				Plots[4].DashStyleHelper = dash3Style;
				Plots[5].Width = plot0Width;
				Plots[5].DashStyleHelper = dash0Style;
				Plots[6].Width = plot7Width + 1;
				Plots[6].DashStyleHelper = dash6Style;
				Plots[7].Width = plot7Width;
				Plots[7].DashStyleHelper = dash6Style;
				Lines[0].Brush = zerolineBrush;
				Lines[0].Width = zerolineWidth;
				Lines[0].DashStyleHelper = zerolineStyle;
				channelFillBrush = channelFillBrushS.Clone();
				channelFillBrush.Opacity = (float) channelOpacity/100.0;
				channelFillBrush.Freeze();
			}
			else if (State == State.DataLoaded)
			{
				trend = new Series<double>(this, MaximumBarsLookBack.Infinite);
				longSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
				shortSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
				bMACD = MACD(Input, fast, slow, bandPeriod);
				stdDevBB = amaStdDev(bMACD, bandPeriod);
		    	sessionIterator = new SessionIterator(Bars);
			}	
			else if (State == State.Historical)
			{
				channelIsFilled = (channelFlooding && channelOpacity > 0);
				DrawOnPricePanel = false;
				pathUpperBandViolation = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, upperBandViolation);
				pathLowerBandViolation = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, lowerBandViolation);
				pathBullishZeroCross = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, bullishZeroCross);
				pathBearishZeroCross = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, bearishZeroCross);
				channelFillBrush = channelFillBrushS.Clone();
				channelFillBrush.Opacity = (float) channelOpacity/100.0;
				channelFillBrush.Freeze();
			}	
		}

		protected override void OnBarUpdate()
		{
			macdValue = bMACD[0];
			Values[0][0] = macdValue;
			BBMACD[0] = macdValue;
			average = bMACD.Avg[0];
			stdDevValue = stdDevBB[0];
			Average[0] = average;
			upperValue = average + stdDevMultiplier * stdDevValue;
			lowerValue = average - stdDevMultiplier * stdDevValue;
			UpperBB[0] = upperValue;
			LowerBB[0] = lowerValue;
			Values[5][0] = macdValue;
			Values[6][0] = macdValue;
			Values[7][0] = macdValue;
			
			if (CurrentBar < BarsRequiredToPlot)
			{	
				trend[0] = 0.0;
				return;
			}
			
			upperViolation = false;
			lowerViolation = false;
			zerolineCrossFromBelow = false;
			zerolineCrossFromAbove = false;
			
			if (macdValue > bMACD[1])
			{
				if(macdValue > upperValue)
				{
					PlotBrushes[7][0] = dotsUpOutside;
					trend[0] = 2.0;
					if(bMACD[1] <= UpperBB[1])
						upperViolation = true;
				}
				else
				{	
					PlotBrushes[7][0] = dotsUpInside;
					trend[0] = 1.0;
				}	
			}
			else if(bMACD[0] < bMACD[1])
			{
				if(macdValue < lowerValue)
				{
					PlotBrushes[7][0] = dotsDownOutside;
					trend[0] = -2.0;
					if (bMACD[1] >= LowerBB[1])
						lowerViolation = true;
				}
				else
				{	
					PlotBrushes[7][0] = dotsDownInside;
					trend[0] = -1.0;
				}	
			}
			else
			{	
				PlotBrushes[7][0] = PlotBrushes[7][1];
				trend[0] = trend[1];
			}
			
			if(upperViolation && macdValue > 0)
				longSignal[0] = 2.0;
			else if (upperViolation)
				longSignal[0] = 1.0;
			else
				longSignal[0] = 0.0;
			if(lowerViolation && macdValue < 0)
				shortSignal[0] = 2.0;
			else if (lowerViolation)
				shortSignal[0] = 1.0;
			else
				shortSignal[0] = 0.0;
			
			if (bMACD[0] > 0)
			{
				if (bMACD[1] <= 0)
				{
					Values[1][0] = 0.0;
					if(showZerolineCrosses)
						PlotBrushes[1][0] = zerolineCrossUp;
					else
						PlotBrushes[1][0] = Brushes.Transparent;
					zerolineCrossFromBelow = true;	
				}
				else
					Values[1].Reset();
			}
			else if (bMACD[0] < 0)
			{
				if (bMACD[1] >= 0)
				{
					Values[1][0] = 0.0;
					if(showZerolineCrosses)
						PlotBrushes[1][0] = zerolineCrossDown;
					else
						PlotBrushes[1][0] = Brushes.Transparent;
					zerolineCrossFromAbove = true;
				}
				else
					Values[1].Reset();
			}
			
			if(showPaintBars && CurrentBar >= totalBarsRequiredToPlot)
			{
				if(displacement >= 0)
				{
					if(trend[displacement] > 1.5)
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = dotsUpOutsideUpclose;
						else
							BarBrushes[0] = dotsUpOutsideDownclose;
						CandleOutlineBrushes[0] = dotsUpOutsideOutline;
					}	
					else if(trend[displacement] > 0.5)
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = dotsUpInsideUpclose;
						else
							BarBrushes[0] = dotsUpInsideDownclose;
						CandleOutlineBrushes[0] = dotsUpInsideOutline;
					}	
					else if(trend[displacement] < -1.5)
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = dotsDownOutsideUpclose;
						else
							BarBrushes[0] = dotsDownOutsideDownclose;
						CandleOutlineBrushes[0] = dotsDownOutsideOutline;
					}	
					else if(trend[displacement] < -0.5)
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = dotsDownInsideUpclose;
						else
							BarBrushes[0] = dotsDownInsideDownclose;
						CandleOutlineBrushes[0] = dotsDownInsideOutline;
					}	
					else
					{
						if(Open[0] < Close[0])
							BarBrushes[0] = Brushes.LightGray;
						else
							BarBrushes[0] = Brushes.Gray;
						CandleOutlineBrushes[0] = Brushes.DarkGray;
					}	
				}
				else 
				{
					if(trend[0] > 1.5)
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = dotsUpOutsideUpclose;
						else
							BarBrushes[-displacement] = dotsUpOutsideDownclose;
						CandleOutlineBrushes[-displacement] = dotsUpOutsideOutline;
					}	
					else if(trend[0] > 0.5)
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = dotsUpInsideUpclose;
						else
							BarBrushes[-displacement] = dotsUpInsideDownclose;
						CandleOutlineBrushes[-displacement] = dotsUpInsideOutline;
					}	
					else if(trend[0] < -1.5)
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = dotsDownOutsideUpclose;
						else
							BarBrushes[-displacement] = dotsDownOutsideDownclose;
						CandleOutlineBrushes[-displacement] = dotsDownOutsideOutline;
					}	
					else if(trend[0] < -0.5)
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = dotsDownInsideUpclose;
						else
							BarBrushes[-displacement] = dotsDownInsideDownclose;
						CandleOutlineBrushes[-displacement] = dotsDownInsideOutline;
					}	
					else
					{
						if(Open[-displacement] < Close[-displacement])
							BarBrushes[-displacement] = Brushes.LightGray;
						else
							BarBrushes[-displacement] = Brushes.Gray;
						CandleOutlineBrushes[-displacement] = Brushes.DarkGray;
					}					
				}
			}			
			if (soundAlerts && State == State.Realtime && IsConnected())
			{
				if(upperViolation)		
				{
					try
					{
							Alert("Upper_BB_Violation", Priority.Medium,"Upper BB Violation", pathUpperBandViolation, rearmTime, Brushes.Black, dotsUpOutside);
					}
					catch{}
				}
				else if(lowerViolation)		
				{
					try
					{
							Alert("Lower_BB_Violation", Priority.Medium,"Lower BB Violation", pathLowerBandViolation, rearmTime, Brushes.Black, dotsDownOutside);
					}
					catch{}
				}
				else if(zerolineCrossFromBelow)		
				{
					try
					{
							Alert("Bullish_Zeroline_Cross", Priority.Medium,"Bullish Zeroline Cross", pathBullishZeroCross, rearmTime, Brushes.Black, zerolineCrossUp);
					}
					catch{}
				}
				else if(zerolineCrossFromAbove)		
				{
					try
					{
							Alert("Bearish_Zeroline_Cross", Priority.Medium,"Bearish Zeroline Cross", pathBearishZeroCross, rearmTime, Brushes.Black, zerolineCrossDown);
					}
					catch{}
				}
			}	
		}

		#region Properties
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> BBMACD
		{
			get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Average
		{
			get { return Values[2]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> UpperBB
		{
			get { return Values[3]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> LowerBB
		{
			get { return Values[4]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Trend
		{
			get { return trend; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> LongSignal
		{
			get { return longSignal; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> ShortSignal
		{
			get { return shortSignal; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast period", Description = "Sets the fast period for the MACD", GroupName = "Input Parameters", Order = 0)]
		public int Fast
		{	
            get { return fast; }
            set { fast = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow period", Description = "Sets the slow period for the MACD", GroupName = "Input Parameters", Order = 1)]
		public int Slow
		{	
            get { return slow; }
            set { slow = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Band period", Description = "Sets the period for the average and the standard deviation", GroupName = "Input Parameters", Order = 2)]
		public int BandPeriod
		{	
            get { return bandPeriod; }
            set { bandPeriod = value; }
		}
		
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Std. dev. multiplier", Description = "Sets the standard deviation multiplier for the Bollinger bands", GroupName = "Input Parameters", Order = 3)]
		public double StdDevMultiplier
		{	
            get { return stdDevMultiplier; }
            set { stdDevMultiplier = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show MACD average", GroupName = "Display Options", Order = 0)]
        public bool ShowAverage
        {
            get { return showAverage; }
            set { showAverage = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show Bollinger Bands", GroupName = "Display Options", Order = 1)]
        public bool ShowChannel
        {
            get { return showChannel; }
            set { showChannel = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Channel flooding", GroupName = "Display Options", Order = 2)]
        public bool ChannelFlooding
        {
            get { return channelFlooding; }
            set { channelFlooding = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show zeroline crosses", GroupName = "Display Options", Order = 3)]
        public bool ShowZerolineCrosses
        {
            get { return showZerolineCrosses; }
            set { showZerolineCrosses = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show paint bars", GroupName = "Display Options", Order = 4)]
        public bool ShowPaintBars
        {
            get { return showPaintBars; }
            set { showPaintBars = value; }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rising above bands", Description = "Sets the color for rising MACDBB dots above the upper channel line", GroupName = "Plot Colors", Order = 0)]
		public System.Windows.Media.Brush DotsUpOutside
		{ 
			get {return dotsUpOutside;}
			set {dotsUpOutside = value;}
		}

		[Browsable(false)]
		public string DotsUpOutsideSerializable
		{
			get { return Serialize.BrushToString(dotsUpOutside); }
			set { dotsUpOutside = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rising other", Description = "Sets the color for rising MACDBB dots below the upper channel line", GroupName = "Plot Colors", Order = 1)]
		public System.Windows.Media.Brush DotsUpInside
		{ 
			get {return dotsUpInside;}
			set {dotsUpInside = value;}
		}

		[Browsable(false)]
		public string DotsUpInsideSerializable
		{
			get { return Serialize.BrushToString(dotsUpInside); }
			set { dotsUpInside = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Falling below bands", Description = "Sets the color for falling MACDBB dots below the lower channel line", GroupName = "Plot Colors", Order = 2)]
		public System.Windows.Media.Brush DotsDownOutside
		{ 
			get {return dotsDownOutside;}
			set {dotsDownOutside = value;}
		}

		[Browsable(false)]
		public string DotsDownOutsideSerializable
		{
			get { return Serialize.BrushToString(dotsDownOutside); }
			set { dotsDownOutside = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Falling other", Description = "Sets the color for falling MACDBB dots above the lower channel line", GroupName = "Plot Colors", Order = 3)]
		public System.Windows.Media.Brush DotsDownInside
		{ 
			get {return dotsDownInside;}
			set {dotsDownInside = value;}
		}

		[Browsable(false)]
		public string DotsDownInsideSerializable
		{
			get { return Serialize.BrushToString(dotsDownInside); }
			set { dotsDownInside = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dot frames", Description = "Sets the color for the MACDBB dot frames", GroupName = "Plot Colors", Order = 5)]
		public System.Windows.Media.Brush DotFrame
		{ 
			get {return dotFrame;}
			set {dotFrame = value;}
		}

		[Browsable(false)]
		public string DotFrameSerializable
		{
			get { return Serialize.BrushToString(dotFrame); }
			set { dotFrame = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dot connectors", Description = "Sets the color for the MACDBB dot connectors", GroupName = "Plot Colors", Order = 6)]
		public System.Windows.Media.Brush Connector
		{ 
			get {return connector;}
			set {connector = value;}
		}

		[Browsable(false)]
		public string ConnectorSerializable
		{
			get { return Serialize.BrushToString(connector); }
			set { connector = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "MACDBB average", Description = "Sets the color for the Bollinger midband", GroupName = "Plot Colors", Order = 7)]
		public System.Windows.Media.Brush BBAverage
		{ 
			get {return bbAverage;}
			set {bbAverage = value;}
		}

		[Browsable(false)]
		public string BBAverageSerializable
		{
			get { return Serialize.BrushToString(bbAverage); }
			set { bbAverage = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upper BB", Description = "Sets the color for the upper Bollinger band", GroupName = "Plot Colors", Order = 8)]
		public System.Windows.Media.Brush BBUpper
		{ 
			get {return bbUpper;}
			set {bbUpper = value;}
		}

		[Browsable(false)]
		public string BBUpperSerializable
		{
			get { return Serialize.BrushToString(bbUpper); }
			set { bbUpper = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Lower BB", Description = "Sets the color for the lower Bollinger band", GroupName = "Plot Colors", Order = 9)]
		public System.Windows.Media.Brush BBLower
		{ 
			get {return bbLower;}
			set {bbLower = value;}
		}

		[Browsable(false)]
		public string BBLowerSerializable
		{
			get { return Serialize.BrushToString(bbLower); }
			set { bbLower = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Channel fill", Description = "Sets the fill color for the area between the Bollinger bands", GroupName = "Plot Colors", Order = 10)]
		public System.Windows.Media.Brush ChannelFillBrushS
		{ 
			get {return channelFillBrushS;}
			set {channelFillBrushS = value;}
		}

		[Browsable(false)]
		public string ChannelFillBrushSerializableS
		{
			get { return Serialize.BrushToString(channelFillBrushS); }
			set { channelFillBrushS = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Zeroline Cross Up", Description = "Sets the color for a bullish zeroline cross", GroupName = "Plot Colors", Order = 11)]
		public System.Windows.Media.Brush ZerolineCrossUp
		{ 
			get {return zerolineCrossUp;}
			set {zerolineCrossUp = value;}
		}

		[Browsable(false)]
		public string ZerolineCrossUpSerializable
		{
			get { return Serialize.BrushToString(zerolineCrossUp); }
			set { zerolineCrossUp = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Zeroline Cross Down", Description = "Sets the color for a bearish zeroline cross", GroupName = "Plot Colors", Order = 12)]
		public System.Windows.Media.Brush ZerolineCrossDown
		{ 
			get {return zerolineCrossDown;}
			set {zerolineCrossDown = value;}
		}

		[Browsable(false)]
		public string ZerolineCrossDownSerializable
		{
			get { return Serialize.BrushToString(zerolineCrossDown); }
			set { zerolineCrossDown = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style midband", Description = "Sets the dash style for the MACD average", GroupName = "Plot Parameters", Order = 0)]
		public DashStyleHelper Dash2Style
		{
			get { return dash2Style; }
			set { dash2Style = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style bands", Description = "Sets the dash style for the Bollinger Bands", GroupName = "Plot Parameters", Order = 1)]
		public DashStyleHelper Dash3Style
		{
			get { return dash3Style; }
			set { dash3Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dot size MACD", Description = "Sets the plot width for MACD dots", GroupName = "Plot Parameters", Order = 2)]
		public int Plot7Width
		{	
            get { return plot7Width; }
            set { plot7Width = value; }
		}
			
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Width MACD connectors", Description = "Sets the plot width for MACD Connectors", GroupName = "Plot Parameters", Order = 3)]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
			
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width midband", Description = "Sets the plot width for the MACD average", GroupName = "Plot Parameters", Order = 4)]
		public int Plot2Width
		{	
            get { return plot2Width; }
            set { plot2Width = value; }
		}
			
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width bands", Description = "Sets the plot width for the Bollinger Bands", GroupName = "Plot Parameters", Order = 5)]
		public int Plot3Width
		{	
            get { return plot3Width; }
            set { plot3Width = value; }
		}
			
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dot size crosses", Description = "Sets the dots size for the zeroline crosses", GroupName = "Plot Parameters", Order = 6)]
		public int Plot1Width
		{	
            get { return plot1Width; }
            set { plot1Width = value; }
		}
			
		[Range(0, 100)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Channel opacity", Description = "Select a value between 0 and 100 for the channel opacity", GroupName = "Plot Parameters", Order = 7)]
		public int ChannelOpacity
		{	
            get { return channelOpacity; }
            set { channelOpacity = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rising above bands", Description = "Sets the color for rising MACDBB dots above the upper channel line", GroupName = "Paint Bars - Upcloses", Order = 0)]
		public System.Windows.Media.Brush DotsUpOutsideUpclose
		{ 
			get {return dotsUpOutsideUpclose;}
			set {dotsUpOutsideUpclose = value;}
		}

		[Browsable(false)]
		public string DotsUpOutsideUpcloseSerializable
		{
			get { return Serialize.BrushToString(dotsUpOutsideUpclose); }
			set { dotsUpOutsideUpclose = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rising other", Description = "Sets the color for rising MACDBB dots below the upper channel line", GroupName = "Paint Bars - Upcloses", Order = 1)]
		public System.Windows.Media.Brush DotsUpInsideUpclose
		{ 
			get {return dotsUpInsideUpclose;}
			set {dotsUpInsideUpclose = value;}
		}

		[Browsable(false)]
		public string DotsUpInsideUpcloseSerializable
		{
			get { return Serialize.BrushToString(dotsUpInsideUpclose); }
			set { dotsUpInsideUpclose = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Falling below bands", Description = "Sets the color for falling MACDBB dots below the lower channel line", GroupName = "Paint Bars - Upcloses", Order = 2)]
		public System.Windows.Media.Brush DotsDownOutsideUpclose
		{ 
			get {return dotsDownOutsideUpclose;}
			set {dotsDownOutsideUpclose = value;}
		}

		[Browsable(false)]
		public string DotsDownOutsideUpcloseSerializable
		{
			get { return Serialize.BrushToString(dotsDownOutsideUpclose); }
			set { dotsDownOutsideUpclose = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Falling other", Description = "Sets the color for falling MACDBB dots above the lower channel line", GroupName = "Paint Bars - Upcloses", Order = 3)]
		public System.Windows.Media.Brush DotsDownInsideUpclose
		{ 
			get {return dotsDownInsideUpclose;}
			set {dotsDownInsideUpclose = value;}
		}

		[Browsable(false)]
		public string DotsDownInsideUpcloseSerializable
		{
			get { return Serialize.BrushToString(dotsDownInsideUpclose); }
			set { dotsDownInsideUpclose = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rising above bands", Description = "Sets the color for rising MACDBB dots above the upper channel line", GroupName = "Paint Bars - Downcloses", Order = 0)]
		public System.Windows.Media.Brush DotsUpOutsideDownclose
		{ 
			get {return dotsUpOutsideDownclose;}
			set {dotsUpOutsideDownclose = value;}
		}

		[Browsable(false)]
		public string DotsUpOutsideDowncloseSerializable
		{
			get { return Serialize.BrushToString(dotsUpOutsideDownclose); }
			set { dotsUpOutsideDownclose = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rising other", Description = "Sets the color for rising MACDBB dots below the upper channel line", GroupName = "Paint Bars - Downcloses", Order = 1)]
		public System.Windows.Media.Brush DotsUpInsideDownclose
		{ 
			get {return dotsUpInsideDownclose;}
			set {dotsUpInsideDownclose = value;}
		}

		[Browsable(false)]
		public string DotsUpInsideDowncloseSerializable
		{
			get { return Serialize.BrushToString(dotsUpInsideDownclose); }
			set { dotsUpInsideDownclose = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Falling below bands", Description = "Sets the color for falling MACDBB dots below the lower channel line", GroupName = "Paint Bars - Downcloses", Order = 2)]
		public System.Windows.Media.Brush DotsDownOutsideDownclose
		{ 
			get {return dotsDownOutsideDownclose;}
			set {dotsDownOutsideDownclose = value;}
		}

		[Browsable(false)]
		public string DotsDownOutsideDowncloseSerializable
		{
			get { return Serialize.BrushToString(dotsDownOutsideDownclose); }
			set { dotsDownOutsideDownclose = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Falling other", Description = "Sets the color for falling MACDBB dots above the lower channel line", GroupName = "Paint Bars - Downcloses", Order = 3)]
		public System.Windows.Media.Brush DotsDownInsideDownclose
		{ 
			get {return dotsDownInsideDownclose;}
			set {dotsDownInsideDownclose = value;}
		}

		[Browsable(false)]
		public string DotsDownInsideDowncloseSerializable
		{
			get { return Serialize.BrushToString(dotsDownInsideDownclose); }
			set { dotsDownInsideDownclose = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rising above bands", Description = "Sets the candle outline color for rising MACDBB dots above the upper channel line", GroupName = "Paint Bars - Outlines", Order = 0)]
		public System.Windows.Media.Brush DotsUpOutsideOutline
		{ 
			get {return dotsUpOutsideOutline;}
			set {dotsUpOutsideOutline = value;}
		}

		[Browsable(false)]
		public string DotsUpOutsideOutlineSerializable
		{
			get { return Serialize.BrushToString(dotsUpOutsideOutline); }
			set { dotsUpOutsideOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rising other", Description = "Sets the candle outline color for rising MACDBB dots below the upper channel line", GroupName = "Paint Bars - Outlines", Order = 1)]
		public System.Windows.Media.Brush DotsUpInsideOutline
		{ 
			get {return dotsUpInsideOutline;}
			set {dotsUpInsideOutline = value;}
		}

		[Browsable(false)]
		public string DotsUpInsideOutlineSerializable
		{
			get { return Serialize.BrushToString(dotsUpInsideOutline); }
			set { dotsUpInsideOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Falling below bands", Description = "Sets the candle outline color for falling MACDBB dots below the lower channel line", GroupName = "Paint Bars - Outlines", Order = 2)]
		public System.Windows.Media.Brush DotsDownOutsideOutline
		{ 
			get {return dotsDownOutsideOutline;}
			set {dotsDownOutsideOutline = value;}
		}

		[Browsable(false)]
		public string DotsDownOutsideOutlineSerializable
		{
			get { return Serialize.BrushToString(dotsDownOutsideOutline); }
			set { dotsDownOutsideOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Falling other", Description = "Sets the candle outline color for falling MACDBB dots above the lower channel line", GroupName = "Paint Bars - Outlines", Order = 3)]
		public System.Windows.Media.Brush DotsDownInsideOutline
		{ 
			get {return dotsDownInsideOutline;}
			set {dotsDownInsideOutline = value;}
		}

		[Browsable(false)]
		public string DotsDownInsideOutlineSerializable
		{
			get { return Serialize.BrushToString(dotsDownInsideOutline); }
			set { dotsDownInsideOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Line color", Description = "Sets the color for the zeroline", GroupName = "Zeroline", Order = 0)]
		public System.Windows.Media.Brush ZerolineBrush
		{ 
			get {return zerolineBrush;}
			set {zerolineBrush = value;}
		}

		[Browsable(false)]
		public string ZerolineBrushSerializable
		{
			get { return Serialize.BrushToString(zerolineBrush); }
			set { zerolineBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style", Description = "Sets the dash style for the zeroline", GroupName = "Zeroline", Order = 1)]
		public DashStyleHelper ZerolineStyle
		{
			get { return zerolineStyle; }
			set { zerolineStyle = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width", Description = "Sets the plot width for the zeroline", GroupName = "Zeroline", Order = 2)]
		public int ZerolineWidth
		{	
            get { return zerolineWidth; }
            set { zerolineWidth = value; }
		}
			
		[Display(ResourceType = typeof(Custom.Resource), Name = "Sound alerts", GroupName = "Sound Alerts", Order = 0)]
        public bool SoundAlerts
        {
            get { return soundAlerts; }
            set { soundAlerts = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upper band touched", Description = "Sound file for upper band violation", GroupName = "Sound Alerts", Order = 1)]
		public string UpperBandViolation
		{	
            get { return upperBandViolation; }
            set { upperBandViolation = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Lower band touched", Description = "Sound file for lower band violation", GroupName = "Sound Alerts", Order = 2)]
		public string LowerBandViolation
		{	
            get { return lowerBandViolation; }
            set { lowerBandViolation = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish zero cross", Description = "Sound file for bullish cross of the zeroline", GroupName = "Sound Alerts", Order = 3)]
		public string BullishZeroCross
		{	
            get { return bullishZeroCross; }
            set { bullishZeroCross = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish zero cross", Description = "Sound file for bearish cross of the zeroline", GroupName = "Sound Alerts", Order = 4)]
		public string BearishZeroCross
		{	
            get { return bearishZeroCross; }
            set { bearishZeroCross = value; }
		}		
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rearm time", Description = "Rearm time for alerts in seconds", GroupName = "Sound Alerts", Order = 5)]
		public int RearmTime
		{	
            get { return rearmTime; }
            set { rearmTime = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
		
		#region Miscellaneous
	
		private bool IsConnected()
        {
			if ( Bars != null && Bars.Instrument.GetMarketDataConnection().PriceStatus == NinjaTrader.Cbi.ConnectionStatus.Connected
					&& sessionIterator.IsInSession(Now, true, true))
				return true;
			else
            	return false;
        }
		
		private DateTime Now
		{
          get 
			{ 
				DateTime now = (Bars.Instrument.GetMarketDataConnection().Options.Provider == NinjaTrader.Cbi.Provider.Playback ? Bars.Instrument.GetMarketDataConnection().Now : DateTime.Now); 

				if (now.Millisecond > 0)
					now = NinjaTrader.Core.Globals.MinDate.AddSeconds((long) System.Math.Floor(now.Subtract(NinjaTrader.Core.Globals.MinDate).TotalSeconds));

				return now;
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (Bars == null || ChartControl == null || ChartBars.ToIndex < BarsRequiredToPlot || !IsVisible) return;

			SharpDX.Direct2D1.Brush zerolineBrushDX = zerolineBrush.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush channelFillBrushDX = channelFillBrush.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush bbAverageDX = bbAverage.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush bbUpperDX = bbUpper.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush bbLowerDX = bbLower.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush dotsUpOutsideDX = dotsUpOutside.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush dotsUpInsideDX = dotsUpInside.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush dotsDownOutsideDX = dotsDownOutside.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush dotsDownInsideDX = dotsDownInside.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush connectorDX = connector.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Brush dotFrameDX = dotFrame.ToDxBrush(RenderTarget);
			SharpDX.Direct2D1.Ellipse ellipse;
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

	        ChartPanel panel = chartControl.ChartPanels[ChartPanel.PanelIndex];
			
			bool nonEquidistant 	= (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti);
			int	lastBarPainted 	 	= ChartBars.ToIndex;
			int lastBarCounted		= Input.Count - 1;
			int	lastBarOnUpdate		= lastBarCounted - (Calculate == Calculate.OnBarClose ? 1 : 0);
			int	lastBarIndex		= Math.Min(lastBarPainted, lastBarOnUpdate);
			int firstBarPainted	 	= ChartBars.FromIndex;
			int firstBarIndex  	 	= Math.Max(BarsRequiredToPlot + displacement, firstBarPainted);
			int lastIndex			= 0;
			int x 					= 0;
			int y1 					= 0;
			int y2 					= 0;
			int y 					= 0;
			int t					= 0;
			int lastX 				= 0;
			int lastY0 				= 0;
			int lastY1 				= 0;
			int lastY2 				= 0;
			int lastY 				= 0;
			int sign 				= 0;
			int lastSign 			= 0;
			int startBar 			= 0;
			int priorStartBar 		= 0;
			int returnBar 			= 0;
			int count	 			= 0;
			double barWidth			= 0.0;
			
			bool firstLoop 			= true;
			Vector2[] cloudArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			Vector2[] plotArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			
			if(lastBarIndex + displacement > firstBarIndex)
			{	
				if (displacement >= 0)
					lastIndex = lastBarIndex + displacement;
				else
					lastIndex = Math.Min(lastBarIndex, lastBarOnUpdate + displacement);
				if(nonEquidistant && lastIndex > lastBarOnUpdate)
					barWidth = Convert.ToDouble(ChartControl.GetXByBarIndex(ChartBars, lastBarPainted) - ChartControl.GetXByBarIndex(ChartBars, lastBarPainted - displacement))/displacement;
				lastY0	= chartScale.GetYByValue(Average.GetValueAt(lastIndex - displacement));
				lastY1	= chartScale.GetYByValue(UpperBB.GetValueAt(lastIndex - displacement));
				lastY2	= chartScale.GetYByValue(LowerBB.GetValueAt(lastIndex - displacement));
				
				// Zeroline
				y = chartScale.GetYByValue(0.0);
				SharpDX.Vector2 startPoint = new SharpDX.Vector2(ChartPanel.X, y);
				SharpDX.Vector2 endPoint = new SharpDX.Vector2(ChartPanel.X + ChartPanel.W, y);
				RenderTarget.DrawLine(startPoint, endPoint, zerolineBrushDX, Lines[0].Width, Lines[0].StrokeStyle);
				
				//Area
				if(channelIsFilled)
				{	
					SharpDX.Direct2D1.PathGeometry 	path;
					SharpDX.Direct2D1.GeometrySink 	sink;
					path = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					using (path)
					{
						count = -1;
						for (int idx = lastIndex; idx >= firstBarIndex; idx --)	
						{
							if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, idx);
							y = chartScale.GetYByValue(UpperBB.GetValueAt(idx - displacement));   
							count = count + 1;
							cloudArray[count] = new Vector2(x,y);
						}
						for (int idx = firstBarIndex ; idx <= lastIndex; idx ++)	
						{
							if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, idx);
							y = chartScale.GetYByValue(LowerBB.GetValueAt(idx - displacement));   
							count = count + 1;
							cloudArray[count] = new Vector2(x,y);
						}
						sink = path.Open();
						sink.BeginFigure(cloudArray[0], FigureBegin.Filled);
						for (int i = 1; i <= count; i++)
							sink.AddLine(cloudArray[i]);
						sink.EndFigure(FigureEnd.Closed);
		        		sink.Close();
	 					RenderTarget.FillGeometry(path, channelFillBrushDX);
					}
					path.Dispose();
					sink.Dispose();
				}
				
				// Average
				if(showAverage)
				{
					SharpDX.Direct2D1.PathGeometry 	pathA;
					SharpDX.Direct2D1.GeometrySink 	sinkA;
					pathA = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					using (pathA)
					{
						count = -1;
						for (int idx = lastIndex; idx >= firstBarIndex; idx --)	
						{
							if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, idx);
							y = chartScale.GetYByValue(Average.GetValueAt(idx - displacement));   
							count = count + 1;
							plotArray[count] = new Vector2(x,y);
						}
						sinkA = pathA.Open();
						sinkA.BeginFigure(plotArray[0], FigureBegin.Filled);
						for (int i = 1; i <= count; i++)
							sinkA.AddLine(plotArray[i]);
						sinkA.EndFigure(FigureEnd.Open);
		        		sinkA.Close();
						RenderTarget.DrawGeometry(pathA, bbAverageDX, Plots[2].Width, Plots[2].StrokeStyle);
					}					
				}	
				
				// Channel lines
				if(showChannel)	
				{
					SharpDX.Direct2D1.PathGeometry 	pathU;
					SharpDX.Direct2D1.GeometrySink 	sinkU;
					pathU = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					using (pathU)
					{
						count = -1;
						for (int idx = lastIndex; idx >= firstBarIndex; idx --)	
						{
							if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, idx);
							y = chartScale.GetYByValue(UpperBB.GetValueAt(idx - displacement));   
							count = count + 1;
							plotArray[count] = new Vector2(x,y);
						}
						sinkU = pathU.Open();
						sinkU.BeginFigure(plotArray[0], FigureBegin.Filled);
						for (int i = 1; i <= count; i++)
							sinkU.AddLine(plotArray[i]);
						sinkU.EndFigure(FigureEnd.Open);
		        		sinkU.Close();
						RenderTarget.DrawGeometry(pathU, bbUpperDX, Plots[3].Width, Plots[3].StrokeStyle);
					}					
					SharpDX.Direct2D1.PathGeometry 	pathL;
					SharpDX.Direct2D1.GeometrySink 	sinkL;
					pathL = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					using (pathL)
					{
						count = -1;
						for (int idx = lastIndex; idx >= firstBarIndex; idx --)	
						{
							if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, idx);
							y = chartScale.GetYByValue(LowerBB.GetValueAt(idx - displacement));   
							count = count + 1;
							plotArray[count] = new Vector2(x,y);
						}
						sinkL = pathL.Open();
						sinkL.BeginFigure(plotArray[0], FigureBegin.Filled);
						for (int i = 1; i <= count; i++)
							sinkL.AddLine(plotArray[i]);
						sinkL.EndFigure(FigureEnd.Open);
		        		sinkL.Close();
						RenderTarget.DrawGeometry(pathL, bbLowerDX, Plots[4].Width, Plots[4].StrokeStyle);
					}					
				}
				
				// Zeroline crosses
				if(showZerolineCrosses)
				{	
					for (int idx = lastIndex; idx >= firstBarIndex; idx --)	
					{
						if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
							x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
						else
							x = ChartControl.GetXByBarIndex(ChartBars, idx);
						if(Values[1].IsValidDataPointAt(idx - displacement))
						{
							y = chartScale.GetYByValue(Values[1].GetValueAt(idx - displacement));   
							ellipse = new SharpDX.Direct2D1.Ellipse(new Vector2(x, y), plot1Width + 2, plot1Width + 2);
							RenderTarget.FillEllipse(ellipse, PlotBrushes[1].GetDxBrush(idx - displacement));
						}	
					}
				}
				
				// Connectors
				SharpDX.Direct2D1.PathGeometry 	pathC;
				SharpDX.Direct2D1.GeometrySink 	sinkC;
				pathC = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
				using (pathC)
				{
					count = -1;
					for (int idx = lastIndex; idx >= firstBarIndex; idx --)	
					{
						if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
							x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
						else
							x = ChartControl.GetXByBarIndex(ChartBars, idx);
						y = chartScale.GetYByValue(BBMACD.GetValueAt(idx - displacement));   
						count = count + 1;
						plotArray[count] = new Vector2(x,y);
					}
					sinkC = pathC.Open();
					sinkC.BeginFigure(plotArray[0], FigureBegin.Filled);
					for (int i = 1; i <= count; i++)
						sinkC.AddLine(plotArray[i]);
					sinkC.EndFigure(FigureEnd.Open);
	        		sinkC.Close();
					RenderTarget.DrawGeometry(pathC, connectorDX, Plots[5].Width, Plots[5].StrokeStyle);
				}	
				
				//MACDBB dots
				for (int idx = lastIndex; idx >= firstBarIndex; idx --)	
				{
					if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
						x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
					else
						x = ChartControl.GetXByBarIndex(ChartBars, idx);
					y = chartScale.GetYByValue(BBMACD.GetValueAt(idx - displacement));   
					t = (int) Trend.GetValueAt(idx - displacement);
					ellipse = new SharpDX.Direct2D1.Ellipse(new Vector2(x, y), plot7Width + 2, plot7Width + 2);
					RenderTarget.FillEllipse(ellipse, dotFrameDX);
					ellipse = new SharpDX.Direct2D1.Ellipse(new Vector2(x, y), plot7Width + 1, plot7Width + 1);
					if(t > 1.5)
						RenderTarget.FillEllipse(ellipse, dotsUpOutsideDX);
					else if (t > 0.5)
						RenderTarget.FillEllipse(ellipse, dotsUpInsideDX);
					else if(t < -1.5)
						RenderTarget.FillEllipse(ellipse, dotsDownOutsideDX);
					else if (t < -0.5)
						RenderTarget.FillEllipse(ellipse, dotsDownInsideDX);
				}		
			}
			zerolineBrushDX.Dispose();
			channelFillBrushDX.Dispose();
			bbAverageDX.Dispose();
			bbUpperDX.Dispose();
			bbLowerDX.Dispose();
			connectorDX.Dispose();
			dotsUpOutsideDX.Dispose();
			dotsUpInsideDX.Dispose();
			dotsDownOutsideDX.Dispose();
			dotsDownInsideDX.Dispose();
			RenderTarget.AntialiasMode = oldAntialiasMode;
		}		
		#endregion	
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaMACDBBLines[] cacheamaMACDBBLines;
		public LizardIndicators.amaMACDBBLines amaMACDBBLines(int fast, int slow, int bandPeriod, double stdDevMultiplier)
		{
			return amaMACDBBLines(Input, fast, slow, bandPeriod, stdDevMultiplier);
		}

		public LizardIndicators.amaMACDBBLines amaMACDBBLines(ISeries<double> input, int fast, int slow, int bandPeriod, double stdDevMultiplier)
		{
			if (cacheamaMACDBBLines != null)
				for (int idx = 0; idx < cacheamaMACDBBLines.Length; idx++)
					if (cacheamaMACDBBLines[idx] != null && cacheamaMACDBBLines[idx].Fast == fast && cacheamaMACDBBLines[idx].Slow == slow && cacheamaMACDBBLines[idx].BandPeriod == bandPeriod && cacheamaMACDBBLines[idx].StdDevMultiplier == stdDevMultiplier && cacheamaMACDBBLines[idx].EqualsInput(input))
						return cacheamaMACDBBLines[idx];
			return CacheIndicator<LizardIndicators.amaMACDBBLines>(new LizardIndicators.amaMACDBBLines(){ Fast = fast, Slow = slow, BandPeriod = bandPeriod, StdDevMultiplier = stdDevMultiplier }, input, ref cacheamaMACDBBLines);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaMACDBBLines amaMACDBBLines(int fast, int slow, int bandPeriod, double stdDevMultiplier)
		{
			return indicator.amaMACDBBLines(Input, fast, slow, bandPeriod, stdDevMultiplier);
		}

		public Indicators.LizardIndicators.amaMACDBBLines amaMACDBBLines(ISeries<double> input , int fast, int slow, int bandPeriod, double stdDevMultiplier)
		{
			return indicator.amaMACDBBLines(input, fast, slow, bandPeriod, stdDevMultiplier);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaMACDBBLines amaMACDBBLines(int fast, int slow, int bandPeriod, double stdDevMultiplier)
		{
			return indicator.amaMACDBBLines(Input, fast, slow, bandPeriod, stdDevMultiplier);
		}

		public Indicators.LizardIndicators.amaMACDBBLines amaMACDBBLines(ISeries<double> input , int fast, int slow, int bandPeriod, double stdDevMultiplier)
		{
			return indicator.amaMACDBBLines(input, fast, slow, bandPeriod, stdDevMultiplier);
		}
	}
}

#endregion
