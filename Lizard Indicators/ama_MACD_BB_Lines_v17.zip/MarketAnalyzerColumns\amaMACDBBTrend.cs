#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.LizardIndicators
{
	[Gui.CategoryOrder("Input Parameters", 1000100)]
	public class amaMACDBBTrend : MarketAnalyzerColumn
	{
		private NinjaTrader.NinjaScript.Indicators.LizardIndicators.amaMACDBBLines amaMACDBB;
		
		private int					fast					= 12;
		private int					slow					= 26;
		private int					bandPeriod 				= 10;
		private double				stdDevMultiplier		= 1.0;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "amaMACDBB_Trend";
				Calculate									= Calculate.OnPriceChange;
				DataType   									= typeof(double);
        		IsEditable 									= false;
				FormatDecimals 								= 0;
			}
			else if (State == State.DataLoaded)
			{
				amaMACDBB		= amaMACDBBLines(fast, slow, bandPeriod, stdDevMultiplier);
			}
		}
		
		protected override void OnBarUpdate()
		{
		  	CurrentValue = amaMACDBB.Trend[0];
		}
		
		#region Properties
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast period", Description = "Sets the fast period for the MACD", GroupName = "Input Parameters", Order = 0)]
		public int Fast
		{	
            get { return fast; }
            set { fast = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow period", Description = "Sets the slow period for the MACD", GroupName = "Input Parameters", Order = 1)]
		public int Slow
		{	
            get { return slow; }
            set { slow = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Band period", Description = "Sets the period for the average and the standard deviation", GroupName = "Input Parameters", Order = 2)]
		public int BandPeriod
		{	
            get { return bandPeriod; }
            set { bandPeriod = value; }
		}
		
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Std. dev. multiplier", Description = "Sets the standard deviation multiplier for the Bollinger bands", GroupName = "Input Parameters", Order = 3)]
		public double StdDevMultiplier
		{	
            get { return stdDevMultiplier; }
            set { stdDevMultiplier = value; }
		}
		#endregion
	}
}
