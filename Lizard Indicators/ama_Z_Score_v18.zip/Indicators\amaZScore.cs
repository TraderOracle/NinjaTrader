//+----------------------------------------------------------------------------------------------+
//| Copyright © <2021>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The Z-score or standard score is the signed number of standard deviations by which the current value of the input series is above or below the mean value calculated for the selected lookback period.
	/// </summary>
	[Gui.CategoryOrder("Input Parameters", 1000100)]
	[Gui.CategoryOrder("Threshold Values", 1000200)]
	[Gui.CategoryOrder("Display Options", 1000300)]
	[Gui.CategoryOrder("Z-Score Plot", 8000100)]
	[Gui.CategoryOrder("Version", 8000200)]
	public class amaZScore : Indicator
	{
		private int		    					period						= 14;
		private int								displacement				= 0;
		private int								totalBarsRequiredToPlot		= 0;
		private double							currentInput				= 0.0;
		private double							priorInput					= 0.0;
		private double 							priorMean					= 0.0;
		private double							priorSquareMean				= 0.0;
		private double							variance					= 0.0;
		private double							zscore						= 0.0;
		private double							upperlineValue				= 2.0;
		private double							zerolineValue				= 0.0;
		private double							lowerlineValue				= -2.0;
		private bool							applyShading				= true;
		private System.Windows.Media.Brush		overboughtBrush				= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		oversoldBrush				= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		neutralBrush				= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		overboughtAreaBrush			= Brushes.Lime;
		private System.Windows.Media.Brush		oversoldAreaBrush			= Brushes.Red;
		private System.Windows.Media.Brush		overboughtAreaBrushOpaque	= null;
		private System.Windows.Media.Brush		oversoldAreaBrushOpaque		= null;
		private System.Windows.Media.Brush		upperlineBrush				= Brushes.DarkGreen;
		private System.Windows.Media.Brush		zerolineBrush				= Brushes.Navy;
		private System.Windows.Media.Brush		lowerlineBrush				= Brushes.DarkRed;
		private	SharpDX.Direct2D1.Brush 		overboughtBrushDX;
		private	SharpDX.Direct2D1.Brush 		oversoldBrushDX;
		private	SharpDX.Direct2D1.Brush 		neutralBrushDX;
		private	SharpDX.Direct2D1.Brush 		overboughtAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		oversoldAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		upperlineBrushDX;
		private	SharpDX.Direct2D1.Brush 		zerolineBrushDX;
		private	SharpDX.Direct2D1.Brush 		lowerlineBrushDX;
		private PlotStyle						plot0Style					= PlotStyle.Line;
		private DashStyleHelper					dash0Style					= DashStyleHelper.Solid;
		private int								plot0Width					= 2;
		private DashStyleHelper					upperlineStyle				= DashStyleHelper.Solid;
		private int								upperlineWidth				= 1;
		private DashStyleHelper					zerolineStyle				= DashStyleHelper.Solid;
		private int								zerolineWidth				= 1;
		private DashStyleHelper					lowerlineStyle				= DashStyleHelper.Solid;
		private int								lowerlineWidth				= 1;
		private int								areaOpacity					= 80;
		private string							versionString				= "v 1.8  -  February 26, 2021";
		private Series<double>					squares;
		private Series<double>					mean;
		private Series<double>					squareMean;
		private Series<double>					zscoreTrend;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\nThe Z-score or standard score is the signed number of standard deviations by which the current value of the input series"
												+ " is above or below the mean value calculated for the selected lookback period.";
				Name						= "amaZScore";
				IsSuspendedWhileInactive 	= true;
				ArePlotsConfigurable		= false;
				AreLinesConfigurable		= false;
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "Z-Score");
				AddLine(new Stroke(Brushes.Gray, 1), 2, "Upper Line");
				AddLine(new Stroke(Brushes.Gray, 1), 0, "Zeroline");
				AddLine(new Stroke(Brushes.Gray, 1), -2, "Lower Line");
			}
			else if (State == State.Configure)
			{
				BarsRequiredToPlot = period;
				totalBarsRequiredToPlot = Math.Max(0, BarsRequiredToPlot + displacement);
				Plots[0].PlotStyle = plot0Style;
				Plots[0].DashStyleHelper = dash0Style;
				Plots[0].Width = plot0Width;
				Lines[0].Value = upperlineValue;
				Lines[0].Brush = upperlineBrush;
				Lines[0].DashStyleHelper = upperlineStyle;
				Lines[0].Width = upperlineWidth;
				Lines[1].Value = zerolineValue;
				Lines[1].Brush = zerolineBrush;
				Lines[1].DashStyleHelper = zerolineStyle;
				Lines[1].Width = zerolineWidth;
				Lines[2].Value = lowerlineValue;
				Lines[2].Brush = lowerlineBrush;
				Lines[2].DashStyleHelper = lowerlineStyle;
				Lines[2].Width = lowerlineWidth;
				overboughtAreaBrushOpaque = overboughtAreaBrush.Clone(); 
				overboughtAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				overboughtAreaBrushOpaque.Freeze();
				oversoldAreaBrushOpaque = oversoldAreaBrush.Clone(); 
				oversoldAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				oversoldAreaBrushOpaque.Freeze();
			}	
			else if (State == State.DataLoaded)
			{
				squares = new Series<double>(this, Period < 250 ? MaximumBarsLookBack.TwoHundredFiftySix : MaximumBarsLookBack.Infinite);
				mean = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				squareMean = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				zscoreTrend = new Series<double>(this, MaximumBarsLookBack.Infinite);
			}
			else if (State == State.Historical)
			{
				overboughtAreaBrushOpaque = overboughtAreaBrush.Clone(); 
				overboughtAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				overboughtAreaBrushOpaque.Freeze();
				oversoldAreaBrushOpaque = oversoldAreaBrush.Clone(); 
				oversoldAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				oversoldAreaBrushOpaque.Freeze();
			}
		}
		
		protected override void OnBarUpdate()
		{
			currentInput = Input[0]/TickSize;
			if(CurrentBar == 0)
			{
				squares[0] = currentInput * currentInput;
				mean[0] = currentInput;
				squareMean[0] = squares[0];
				ZScore[0] = 0.0;
				return;
			}
			if(IsFirstTickOfBar)
			{
				priorMean = mean[1];
				priorSquareMean = squareMean[1];
			}	
			squares[0] = currentInput * currentInput;
			if(CurrentBar < period)
			{
				mean[0] = (CurrentBar * priorMean + currentInput)/(CurrentBar + 1);
				squareMean[0] = (CurrentBar * priorSquareMean + squares[0])/(CurrentBar + 1);
			}
			else
			{
				priorInput = Input[period] / TickSize;
				mean[0] = priorMean + (currentInput - priorInput)/period;
				squareMean[0] = priorSquareMean + (squares[0] - squares[period])/period;
			}	
			variance = squareMean[0] - mean[0] * mean[0];
			if(variance.ApproxCompare(0) > 0)
				zscore = (currentInput - mean[0])/Math.Sqrt(variance);
			else
				zscore = 0.0;
			ZScore[0] = zscore;
			
			if(zscore > upperlineValue)
			{	
				zscoreTrend[0] = 1.0;
				PlotBrushes[0][0] = overboughtBrush;
			}	
			else if(zscore < lowerlineValue)
			{	
				zscoreTrend[0] = -1.0;
				PlotBrushes[0][0] = oversoldBrush;
			}	
			else
			{	
				zscoreTrend[0] = 0.0;
				PlotBrushes[0][0] = neutralBrush;
			}	
		}

		#region Properties
        [Browsable(false)]	
        [XmlIgnore()]		
        public Series<double> ZScore
        {
            get { return Values[0]; }
        }
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> ZScoreTrend
		{
			get { return zscoreTrend; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", Description = "Sets the lookback period for the z-score", GroupName = "Input Parameters", Order = 0)]
		public int Period
		{	
            get { return period; }
            set { period = value; }
		}

		[Range(0, double.MaxValue), NinjaScriptProperty] 
		[Display(ResourceType = typeof(Custom.Resource), Name = "Overbought line", Description = "Sets the overbought level for the z-score", GroupName = "Threshold Values", Order = 0)]
		public double UpperlineValue
		{	
            get { return upperlineValue; }
            set { upperlineValue = value; }
		}
		
		[Range(double.MinValue, 0), NinjaScriptProperty] 
		[Display(ResourceType = typeof(Custom.Resource), Name = "Oversold line", Description = "Sets the oversold level for the z-score", GroupName = "Threshold Values", Order = 1)]
		public double LowerlineValue
		{	
            get { return lowerlineValue; }
            set { lowerlineValue = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Apply shading", Description = "Applies shading to overbought and oversold areas", GroupName = "Display Options", Order = 0)]
      	public bool ApplyShading
        {
            get { return applyShading; }
            set { applyShading = value; }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Z-Score overbought", Description = "Sets the color for the z-score when overbought", GroupName = "Z-Score Plot", Order = 0)]
		public System.Windows.Media.Brush OverboughtBrush
		{ 
			get {return overboughtBrush;}
			set {overboughtBrush = value;}
		}

		[Browsable(false)]
		public string OverboughtBrushSerializable
		{
			get { return Serialize.BrushToString(overboughtBrush); }
			set { overboughtBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Z-Score neutral", Description = "Sets the color for the z-score when neutral", GroupName = "Z-Score Plot", Order = 1)]
		public System.Windows.Media.Brush NeutralBrush
		{ 
			get {return neutralBrush;}
			set {neutralBrush = value;}
		}

		[Browsable(false)]
		public string NeutralBrushSerializable
		{
			get { return Serialize.BrushToString(neutralBrush); }
			set { neutralBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Z-Score oversold", Description = "Sets the color for the z-score when oversold", GroupName = "Z-Score Plot", Order = 2)]
		public System.Windows.Media.Brush OversoldBrush
		{ 
			get {return oversoldBrush;}
			set {oversoldBrush = value;}
		}

		[Browsable(false)]
		public string OversoldBrushSerializable
		{
			get { return Serialize.BrushToString(oversoldBrush); }
			set { oversoldBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style z-score", Description = "Sets the dash style for the z-score", GroupName = "Z-Score Plot", Order = 3)]
		public DashStyleHelper Dash0Style
		{
			get { return dash0Style; }
			set { dash0Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width z-score", Description = "Sets the plot width for the z-score", GroupName = "Z-Score Plot", Order = 4)]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Z-Score overbought area", Description = "Sets the color for the z-score area when overbought", GroupName = "Z-Score Plot", Order = 5)]
		public System.Windows.Media.Brush OverboughtAreaBrush
		{ 
			get {return overboughtAreaBrush;}
			set {overboughtAreaBrush = value;}
		}

		[Browsable(false)]
		public string OverboughtAreaBrushSerializable
		{
			get { return Serialize.BrushToString(overboughtAreaBrush); }
			set { overboughtAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Z-Score oversold area", Description = "Sets the color for the z-score area when oversold", GroupName = "Z-Score Plot", Order = 6)]
		public System.Windows.Media.Brush OversoldAreaBrush
		{ 
			get {return oversoldAreaBrush;}
			set {oversoldAreaBrush = value;}
		}

		[Browsable(false)]
		public string OversoldAreaBrushSerializable
		{
			get { return Serialize.BrushToString(oversoldAreaBrush); }
			set { oversoldAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(0, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Area opacity", Description = "Sets the opacity for the overbought and oversold areas", GroupName = "Z-Score Plot", Order = 7)]
		public int AreaOpacity
		{	
            get { return areaOpacity; }
            set { areaOpacity = value; }
		}		
	
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upper line", Description = "Sets the color for the upper line", GroupName = "Lines", Order = 0)]
		public System.Windows.Media.Brush UpperlineBrush
		{ 
			get {return upperlineBrush;}
			set {upperlineBrush = value;}
		}

		[Browsable(false)]
		public string UpperlineBrushSerializable
		{
			get { return Serialize.BrushToString(upperlineBrush); }
			set { upperlineBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style upper line", Description = "Sets the dash style for the upper line", GroupName = "Lines", Order = 1)]
		public DashStyleHelper UpperlineStyle
		{
			get { return upperlineStyle; }
			set { upperlineStyle = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width upper line", Description = "Sets the plot width for the upper line", GroupName = "Lines", Order = 2)]
		public int UpperlineWidth
		{	
            get { return upperlineWidth; }
            set { upperlineWidth = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Zeroline", Description = "Sets the color for the zeroline", GroupName = "Lines", Order = 3)]
		public System.Windows.Media.Brush ZerolineBrush
		{ 
			get {return zerolineBrush;}
			set {zerolineBrush = value;}
		}

		[Browsable(false)]
		public string ZerolineBrushSerializable
		{
			get { return Serialize.BrushToString(zerolineBrush); }
			set { zerolineBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style zeroline", Description = "Sets the dash style for the zeroline", GroupName = "Lines", Order = 4)]
		public DashStyleHelper ZerolineStyle
		{
			get { return zerolineStyle; }
			set { zerolineStyle = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width zeroline", Description = "Sets the plot width for the zeroline", GroupName = "Lines", Order = 5)]
		public int ZerolineWidth
		{	
            get { return zerolineWidth; }
            set { zerolineWidth = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Lower line", Description = "Sets the color for the lower line", GroupName = "Lines", Order = 6)]
		public System.Windows.Media.Brush LowerlineBrush
		{ 
			get {return lowerlineBrush;}
			set {lowerlineBrush = value;}
		}

		[Browsable(false)]
		public string LowerlineBrushSerializable
		{
			get { return Serialize.BrushToString(lowerlineBrush); }
			set { lowerlineBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style lower line", Description = "Sets the dash style for the lower line", GroupName = "Lines", Order = 7)]
		public DashStyleHelper LowerlineStyle
		{
			get { return lowerlineStyle; }
			set { lowerlineStyle = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width lower line", Description = "Sets the plot width for the lower line", GroupName = "Lines", Order = 8)]
		public int LowerlineWidth
		{	
            get { return lowerlineWidth; }
            set { lowerlineWidth = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
		
		#region Miscellaneous
		
		public override void OnRenderTargetChanged()
		{
			if (overboughtBrushDX != null)
				overboughtBrushDX.Dispose();
			if (oversoldBrushDX != null)
				oversoldBrushDX.Dispose();
			if (neutralBrushDX != null)
				neutralBrushDX.Dispose();
			if (overboughtAreaBrushDX != null)
				overboughtAreaBrushDX.Dispose();
			if (oversoldAreaBrushDX != null)
				oversoldAreaBrushDX.Dispose();
			if (upperlineBrushDX != null)
				upperlineBrushDX.Dispose();
			if (zerolineBrushDX != null)
				zerolineBrushDX.Dispose();
			if (lowerlineBrushDX != null)
				lowerlineBrushDX.Dispose();
			
			if (RenderTarget != null)
			{
				try
				{
					overboughtBrushDX = overboughtBrush.ToDxBrush(RenderTarget);
					oversoldBrushDX = oversoldBrush.ToDxBrush(RenderTarget);
					neutralBrushDX = neutralBrush.ToDxBrush(RenderTarget);
					overboughtAreaBrushDX = overboughtAreaBrushOpaque.ToDxBrush(RenderTarget);
					oversoldAreaBrushDX = oversoldAreaBrushOpaque.ToDxBrush(RenderTarget);
					upperlineBrushDX = upperlineBrush.ToDxBrush(RenderTarget);
					zerolineBrushDX = zerolineBrush.ToDxBrush(RenderTarget);
					lowerlineBrushDX = lowerlineBrush.ToDxBrush(RenderTarget);
				}
				catch (Exception e) { }
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (Bars == null || ChartControl == null || ChartBars.ToIndex < BarsRequiredToPlot || !IsVisible) return;
			int	lastBarPainted = ChartBars.ToIndex;
			if(lastBarPainted  < 0 || BarsArray[0].Count < lastBarPainted) return;
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
	        ChartPanel panel = chartControl.ChartPanels[ChartPanel.PanelIndex];
			
			bool nonEquidistant 	= (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti);
			int lastBarCounted		= Close.Count - 1;
			int	lastBarOnUpdate		= lastBarCounted - (Calculate == Calculate.OnBarClose ? 1 : 0);
			int	lastBarIndex		= Math.Min(lastBarPainted, lastBarOnUpdate);
			int firstBarPainted	 	= ChartBars.FromIndex;
			int firstBarIndex  	 	= Math.Max(totalBarsRequiredToPlot, firstBarPainted); 
			int lastIndex			= 0;
			int x 					= 0;
			int y0	 				= 0;
			int y1 					= 0;
			int yUpper 				= 0;
			int yMid 				= 0;
			int yLower 				= 0;
			int y 					= 0;
			int t					= 0;
			int lastX 				= 0;
			int lastY0 				= 0;
			int lastY 				= 0;
			int sign 				= 0;
			int lastSign 			= 0;
			int startBar 			= 0;
			int returnBar 			= 0;
			int count	 			= 0;
			double barWidth			= 0;
			bool firstLoop 			= true;
			SharpDX.Vector2 startPointDX;
			SharpDX.Vector2 endPointDX;
			Vector2[] plotArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			
			if(lastBarIndex + displacement > firstBarIndex)
			{	
				if (displacement >= 0)
					lastIndex = lastBarIndex + displacement;
				else
					lastIndex = Math.Min(lastBarIndex, lastBarOnUpdate + displacement);
				if(nonEquidistant && lastIndex > lastBarOnUpdate)
					barWidth = Convert.ToDouble(ChartControl.GetXByBarIndex(ChartBars, lastBarPainted) - ChartControl.GetXByBarIndex(ChartBars, lastBarPainted - displacement))/displacement;
				lastY0	= chartScale.GetYByValue(ZScore.GetValueAt(lastIndex - displacement));
				yUpper  = chartScale.GetYByValue(upperlineValue);
				yMid  = chartScale.GetYByValue(zerolineValue);
				yLower  = chartScale.GetYByValue(lowerlineValue);
				
				//Lines
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yUpper);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yUpper);
				RenderTarget.DrawLine(startPointDX, endPointDX, upperlineBrushDX, upperlineWidth, Lines[0].StrokeStyle);
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yMid);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yMid);
				RenderTarget.DrawLine(startPointDX, endPointDX, zerolineBrushDX, zerolineWidth, Lines[1].StrokeStyle);
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yLower);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yLower);
				RenderTarget.DrawLine(startPointDX, endPointDX, lowerlineBrushDX, lowerlineWidth, Lines[2].StrokeStyle);

				// Z-Score Shading
				if(applyShading)
				{	
					lastY = lastY0;
					lastSign = (int) ZScoreTrend.GetValueAt(lastIndex - displacement);
					startBar = lastIndex;
					firstLoop = true;
					do
					{
						SharpDX.Direct2D1.PathGeometry 	pathF;
						SharpDX.Direct2D1.GeometrySink 	sinkF;
						pathF = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (pathF)
						{
							if(firstLoop)
							{	
								count = 0;						
								if(nonEquidistant && displacement > 0 && startBar > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((startBar - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, startBar);
								if (lastSign == 1)
									plotArray[count] = new Vector2(x, yUpper);
								else if(lastSign == -1)
									plotArray[count] = new Vector2(x, yLower);
							}	
							else
							{	
								count = 0;
								plotArray[count] = new Vector2(lastX, lastY);
							}
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(ZScore.GetValueAt(idx - displacement));   
								t = (int) ZScoreTrend.GetValueAt(idx - displacement);
								count = count + 1;
								if(t == lastSign)
								{
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = t;
									lastX = x;
									lastY = y;
								}	
								else if (t == 0 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 0 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper - lastY);
									double diff = Convert.ToDouble(yUpper - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
								else if (t == 1 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower - lastY);
									double diff = Convert.ToDouble(yLower - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
							}
							if(sign == 0)
							{	
								firstLoop = false;
								continue;
							}	
							if(startBar == firstBarIndex)
							{
								count = count + 1;
								if(sign == 1)
									plotArray[count] = new Vector2(lastX, yUpper);
								else if(sign == -1)
									plotArray[count] = new Vector2(lastX, yLower);
							}	
							sinkF = pathF.Open();
							sinkF.BeginFigure(plotArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sinkF.AddLine(plotArray[i]);
							sinkF.EndFigure(FigureEnd.Closed);
			        		sinkF.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
							if(sign == 1)
		 						RenderTarget.FillGeometry(pathF, overboughtAreaBrushDX);
							else if(sign == -1) 
		 						RenderTarget.FillGeometry(pathF, oversoldAreaBrushDX);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						pathF.Dispose();
						sinkF.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex && ZScore.IsValidDataPointAt(startBar - displacement));
				}
				
				// Z-Score
				lastY = lastY0;
				lastSign = 5;
				startBar = lastIndex;
				firstLoop = true;
				do
				{
					SharpDX.Direct2D1.PathGeometry 	pathE;
					SharpDX.Direct2D1.GeometrySink 	sinkE;
					pathE = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					using (pathE)
					{
						count = 0;
						plotArray[count] = new Vector2(lastX, lastY);
						for (int idx = startBar; idx >= firstBarIndex; idx --)	
						{
							if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, idx);
							y = chartScale.GetYByValue(ZScore.GetValueAt(idx - displacement));   
							t = (int) ZScoreTrend.GetValueAt(idx - displacement);
							count = count + 1;
							if(t == lastSign)
							{
								plotArray[count] = new Vector2(x,y);
								sign = t;
								startBar = idx;
								lastX = x;
								lastY = y;
							}	
							else if(lastSign == 5)
							{	
								plotArray[count] = new Vector2(x,y);
								sign = 5;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}	
							else if (t == 0 && lastSign == 1)
							{	
								double lastDiff = Convert.ToDouble(yUpper - lastY);
								double diff = Convert.ToDouble(yUpper - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yUpper;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}
							else if (t == 0 && lastSign == -1)
							{	
								double lastDiff = Convert.ToDouble(yLower - lastY);
								double diff = Convert.ToDouble(yLower - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yLower;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}
							else if (t == 1 && lastSign == 0)
							{	
								double lastDiff = Convert.ToDouble(yUpper - lastY);
								double diff = Convert.ToDouble(yUpper - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yUpper;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}
							else if (t == -1 && lastSign == 0)
							{	
								double lastDiff = Convert.ToDouble(yLower - lastY);
								double diff = Convert.ToDouble(yLower - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yLower;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}
							else if (t == -1 && lastSign == 1)
							{	
								double lastDiff = Convert.ToDouble(yUpper - lastY);
								double diff = Convert.ToDouble(yUpper - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yUpper;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = 0;
								break;
							}
							else if (t == 1 && lastSign == -1)
							{	
								double lastDiff = Convert.ToDouble(yLower - lastY);
								double diff = Convert.ToDouble(yLower - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yLower;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = 0;
								break;
							}
						}
						sinkE = pathE.Open();
						if(firstLoop)
							sinkE.BeginFigure(plotArray[1], FigureBegin.Filled);
						else
							sinkE.BeginFigure(plotArray[0], FigureBegin.Filled);
						for (int i = 1; i <= count; i++)
							sinkE.AddLine(plotArray[i]);
						sinkE.EndFigure(FigureEnd.Open);
		        		sinkE.Close();
						RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
						if(sign == 1)
	 						RenderTarget.DrawGeometry(pathE, overboughtBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
						else if(sign == 0) 
	 						RenderTarget.DrawGeometry(pathE, neutralBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
						else if(sign == -1) 
	 						RenderTarget.DrawGeometry(pathE, oversoldBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
						RenderTarget.AntialiasMode = oldAntialiasMode;
					}
					pathE.Dispose();
					sinkE.Dispose();
					firstLoop = false;
				}	
				while (startBar > firstBarIndex && ZScore.IsValidDataPointAt(startBar - displacement));
			}			
		}		
		#endregion		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaZScore[] cacheamaZScore;
		public LizardIndicators.amaZScore amaZScore(int period, double upperlineValue, double lowerlineValue)
		{
			return amaZScore(Input, period, upperlineValue, lowerlineValue);
		}

		public LizardIndicators.amaZScore amaZScore(ISeries<double> input, int period, double upperlineValue, double lowerlineValue)
		{
			if (cacheamaZScore != null)
				for (int idx = 0; idx < cacheamaZScore.Length; idx++)
					if (cacheamaZScore[idx] != null && cacheamaZScore[idx].Period == period && cacheamaZScore[idx].UpperlineValue == upperlineValue && cacheamaZScore[idx].LowerlineValue == lowerlineValue && cacheamaZScore[idx].EqualsInput(input))
						return cacheamaZScore[idx];
			return CacheIndicator<LizardIndicators.amaZScore>(new LizardIndicators.amaZScore(){ Period = period, UpperlineValue = upperlineValue, LowerlineValue = lowerlineValue }, input, ref cacheamaZScore);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaZScore amaZScore(int period, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaZScore(Input, period, upperlineValue, lowerlineValue);
		}

		public Indicators.LizardIndicators.amaZScore amaZScore(ISeries<double> input , int period, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaZScore(input, period, upperlineValue, lowerlineValue);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaZScore amaZScore(int period, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaZScore(Input, period, upperlineValue, lowerlineValue);
		}

		public Indicators.LizardIndicators.amaZScore amaZScore(ISeries<double> input , int period, double upperlineValue, double lowerlineValue)
		{
			return indicator.amaZScore(input, period, upperlineValue, lowerlineValue);
		}
	}
}

#endregion
