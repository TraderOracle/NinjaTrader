#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

//This namespace holds MarketAnalyzerColumns in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns.LizardIndicators
{
	[Gui.CategoryOrder("Algorithmic Options", 1000100)]
	[Gui.CategoryOrder("Input Parameters", 1000200)]
	[Gui.CategoryOrder("Threshold Lines", 1000300)]
	public class amaMultiTSITrend : MarketAnalyzerColumn
	{
		private NinjaTrader.NinjaScript.Indicators.LizardIndicators.amaMultiTSI amaMTSI;
		
        private int                         momentumPeriod              = 1;
        private int                         smooth1                     = 20;
        private int                         smooth2                     = 9;
        private int                         smooth3                     = 1;
        private int                         signalPeriod                = 5;
		private double						upperThreshold				= 25;
		private double						lowerThreshold				= -25;
       	private double                      epsilon                     = 0.0;
        private amaMultiTSISmoothType       smoothType                  = amaMultiTSISmoothType.EMA;
        private amaMultiTSISmoothType       signalType                  = amaMultiTSISmoothType.EMA;
        private amaMultiTSITrendDefinition  trendDefinition             = amaMultiTSITrendDefinition.Signal_Slope;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"";
				Name										= "amaMultiTSI_Trend";
				Calculate									= Calculate.OnPriceChange;
				DataType   									= typeof(double);
        		IsEditable 									= false;
				BarsRequiredToPlot 							= smooth1 + smooth2 + smooth3 + signalPeriod;				
				FormatDecimals 								= 0;
			}
			else if (State == State.DataLoaded)
			{
				amaMTSI		= amaMultiTSI(smoothType, signalType, trendDefinition, momentumPeriod, smooth1, smooth2, smooth3, signalPeriod, upperThreshold, lowerThreshold);
			}
		}
		
		protected override void OnBarUpdate()
		{
		  	CurrentValue = amaMTSI.Trend[0];
		}
		
		#region Properties
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Momentum smoothing", Description = "Select moving average type for smoothing momentum", GroupName = "Algorithmic Options", Order = 0)]
		public amaMultiTSISmoothType SmoothType
		{	
            get { return smoothType; }
            set { smoothType = value; }
		}
			
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Signal smoothing", Description = "Select moving average type for smoothing the signal line", GroupName = "Algorithmic Options", Order = 1)]
		public amaMultiTSISmoothType SignalType
		{	
            get { return signalType; }
            set { signalType = value; }
		}
			
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Trend definition", Description = "Select trend definition for the paint bars", GroupName = "Algorithmic Options", Order = 2)]
		public amaMultiTSITrendDefinition TrendDefinition
		{	
            get { return trendDefinition; }
            set { trendDefinition = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Momentum period", Description = "Select lookback period for momentum", GroupName = "Input Parameters", Order = 0)]
		public int MomentumPeriod
		{	
            get { return momentumPeriod; }
            set { momentumPeriod = value; }
		}
				
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Smoothing period 1", Description = "Select first smoothing period for momentum", GroupName = "Input Parameters", Order = 1)]
		public int Smooth1
		{	
            get { return smooth1; }
            set { smooth1 = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Smoothing period 2", Description = "Select second smoothing period for momentum", GroupName = "Input Parameters", Order = 2)]
		public int Smooth2
		{	
            get { return smooth2; }
            set { smooth2 = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Smoothing period 3", Description = "Select third smoothing period for momentum", GroupName = "Input Parameters", Order = 3)]
		public int Smooth3
		{	
            get { return smooth3; }
            set { smooth3 = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Signal period", Description = "Select lookback period for signal line", GroupName = "Input Parameters", Order = 4)]
		public int SignalPeriod
		{	
            get { return signalPeriod; }
            set { signalPeriod = value; }
		}
				
		[Range(0.0, 100.0), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Upper threshold", GroupName = "Threshold Lines", Order = 0)]
		public double UpperThreshold
		{	
            get { return upperThreshold; }
            set { upperThreshold = value; }
		}
		
		[Range(-100.0, 0), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Lower threshold", GroupName = "Threshold Lines", Order = 1)]
		public double LowerThreshold
		{	
            get { return lowerThreshold; }
            set { lowerThreshold = value; }
		}
		#endregion
	}
}
