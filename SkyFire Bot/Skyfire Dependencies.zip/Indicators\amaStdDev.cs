//+----------------------------------------------------------------------------------------------+
//| Copyright © <2020>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The indicator calculates the standard deviation from the input series over the selected lookback period. 
	/// This indicator uses a faster algorithm than the standard deviation indicator that ships with NinjaTrader.
	/// </summary>
	[Gui.CategoryOrder("Input Parameters", 1000100)]
	[Gui.CategoryOrder("Version", 8000100)]
	public class amaStdDev : Indicator
	{
		private int						period					= 14;
		private double 					priorMean				= 0.0;
		private double					priorSquareMean			= 0.0;
		private double					diff					= 0.0;
		private string					versionString			= "v 1.3  -  March 7, 2020";
		private Series<double>			squares;
		private Series<double>			mean;
		private Series<double>			squareMean;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\nThe indicator calculates the standard deviation from the input series over the selected lookback period. "
												+ "This indicator uses a faster algorithm than the standard deviation indicator that ships with NinjaTrader."; 
				Name						= "amaStdDev";
				IsSuspendedWhileInactive	= true;
				AddPlot(new Stroke(Brushes.Red, 2), PlotStyle.Line, "Std Dev");	
			}
			else if (State == State.Configure)
			{
				BarsRequiredToPlot	= period;
			}
			else if (State == State.DataLoaded)
			{
				squares = new Series<double>(this, Period < 250 ? MaximumBarsLookBack.TwoHundredFiftySix : MaximumBarsLookBack.Infinite);
				mean = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				squareMean = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
			}	
		}

		protected override void OnBarUpdate()
		{
			if(CurrentBar == 0)
			{
				squares[0] = Input[0]*Input[0];
				mean[0] = Input[0];
				squareMean[0] = squares[0];
				StdDev[0] = 0.0;
				return;
			}
			if(IsFirstTickOfBar)
			{
				priorMean = mean[1];
				priorSquareMean = squareMean[1];
			}	
			squares[0] = Input[0]*Input[0];
			if(CurrentBar < period)
			{
				mean[0] = (CurrentBar * priorMean + Input[0])/(CurrentBar + 1);
				squareMean[0] = (CurrentBar * priorSquareMean + squares[0])/(CurrentBar + 1);
			}
			else
			{
				mean[0] = priorMean + (Input[0] - Input[period])/period;
				squareMean[0] = priorSquareMean + (squares[0] - squares[period])/period;
			}	
			diff = squareMean[0] - mean[0]*mean[0];
			if(diff > 0)
				StdDev[0] = Math.Sqrt(diff);
			else
				StdDev[0] = 0.0;
		}

		#region Properties
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> StdDev
		{
			get { return Values[0]; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "Input Parameters", Order = 0)]
		public int Period
		{	
            get { return period; }
            set { period = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaStdDev[] cacheamaStdDev;
		public LizardIndicators.amaStdDev amaStdDev(int period)
		{
			return amaStdDev(Input, period);
		}

		public LizardIndicators.amaStdDev amaStdDev(ISeries<double> input, int period)
		{
			if (cacheamaStdDev != null)
				for (int idx = 0; idx < cacheamaStdDev.Length; idx++)
					if (cacheamaStdDev[idx] != null && cacheamaStdDev[idx].Period == period && cacheamaStdDev[idx].EqualsInput(input))
						return cacheamaStdDev[idx];
			return CacheIndicator<LizardIndicators.amaStdDev>(new LizardIndicators.amaStdDev(){ Period = period }, input, ref cacheamaStdDev);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaStdDev amaStdDev(int period)
		{
			return indicator.amaStdDev(Input, period);
		}

		public Indicators.LizardIndicators.amaStdDev amaStdDev(ISeries<double> input , int period)
		{
			return indicator.amaStdDev(input, period);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaStdDev amaStdDev(int period)
		{
			return indicator.amaStdDev(Input, period);
		}

		public Indicators.LizardIndicators.amaStdDev amaStdDev(ISeries<double> input , int period)
		{
			return indicator.amaStdDev(input, period);
		}
	}
}

#endregion
