//+----------------------------------------------------------------------------------------------+
//| Copyright © <2021>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The Connors RSI is a momentum oscillator indicator developed by Larry Connors. It can be used to identified short term overbought and oversold conditions.
	/// </summary>
	[Gui.CategoryOrder("Input Parameters", 1000100)]
	[Gui.CategoryOrder("Threshold Values", 1000200)]
	[Gui.CategoryOrder("Display Options", 1000300)]
	[Gui.CategoryOrder("Version", 8000100)]
	public class amaConnorsRSI : Indicator
	{
		private int								rankPeriod					= 100; 
		private int								streakPeriod 				= 2;
		private int								rsiPeriod					= 3;
		private int								displacement				= 0;
		private int								totalBarsRequiredToPlot		= 0;
		private int								barsAgo						= 0;
		private double							rank						= 0.0;
		private double							crsi						= 0.0;
		private double							percentRank					= 0.0;
		private double							upperline2Value				= 90.0;
		private double							upperline1Value				= 70.0;
		private double							zerolineValue				= 0.0;
		private double							lowerline1Value				= 30.0;
		private double							lowerline2Value				= 10.0;
		private bool							applyShading				= true;
		private bool 							calculateFromPriceData		= true;
		private System.Windows.Media.Brush		overboughtBrush				= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		oversoldBrush				= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		neutralBrush				= Brushes.DarkSlateGray;
		private System.Windows.Media.Brush		overboughtAreaBrush			= Brushes.Lime;
		private System.Windows.Media.Brush		oversoldAreaBrush			= Brushes.Red;
		private System.Windows.Media.Brush		overboughtAreaBrushOpaque	= null;
		private System.Windows.Media.Brush		oversoldAreaBrushOpaque		= null;
		private System.Windows.Media.Brush		upperline2Brush				= Brushes.DarkGreen;
		private System.Windows.Media.Brush		upperline1Brush				= Brushes.DarkGreen;
		private System.Windows.Media.Brush		zerolineBrush				= Brushes.Navy;
		private System.Windows.Media.Brush		lowerline1Brush				= Brushes.DarkRed;
		private System.Windows.Media.Brush		lowerline2Brush				= Brushes.DarkRed;
		private	SharpDX.Direct2D1.Brush 		overboughtBrushDX;
		private	SharpDX.Direct2D1.Brush 		oversoldBrushDX;
		private	SharpDX.Direct2D1.Brush 		neutralBrushDX;
		private	SharpDX.Direct2D1.Brush 		overboughtAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		oversoldAreaBrushDX;
		private	SharpDX.Direct2D1.Brush 		upperline2BrushDX;
		private	SharpDX.Direct2D1.Brush 		upperline1BrushDX;
		private	SharpDX.Direct2D1.Brush 		zerolineBrushDX;
		private	SharpDX.Direct2D1.Brush 		lowerline1BrushDX;
		private	SharpDX.Direct2D1.Brush 		lowerline2BrushDX;
		private PlotStyle						plot0Style					= PlotStyle.Line;
		private DashStyleHelper					dash0Style					= DashStyleHelper.Solid;
		private int								plot0Width					= 2;
		private DashStyleHelper					upperline2Style				= DashStyleHelper.Solid;
		private int								upperline2Width				= 1;
		private DashStyleHelper					upperline1Style				= DashStyleHelper.Solid;
		private int								upperline1Width				= 1;
		private DashStyleHelper					zerolineStyle				= DashStyleHelper.Solid;
		private int								zerolineWidth				= 1;
		private DashStyleHelper					lowerline1Style				= DashStyleHelper.Solid;
		private int								lowerline1Width				= 1;
		private DashStyleHelper					lowerline2Style				= DashStyleHelper.Solid;
		private int								lowerline2Width				= 1;
		private int								areaOpacity					= 80;
		private string							versionString				= "v 1.2  -  February 26, 2021";
		private Series<double>					streak;
		private Series<double>					crsiTrend;
		private ROC								rateOfChange;
		private RSI								streakRSI;
		private RSI								defaultRSI;
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\n The Connors RSI is a momentum oscillator indicator developed by Larry Connors. It can be used to identified short term overbought and oversold conditions.";
				Name						= "amaConnorsRSI";
				IsSuspendedWhileInactive	= true;
				ArePlotsConfigurable		= false;
				AreLinesConfigurable		= false;
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Line, "CRSI");
				AddLine(Brushes.Gray, 90, "Level 2");
				AddLine(Brushes.Gray, 70, "Level 1");
				AddLine(Brushes.Gray, 0, "Zeroline");
				AddLine(Brushes.Gray, 30, "Level -1");
				AddLine(Brushes.Gray, 10, "Level -2");
			}
			else if (State == State.Configure)
			{
				BarsRequiredToPlot = Math.Max(rankPeriod, Math.Max(streakPeriod, rsiPeriod));
				totalBarsRequiredToPlot = Math.Max(0, BarsRequiredToPlot + displacement);
				Plots[0].PlotStyle = plot0Style;
				Plots[0].DashStyleHelper = dash0Style;
				Plots[0].Width = plot0Width;
				Lines[0].Value = upperline2Value;
				Lines[0].Brush = upperline2Brush;
				Lines[0].DashStyleHelper = upperline2Style;
				Lines[0].Width = upperline2Width;
				Lines[1].Value = upperline1Value;
				Lines[1].Brush = upperline1Brush;
				Lines[1].DashStyleHelper = upperline1Style;
				Lines[1].Width = upperline1Width;
				Lines[2].Value = zerolineValue;
				Lines[2].Brush = zerolineBrush;
				Lines[2].DashStyleHelper = zerolineStyle;
				Lines[2].Width = zerolineWidth;
				Lines[3].Value = lowerline1Value;
				Lines[3].Brush = lowerline1Brush;
				Lines[3].DashStyleHelper = lowerline1Style;
				Lines[3].Width = lowerline1Width;
				Lines[4].Value = lowerline2Value;
				Lines[4].Brush = lowerline2Brush;
				Lines[4].DashStyleHelper = lowerline2Style;
				Lines[4].Width = lowerline2Width;
				overboughtAreaBrushOpaque = overboughtAreaBrush.Clone(); 
				overboughtAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				overboughtAreaBrushOpaque.Freeze();
				oversoldAreaBrushOpaque = oversoldAreaBrush.Clone(); 
				oversoldAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				oversoldAreaBrushOpaque.Freeze();
			}
			else if (State == State.DataLoaded)
			{
				streak = new Series<double>(this, streakPeriod < 250 ? MaximumBarsLookBack.TwoHundredFiftySix : MaximumBarsLookBack.Infinite);
				rateOfChange = ROC(Input, 1);
				streakRSI = RSI(streak, streakPeriod, 3);
				defaultRSI = RSI(Input, rsiPeriod, 3);
				crsiTrend  = new Series<double>(this, MaximumBarsLookBack.Infinite);
				if(Input is PriceSeries)
					calculateFromPriceData = true;
				else
					calculateFromPriceData = false;
			}
			else if (State == State.Historical)
			{
				overboughtAreaBrushOpaque = overboughtAreaBrush.Clone(); 
				overboughtAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				overboughtAreaBrushOpaque.Freeze();
				oversoldAreaBrushOpaque = oversoldAreaBrush.Clone(); 
				oversoldAreaBrushOpaque.Opacity = (float) areaOpacity/100.0;
				oversoldAreaBrushOpaque.Freeze();
			}
		}

		protected override void OnBarUpdate()
		{	
			if(CurrentBar < 1)
			{
				streak[0] = 0;
				CRSI[0] = 50.0;
				return;
			}	
			
			barsAgo = Math.Min(rankPeriod, CurrentBar);
			rank = 0.0;
			for (int i = 1; i <= barsAgo; i++)
				if(rateOfChange[0] > rateOfChange[i])
					rank = rank + 1.0;
			percentRank = 100*rank/barsAgo;
			if(Input[0] > Input[1])
				streak[0] = streak[1] < 0.5 ? 1.0 : streak[1] + 1.0;
			else if (Input[0] < Input[1])
				streak[0] = streak[1] > -0.5 ? -1.0 : streak[1] - 1.0;
			else
				streak[0] = 0.0;
			crsi = (percentRank + streakRSI[0] + defaultRSI[0])/3.0;
			CRSI[0] = crsi;
			if(crsi > upperline1Value)
			{	
				crsiTrend[0] = 1.0;
				PlotBrushes[0][0] = overboughtBrush;
			}	
			else if(crsi < lowerline1Value)
			{	
				crsiTrend[0] = -1.0;
				PlotBrushes[0][0] = oversoldBrush;
			}	
			else
			{	
				crsiTrend[0] = 0.0;
				PlotBrushes[0][0] = neutralBrush;
			}	
		}

		#region Properties
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> CRSI
		{
			get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> CRSITrend
		{
			get { return crsiTrend; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rank period", GroupName = "Input Parameters", Order = 0)]
		public int RankPeriod
		{	
            get { return rankPeriod; }
            set { rankPeriod = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Streak period", GroupName = "Input Parameters", Order = 1)]
		public int StreakPeriod
		{	
            get { return streakPeriod; }
            set { streakPeriod = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "RSI period", GroupName = "Input Parameters", Order = 2)]
		public int RSIPeriod
		{	
            get { return rsiPeriod; }
            set { rsiPeriod = value; }
		}
			
		[Range(50, 100), NinjaScriptProperty] 
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level 2", Description = "Sets the 2nd overbought level for the Connors RSI", GroupName = "Threshold Values", Order = 0)]
		public double Upperline2Value
		{	
            get { return upperline2Value; }
            set { upperline2Value = value; }
		}
		
		[Range(50, 100), NinjaScriptProperty] 
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level 1", Description = "Sets the 1st overbought level for the Connors RSI", GroupName = "Threshold Values", Order = 1)]
		public double Upperline1Value
		{	
            get { return upperline1Value; }
            set { upperline1Value = value; }
		}
		
		[Range(0, 50), NinjaScriptProperty] 
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level -1", Description = "Sets the 1st oversold level for the Connors RSI", GroupName = "Threshold Values", Order = 2)]
		public double Lowerline1Value
		{	
            get { return lowerline1Value; }
            set { lowerline1Value = value; }
		}
		
		[Range(0, 50), NinjaScriptProperty] 
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level -2", Description = "Sets the 2nd oversold level for the Connors RSI", GroupName = "Threshold Values", Order = 3)]
		public double Lowerline2Value
		{	
            get { return lowerline2Value; }
            set { lowerline2Value = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Apply shading", Description = "Applies shading to overbought and oversold areas", GroupName = "Display Options", Order = 0)]
      	public bool ApplyShading
        {
            get { return applyShading; }
            set { applyShading = value; }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "CRSI overbought", Description = "Sets the color for the Connors RSI when overbought", GroupName = "Plots", Order = 0)]
		public System.Windows.Media.Brush OverboughtBrush
		{ 
			get {return overboughtBrush;}
			set {overboughtBrush = value;}
		}

		[Browsable(false)]
		public string OverboughtBrushSerializable
		{
			get { return Serialize.BrushToString(overboughtBrush); }
			set { overboughtBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "CRSI neutral", Description = "Sets the color for the Connors RSI when neutral", GroupName = "Plots", Order = 1)]
		public System.Windows.Media.Brush NeutralBrush
		{ 
			get {return neutralBrush;}
			set {neutralBrush = value;}
		}

		[Browsable(false)]
		public string NeutralBrushSerializable
		{
			get { return Serialize.BrushToString(neutralBrush); }
			set { neutralBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "CRSI oversold", Description = "Sets the color for the Connors RSI when oversold", GroupName = "Plots", Order = 2)]
		public System.Windows.Media.Brush OversoldBrush
		{ 
			get {return oversoldBrush;}
			set {oversoldBrush = value;}
		}

		[Browsable(false)]
		public string OversoldBrushSerializable
		{
			get { return Serialize.BrushToString(oversoldBrush); }
			set { oversoldBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style CRSI", Description = "Sets the dash style for the Connnors RSI", GroupName = "Plots", Order = 3)]
		public DashStyleHelper Dash0Style
		{
			get { return dash0Style; }
			set { dash0Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width CRSI", Description = "Sets the plot width for the Connnors RSI", GroupName = "Plots", Order = 4)]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "CRSI overbought area", Description = "Sets the color for the Connnors RSI area when overbought", GroupName = "Plots", Order = 5)]
		public System.Windows.Media.Brush OverboughtAreaBrush
		{ 
			get {return overboughtAreaBrush;}
			set {overboughtAreaBrush = value;}
		}

		[Browsable(false)]
		public string OverboughtAreaBrushSerializable
		{
			get { return Serialize.BrushToString(overboughtAreaBrush); }
			set { overboughtAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "CRSI oversold area", Description = "Sets the color for the Connnors RSI area when oversold", GroupName = "Plots", Order = 6)]
		public System.Windows.Media.Brush OversoldAreaBrush
		{ 
			get {return oversoldAreaBrush;}
			set {oversoldAreaBrush = value;}
		}

		[Browsable(false)]
		public string OversoldAreaBrushSerializable
		{
			get { return Serialize.BrushToString(oversoldAreaBrush); }
			set { oversoldAreaBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(0, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Area opacity", Description = "Sets the opacity for the overbought and oversold areas", GroupName = "Plots", Order = 7)]
		public int AreaOpacity
		{	
            get { return areaOpacity; }
            set { areaOpacity = value; }
		}		
	
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level 2", Description = "Sets the color for the 2nd upper line", GroupName = "Lines", Order = 0)]
		public System.Windows.Media.Brush Upperline2Brush
		{ 
			get {return upperline2Brush;}
			set {upperline2Brush = value;}
		}

		[Browsable(false)]
		public string Upperline2BrushSerializable
		{
			get { return Serialize.BrushToString(upperline2Brush); }
			set { upperline2Brush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style level 2", Description = "Sets the dash style for the 2nd upper line", GroupName = "Lines", Order = 1)]
		public DashStyleHelper Upperline2Style
		{
			get { return upperline2Style; }
			set { upperline2Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width level 2", Description = "Sets the plot width for the 2nd upper line", GroupName = "Lines", Order = 2)]
		public int Upperlin2Width
		{	
            get { return upperline2Width; }
            set { upperline2Width = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level 1", Description = "Sets the color for the 1st upper line", GroupName = "Lines", Order = 3)]
		public System.Windows.Media.Brush Upperline1Brush
		{ 
			get {return upperline1Brush;}
			set {upperline1Brush = value;}
		}

		[Browsable(false)]
		public string Upperline1BrushSerializable
		{
			get { return Serialize.BrushToString(upperline1Brush); }
			set { upperline1Brush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style level 1", Description = "Sets the dash style for the 1st upper line", GroupName = "Lines", Order = 4)]
		public DashStyleHelper Upperline1Style
		{
			get { return upperline1Style; }
			set { upperline1Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width level 1", Description = "Sets the plot width for the 1st upper line", GroupName = "Lines", Order = 5)]
		public int Upperline1Width
		{	
            get { return upperline1Width; }
            set { upperline1Width = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level 0", Description = "Sets the color for the zeroline", GroupName = "Lines", Order = 6)]
		public System.Windows.Media.Brush ZerolineBrush
		{ 
			get {return zerolineBrush;}
			set {zerolineBrush = value;}
		}

		[Browsable(false)]
		public string ZerolineBrushSerializable
		{
			get { return Serialize.BrushToString(zerolineBrush); }
			set { zerolineBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style level 0", Description = "Sets the dash style for the zeroline", GroupName = "Lines", Order = 7)]
		public DashStyleHelper ZerolineStyle
		{
			get { return zerolineStyle; }
			set { zerolineStyle = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width level 0", Description = "Sets the plot width for the zeroline", GroupName = "Lines", Order = 8)]
		public int ZerolineWidth
		{	
            get { return zerolineWidth; }
            set { zerolineWidth = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level -1", Description = "Sets the color for the 1st lower line", GroupName = "Lines", Order = 9)]
		public System.Windows.Media.Brush Lowerline1Brush
		{ 
			get {return lowerline1Brush;}
			set {lowerline1Brush = value;}
		}

		[Browsable(false)]
		public string Lowerline1BrushSerializable
		{
			get { return Serialize.BrushToString(lowerline1Brush); }
			set { lowerline1Brush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style level -1", Description = "Sets the dash style for the 1st lower line", GroupName = "Lines", Order = 10)]
		public DashStyleHelper Lowerline1Style
		{
			get { return lowerline1Style; }
			set { lowerline1Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width level -1", Description = "Sets the plot width for the 1st lower line", GroupName = "Lines", Order = 11)]
		public int Lowerline1Width
		{	
            get { return lowerline1Width; }
            set { lowerline1Width = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Level -2", Description = "Sets the color for the 2nd lower line", GroupName = "Lines", Order = 12)]
		public System.Windows.Media.Brush Lowerline2Brush
		{ 
			get {return lowerline2Brush;}
			set {lowerline2Brush = value;}
		}

		[Browsable(false)]
		public string Lowerline2BrushSerializable
		{
			get { return Serialize.BrushToString(lowerline2Brush); }
			set { lowerline2Brush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Dash style level -2", Description = "Sets the dash style for the 2nd lower line", GroupName = "Lines", Order = 13)]
		public DashStyleHelper Lowerline2Style
		{
			get { return lowerline2Style; }
			set { lowerline2Style = value; }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width level -2", Description = "Sets the plot width for the 2nd lower line", GroupName = "Lines", Order = 14)]
		public int Lowerline2Width
		{	
            get { return lowerline2Width; }
            set { lowerline2Width = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
		
		#region Miscellaneous
		
		public override void OnRenderTargetChanged()
		{
			if (overboughtBrushDX != null)
				overboughtBrushDX.Dispose();
			if (oversoldBrushDX != null)
				oversoldBrushDX.Dispose();
			if (neutralBrushDX != null)
				neutralBrushDX.Dispose();
			if (overboughtAreaBrushDX != null)
				overboughtAreaBrushDX.Dispose();
			if (oversoldAreaBrushDX != null)
				oversoldAreaBrushDX.Dispose();
			if (upperline2BrushDX != null)
				upperline2BrushDX.Dispose();
			if (upperline1BrushDX != null)
				upperline1BrushDX.Dispose();
			if (zerolineBrushDX != null)
				zerolineBrushDX.Dispose();
			if (lowerline1BrushDX != null)
				lowerline1BrushDX.Dispose();
			if (lowerline2BrushDX != null)
				lowerline2BrushDX.Dispose();
			
			if (RenderTarget != null)
			{
				try
				{
					overboughtBrushDX = overboughtBrush.ToDxBrush(RenderTarget);
					oversoldBrushDX = oversoldBrush.ToDxBrush(RenderTarget);
					neutralBrushDX = neutralBrush.ToDxBrush(RenderTarget);
					overboughtAreaBrushDX = overboughtAreaBrushOpaque.ToDxBrush(RenderTarget);
					oversoldAreaBrushDX = oversoldAreaBrushOpaque.ToDxBrush(RenderTarget);
					upperline2BrushDX = upperline2Brush.ToDxBrush(RenderTarget);
					upperline1BrushDX = upperline1Brush.ToDxBrush(RenderTarget);
					zerolineBrushDX = zerolineBrush.ToDxBrush(RenderTarget);
					lowerline1BrushDX = lowerline1Brush.ToDxBrush(RenderTarget);
					lowerline2BrushDX = lowerline2Brush.ToDxBrush(RenderTarget);
				}
				catch (Exception e) { }
			}
		}
		
		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (Bars == null || ChartControl == null || ChartBars.ToIndex < BarsRequiredToPlot || !IsVisible) return;
			int	lastBarPainted = ChartBars.ToIndex;
			if(lastBarPainted  < 0 || BarsArray[0].Count < lastBarPainted) return;
			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.Aliased;
	        ChartPanel panel = chartControl.ChartPanels[ChartPanel.PanelIndex];
			
			bool nonEquidistant 	= (chartControl.BarSpacingType == BarSpacingType.TimeBased || chartControl.BarSpacingType == BarSpacingType.EquidistantMulti);
			int lastBarCounted		= Input.Count - 1;
			int	lastBarOnUpdate		= lastBarCounted - (Calculate == Calculate.OnBarClose ? 1 : 0);
			int	lastBarIndex		= Math.Min(lastBarPainted, lastBarOnUpdate);
			int firstBarPainted	 	= ChartBars.FromIndex;
			int firstBarIndex  	 	= Math.Max(totalBarsRequiredToPlot, firstBarPainted); 
			int lastIndex			= 0;
			int x 					= 0;
			int y0	 				= 0;
			int y1 					= 0;
			int yUpper2 			= 0;
			int yUpper1 			= 0;
			int yMid 				= 0;
			int yLower1 			= 0;
			int yLower2 			= 0;
			int y 					= 0;
			int t					= 0;
			int lastX 				= 0;
			int lastY0 				= 0;
			int lastY 				= 0;
			int sign 				= 0;
			int lastSign 			= 0;
			int startBar 			= 0;
			int priorStartBar 		= 0;
			int returnBar 			= 0;
			int count	 			= 0;
			double barWidth			= 0;
			bool firstLoop 			= true;
			SharpDX.Vector2 startPointDX;
			SharpDX.Vector2 endPointDX;
			Vector2[] plotArray 	= new Vector2[2 * (lastBarIndex - firstBarIndex + Math.Max(0, displacement) + 1)]; 
			
			if(lastBarIndex + displacement > firstBarIndex)
			{	
				if (displacement >= 0)
					lastIndex = lastBarIndex + displacement;
				else
					lastIndex = Math.Min(lastBarIndex, lastBarOnUpdate + displacement);
				if(nonEquidistant && lastIndex > lastBarOnUpdate)
					barWidth = Convert.ToDouble(ChartControl.GetXByBarIndex(ChartBars, lastBarPainted) - ChartControl.GetXByBarIndex(ChartBars, lastBarPainted - displacement))/displacement;
				lastY0	= chartScale.GetYByValue(CRSI.GetValueAt(lastIndex - displacement));
				yUpper2  = chartScale.GetYByValue(upperline2Value);
				yUpper1  = chartScale.GetYByValue(upperline1Value);
				yMid  = chartScale.GetYByValue(zerolineValue);
				yLower1  = chartScale.GetYByValue(lowerline1Value);
				yLower2  = chartScale.GetYByValue(lowerline2Value);
				
				//Lines
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yUpper2);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yUpper2);
				RenderTarget.DrawLine(startPointDX, endPointDX, upperline2BrushDX, upperline2Width, Lines[0].StrokeStyle);
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yUpper1);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yUpper1);
				RenderTarget.DrawLine(startPointDX, endPointDX, upperline1BrushDX, upperline1Width, Lines[1].StrokeStyle);
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yMid);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yMid);
				RenderTarget.DrawLine(startPointDX, endPointDX, zerolineBrushDX, zerolineWidth, Lines[2].StrokeStyle);
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yLower1);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yLower1);
				RenderTarget.DrawLine(startPointDX, endPointDX, lowerline1BrushDX, lowerline1Width, Lines[3].StrokeStyle);
				startPointDX = new SharpDX.Vector2((float)ChartPanel.X, (float)yLower2);
				endPointDX	= new SharpDX.Vector2((float)ChartPanel.X + ChartPanel.W, (float)yLower2);
				RenderTarget.DrawLine(startPointDX, endPointDX, lowerline2BrushDX, lowerline2Width, Lines[4].StrokeStyle);

				// CRSI Shading
				if(applyShading)
				{	
					lastY = lastY0;
					lastSign = (int) CRSITrend.GetValueAt(lastIndex - displacement);
					startBar = lastIndex;
					firstLoop = true;
					do
					{
						SharpDX.Direct2D1.PathGeometry 	pathF;
						SharpDX.Direct2D1.GeometrySink 	sinkF;
						pathF = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
						using (pathF)
						{
							priorStartBar = startBar;
							if(firstLoop)
							{	
								count = 0;						
								if(nonEquidistant && displacement > 0 && startBar > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((startBar - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, startBar);
								if (lastSign == 1)
									plotArray[count] = new Vector2(x, yUpper1);
								else if(lastSign == -1)
									plotArray[count] = new Vector2(x, yLower1);
							}	
							else
							{	
								count = 0;
								plotArray[count] = new Vector2(lastX, lastY);
							}
							for (int idx = startBar; idx >= firstBarIndex; idx --)	
							{
								if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
									x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
								else
									x = ChartControl.GetXByBarIndex(ChartBars, idx);
								y = chartScale.GetYByValue(CRSI.GetValueAt(idx - displacement));   
								t = (int) CRSITrend.GetValueAt(idx - displacement);
								count = count + 1;
								if(t == lastSign)
								{
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = t;
									lastX = x;
									lastY = y;
								}	
								else if (t == 0 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper1 - lastY);
									double diff = Convert.ToDouble(yUpper1 - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper1;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 0 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower1 - lastY);
									double diff = Convert.ToDouble(yLower1 - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower1;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == 1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yUpper1 - lastY);
									double diff = Convert.ToDouble(yUpper1 - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper1;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 0)
								{	
									double lastDiff = Convert.ToDouble(yLower1 - lastY);
									double diff = Convert.ToDouble(yLower1 - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower1;
									plotArray[count] = new Vector2(x,y);
									startBar = idx;
									sign = lastSign;
									lastX = x;
									lastY = y;
									lastSign = t;
									break;
								}
								else if (t == -1 && lastSign == 1)
								{	
									double lastDiff = Convert.ToDouble(yUpper1 - lastY);
									double diff = Convert.ToDouble(yUpper1 - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yUpper1;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
								else if (t == 1 && lastSign == -1)
								{	
									double lastDiff = Convert.ToDouble(yLower1 - lastY);
									double diff = Convert.ToDouble(yLower1 - y);
									double denominator = lastDiff - diff;
									if(denominator.ApproxCompare(0) == 0)
										x = lastX - Convert.ToInt32((lastX - x) * 0.5);
									else	
										x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
									y = yLower1;
									plotArray[count] = new Vector2(x,y);
									sign = lastSign;
									startBar = idx;
									lastX = x;
									lastY = y;
									lastSign = 0;
									break;
								}
							}
							if(sign == 0)
							{	
								firstLoop = false;
								continue;
							}	
							if(startBar == firstBarIndex)
							{
								count = count + 1;
								if(sign == 1)
									plotArray[count] = new Vector2(lastX, yUpper1);
								else if(sign == -1)
									plotArray[count] = new Vector2(lastX, yLower1);
							}	
							sinkF = pathF.Open();
							sinkF.BeginFigure(plotArray[0], FigureBegin.Filled);
							for (int i = 1; i <= count; i++)
								sinkF.AddLine(plotArray[i]);
							sinkF.EndFigure(FigureEnd.Closed);
			        		sinkF.Close();
							RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
							if(sign == 1)
		 						RenderTarget.FillGeometry(pathF, overboughtAreaBrushDX);
							else if(sign == -1) 
		 						RenderTarget.FillGeometry(pathF, oversoldAreaBrushDX);
							RenderTarget.AntialiasMode = oldAntialiasMode;
						}
						pathF.Dispose();
						sinkF.Dispose();
						firstLoop = false;
					}	
					while (startBar > firstBarIndex && CRSI.IsValidDataPointAt(startBar - displacement));
				}
				
				// CRSI
				lastY = lastY0;
				lastSign = 5;
				startBar = lastIndex;
				firstLoop = true;
				do
				{
					SharpDX.Direct2D1.PathGeometry 	pathE;
					SharpDX.Direct2D1.GeometrySink 	sinkE;
					pathE = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
					using (pathE)
					{
						priorStartBar = startBar;
						if(firstLoop)
						{	
							count = 0;						
							if(nonEquidistant && displacement > 0 && startBar > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((startBar - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, startBar);
							plotArray[count] = new Vector2(x, yMid);
						}	
						else
						{	
							count = 0;
							plotArray[count] = new Vector2(lastX, lastY);
						}	
						for (int idx = startBar; idx >= firstBarIndex; idx --)	
						{
							if(nonEquidistant && displacement > 0 && idx > lastBarCounted)
								x = ChartControl.GetXByBarIndex(ChartBars, lastBarCounted) + (int)((idx - lastBarCounted) * barWidth);
							else
								x = ChartControl.GetXByBarIndex(ChartBars, idx);
							y = chartScale.GetYByValue(CRSI.GetValueAt(idx - displacement));   
							t = (int) CRSITrend.GetValueAt(idx - displacement);
							count = count + 1;
							if(t == lastSign)
							{
								plotArray[count] = new Vector2(x,y);
								sign = t;
								startBar = idx;
								lastX = x;
								lastY = y;
							}	
							else if(lastSign == 5)
							{	
								plotArray[count] = new Vector2(x,y);
								sign = 5;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}	
							else if (t == 0 && lastSign == 1)
							{	
								double lastDiff = Convert.ToDouble(yUpper1 - lastY);
								double diff = Convert.ToDouble(yUpper1 - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yUpper1;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}
							else if (t == 0 && lastSign == -1)
							{	
								double lastDiff = Convert.ToDouble(yLower1 - lastY);
								double diff = Convert.ToDouble(yLower1 - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yLower1;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}
							else if (t == 1 && lastSign == 0)
							{	
								double lastDiff = Convert.ToDouble(yUpper1 - lastY);
								double diff = Convert.ToDouble(yUpper1 - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yUpper1;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}
							else if (t == -1 && lastSign == 0)
							{	
								double lastDiff = Convert.ToDouble(yLower1 - lastY);
								double diff = Convert.ToDouble(yLower1 - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yLower1;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = t;
								break;
							}
							else if (t == -1 && lastSign == 1)
							{	
								double lastDiff = Convert.ToDouble(yUpper1 - lastY);
								double diff = Convert.ToDouble(yUpper1 - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yUpper1;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = 0;
								break;
							}
							else if (t == 1 && lastSign == -1)
							{	
								double lastDiff = Convert.ToDouble(yLower1 - lastY);
								double diff = Convert.ToDouble(yLower1 - y);
								double denominator = lastDiff - diff;
								if(denominator.ApproxCompare(0) == 0)
									x = lastX - Convert.ToInt32((lastX - x) * 0.5);
								else	
									x = lastX - Convert.ToInt32((lastX - x) * lastDiff / denominator);
								y = yLower1;
								plotArray[count] = new Vector2(x,y);
								sign = lastSign;
								startBar = idx;
								lastX = x;
								lastY = y;
								lastSign = 0;
								break;
							}
						}
						sinkE = pathE.Open();
						if(firstLoop)
							sinkE.BeginFigure(plotArray[1], FigureBegin.Filled);
						else
							sinkE.BeginFigure(plotArray[0], FigureBegin.Filled);
						for (int i = 1; i <= count; i++)
							sinkE.AddLine(plotArray[i]);
						sinkE.EndFigure(FigureEnd.Open);
		        		sinkE.Close();
						RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;
						if(sign == 1)
	 						RenderTarget.DrawGeometry(pathE, overboughtBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
						else if(sign == 0) 
	 						RenderTarget.DrawGeometry(pathE, neutralBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
						else if(sign == -1) 
	 						RenderTarget.DrawGeometry(pathE, oversoldBrushDX, Plots[0].Width, Plots[0].StrokeStyle);
						RenderTarget.AntialiasMode = oldAntialiasMode;
					}
					pathE.Dispose();
					sinkE.Dispose();
					firstLoop = false;
				}	
				while (startBar > firstBarIndex && CRSI.IsValidDataPointAt(startBar - displacement));
			}			
		}		
		#endregion		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaConnorsRSI[] cacheamaConnorsRSI;
		public LizardIndicators.amaConnorsRSI amaConnorsRSI(int rankPeriod, int streakPeriod, int rSIPeriod, double upperline2Value, double upperline1Value, double lowerline1Value, double lowerline2Value)
		{
			return amaConnorsRSI(Input, rankPeriod, streakPeriod, rSIPeriod, upperline2Value, upperline1Value, lowerline1Value, lowerline2Value);
		}

		public LizardIndicators.amaConnorsRSI amaConnorsRSI(ISeries<double> input, int rankPeriod, int streakPeriod, int rSIPeriod, double upperline2Value, double upperline1Value, double lowerline1Value, double lowerline2Value)
		{
			if (cacheamaConnorsRSI != null)
				for (int idx = 0; idx < cacheamaConnorsRSI.Length; idx++)
					if (cacheamaConnorsRSI[idx] != null && cacheamaConnorsRSI[idx].RankPeriod == rankPeriod && cacheamaConnorsRSI[idx].StreakPeriod == streakPeriod && cacheamaConnorsRSI[idx].RSIPeriod == rSIPeriod && cacheamaConnorsRSI[idx].Upperline2Value == upperline2Value && cacheamaConnorsRSI[idx].Upperline1Value == upperline1Value && cacheamaConnorsRSI[idx].Lowerline1Value == lowerline1Value && cacheamaConnorsRSI[idx].Lowerline2Value == lowerline2Value && cacheamaConnorsRSI[idx].EqualsInput(input))
						return cacheamaConnorsRSI[idx];
			return CacheIndicator<LizardIndicators.amaConnorsRSI>(new LizardIndicators.amaConnorsRSI(){ RankPeriod = rankPeriod, StreakPeriod = streakPeriod, RSIPeriod = rSIPeriod, Upperline2Value = upperline2Value, Upperline1Value = upperline1Value, Lowerline1Value = lowerline1Value, Lowerline2Value = lowerline2Value }, input, ref cacheamaConnorsRSI);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaConnorsRSI amaConnorsRSI(int rankPeriod, int streakPeriod, int rSIPeriod, double upperline2Value, double upperline1Value, double lowerline1Value, double lowerline2Value)
		{
			return indicator.amaConnorsRSI(Input, rankPeriod, streakPeriod, rSIPeriod, upperline2Value, upperline1Value, lowerline1Value, lowerline2Value);
		}

		public Indicators.LizardIndicators.amaConnorsRSI amaConnorsRSI(ISeries<double> input , int rankPeriod, int streakPeriod, int rSIPeriod, double upperline2Value, double upperline1Value, double lowerline1Value, double lowerline2Value)
		{
			return indicator.amaConnorsRSI(input, rankPeriod, streakPeriod, rSIPeriod, upperline2Value, upperline1Value, lowerline1Value, lowerline2Value);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaConnorsRSI amaConnorsRSI(int rankPeriod, int streakPeriod, int rSIPeriod, double upperline2Value, double upperline1Value, double lowerline1Value, double lowerline2Value)
		{
			return indicator.amaConnorsRSI(Input, rankPeriod, streakPeriod, rSIPeriod, upperline2Value, upperline1Value, lowerline1Value, lowerline2Value);
		}

		public Indicators.LizardIndicators.amaConnorsRSI amaConnorsRSI(ISeries<double> input , int rankPeriod, int streakPeriod, int rSIPeriod, double upperline2Value, double upperline1Value, double lowerline1Value, double lowerline2Value)
		{
			return indicator.amaConnorsRSI(input, rankPeriod, streakPeriod, rSIPeriod, upperline2Value, upperline1Value, lowerline1Value, lowerline2Value);
		}
	}
}

#endregion
