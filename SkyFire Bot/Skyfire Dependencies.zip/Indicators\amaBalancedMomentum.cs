//+----------------------------------------------------------------------------------------------+
//| Copyright © <2020>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The Balanced Momentum is an enhanced version of the standard momentum indicator. Standard momentum is often distorted by large bars dropping out of the calculation.
	/// The Balanced Momentum replaces the input value at the beginning of the lookback period with a triangular moving average and thus avoids the distortion.
	/// </summary>
	[Gui.CategoryOrder("Input Parameters", 1000100)]
	[Gui.CategoryOrder("Version", 8000100)]
	public class amaBalancedMomentum : Indicator
	{
		private int 				period 					= 14;
		private int 				smaPeriod				= 15;
		private double 				priorSum1				= 0.0;
		private double 				sum1					= 0.0;
		private double 				priorSum2				= 0.0;
		private double 				sum2					= 0.0;
		private double 				last1					= 0.0;
		private double 				last2					= 0.0;
		private string				versionString			= "v 1.2  -  March 7, 2020";
		private Series<double>		sma1;
		private Series<double>		sma2;	

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\n  The Balanced Momentum is an enhanced version of the standard momentum indicator. Standard momentum is often distorted by large bars dropping out of the calculation."
												+ " The Balanced Momentum replaces the input value at the beginning of the lookback period with a triangular moving average and thus avoids the distortion."; 
				Name						= "amaBalancedMomentum";
				IsSuspendedWhileInactive	= true;

				AddPlot(new Stroke(Brushes.Navy, 2), PlotStyle.Line, "BMomentum");
				AddLine(Brushes.DarkSlateGray, 0, "Zeroline");
			}
			else if (State == State.Configure)
			{
				BarsRequiredToPlot = 2 * (period + 1);
			}	
			else if (State == State.DataLoaded)
			{	
				smaPeriod = period + 1;
				sma1 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
				sma2 = new Series<double>(BarsArray[0], MaximumBarsLookBack.Infinite);
			}	
		}

		protected override void OnBarUpdate()
		{
			
			if (BarsArray[0].BarsType.IsRemoveLastBarSupported)
			{
				if (CurrentBar == 0)
				{	
					sma1[0] = Input[0];
					sma2[0] = Input[0];	
				}	
				else
				{
					last1 = sma1[1] * Math.Min(CurrentBar, smaPeriod);
					last2 = sma2[1] * Math.Min(CurrentBar, smaPeriod);
					if (CurrentBar >= smaPeriod)
					{	
						sma1[0] = (last1 + Input[0] - Input[smaPeriod]) / Math.Min(CurrentBar, smaPeriod);
						sma2[0] = (last2 + sma1[0] - sma1[smaPeriod]) / Math.Min(CurrentBar, smaPeriod);
					}	
					else
					{	
						sma1[0] = ((last1 + Input[0]) / (Math.Min(CurrentBar, smaPeriod) + 1));
						sma2[0] = ((last2 + sma1[0]) / (Math.Min(CurrentBar, smaPeriod) + 1));
					}	
				}
			}
			else
			{
				if (IsFirstTickOfBar)
				{	
					priorSum1 = sum1;
					priorSum2 = sum2;
				}	
				sum1 = priorSum1 + Input[0] - (CurrentBar >= smaPeriod ? Input[smaPeriod] : 0);
				sma1[0] = sum1 / (CurrentBar < Period ? CurrentBar + 1 : smaPeriod);
				sum2 = priorSum2 + sma1[0] - (CurrentBar >= smaPeriod ? sma1[smaPeriod] : 0);
				sma2[0] = sum2 / (CurrentBar < smaPeriod ? CurrentBar + 1 : smaPeriod);
			}
			BMomentum[0] = CurrentBar == 0 ? 0 : Input[0] - sma2[0];
		}

		#region Properties
		
        [Browsable(false)]	
        [XmlIgnore()]		
        public Series<double> BMomentum
        {
            get { return Values[0]; }
        }
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "Input Parameters", Order = 0)]
		public int Period
		{	
            get { return period; }
            set { period = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaBalancedMomentum[] cacheamaBalancedMomentum;
		public LizardIndicators.amaBalancedMomentum amaBalancedMomentum(int period)
		{
			return amaBalancedMomentum(Input, period);
		}

		public LizardIndicators.amaBalancedMomentum amaBalancedMomentum(ISeries<double> input, int period)
		{
			if (cacheamaBalancedMomentum != null)
				for (int idx = 0; idx < cacheamaBalancedMomentum.Length; idx++)
					if (cacheamaBalancedMomentum[idx] != null && cacheamaBalancedMomentum[idx].Period == period && cacheamaBalancedMomentum[idx].EqualsInput(input))
						return cacheamaBalancedMomentum[idx];
			return CacheIndicator<LizardIndicators.amaBalancedMomentum>(new LizardIndicators.amaBalancedMomentum(){ Period = period }, input, ref cacheamaBalancedMomentum);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaBalancedMomentum amaBalancedMomentum(int period)
		{
			return indicator.amaBalancedMomentum(Input, period);
		}

		public Indicators.LizardIndicators.amaBalancedMomentum amaBalancedMomentum(ISeries<double> input , int period)
		{
			return indicator.amaBalancedMomentum(input, period);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaBalancedMomentum amaBalancedMomentum(int period)
		{
			return indicator.amaBalancedMomentum(Input, period);
		}

		public Indicators.LizardIndicators.amaBalancedMomentum amaBalancedMomentum(ISeries<double> input , int period)
		{
			return indicator.amaBalancedMomentum(input, period);
		}
	}
}

#endregion
