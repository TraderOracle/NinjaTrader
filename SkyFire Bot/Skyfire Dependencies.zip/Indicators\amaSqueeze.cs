//+----------------------------------------------------------------------------------------------+
//| Copyright © <2021>  <LizardIndicators.com - powered by AlderLab UG>
//
//| This program is free software: you can redistribute it and/or modify
//| it under the terms of the GNU General Public License as published by
//| the Free Software Foundation, either version 3 of the License, or
//| any later version.
//|
//| This program is distributed in the hope that it will be useful,
//| but WITHOUT ANY WARRANTY; without even the implied warranty of
//| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//| GNU General Public License for more details.
//|
//| By installing this software you confirm acceptance of the GNU
//| General Public License terms. You may find a copy of the license
//| here; http://www.gnu.org/licenses/
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.Indicators.LizardIndicators;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators.LizardIndicators
{
	/// <summary>
	/// The Squeeze indicator allows for identifying low volatility and consolidating markets. The Bollinger squeeze detects low volatility by comparing the current width of the Bollinger Bands to the average width
	/// over the normalization period. The Bollinger-Keltner squeeze detects a consolidating market by comparing the width of Bollinger Bands to the width of the Keltner Channel. The 'squeeze' is on, when the Bollinger Bands
	/// are inside the Keltner Channel. The full squeeze is a combination of the Bollinger squeeze and the Bollinger-Keltner squeeze and detects low volatility during a consolidating market.
	/// </summary>
	[Gui.CategoryOrder("Algorithmic Options", 1000100)]
	[Gui.CategoryOrder("Input Parameters", 1000200)]
	[Gui.CategoryOrder("Bollinger Squeeze", 1000300)]
	[Gui.CategoryOrder("Trend Filter", 1000400)]
	[Gui.CategoryOrder("Trade Signals", 1000500)]
	[Gui.CategoryOrder("Display Options", 1000600)]
	[Gui.CategoryOrder("Paint Bars", 8000100)]
	[Gui.CategoryOrder("Sound Alerts", 8000200)]
	[Gui.CategoryOrder("Version", 8000300)]
	[TypeConverter("NinjaTrader.NinjaScript.Indicators.amaSqueezeTypeConverter")]
	public class amaSqueeze : Indicator
	{
		private int							volaPeriod					= 20;
		private int							squeezePeriod				= 120;
		private int							minSqueezeBars				= 3;
		private int							maxTriggerBars				= 6;
		private int							fastMomentumPeriod			= 10;
		private int							slowMomentumPeriod			= 25;
		private int							displacement				= 0;
		private int							totalBarsRequiredToPlot		= 0;
		private double						stdDevMultiplier			= 2.0;
		private double 						offsetMultiplier			= 1.5;
		private double						minSqueezeStrength			= 1.2;
		private double						diff0						= 0.0;
		private double						margin						= 0.0;
		private double						currentInput				= 0.0;
		private double						priorInput					= 0.0;
		private double 						priorMean					= 0.0;
		private double						priorSquareMean				= 0.0;
		private double						variance					= 0.0;
		private double						stdDev0						= 0.0;
		private double						zScoreStdDev0				= 0.0;
		private double						minDev0						= 0.0;
		private bool 						showTriangles 				= true;
		private bool 						showPaintBars 				= true;
		private bool						soundAlerts					= false;
		private bool						autoBarWidth				= true;
		private bool						calculateFromPriceData		= true;
		private bool						isLongTriggerBar			= false;
		private bool						isShortTriggerBar			= false;
		private bool						isSignalPlotted				= false;
		private bool						errorMessage				= false;
		private amaSqueezeType				squeezeType					= amaSqueezeType.Full_Squeeze;
		private SessionIterator				sessionIterator				= null;
		private Brush						volaBrush					= Brushes.SteelBlue;
		private Brush						trendBrush					= Brushes.Navy;
		private Brush						bbSqueezeBrush				= Brushes.Magenta;
		private Brush						kcSqueezeBrush				= Brushes.Cyan;
		private Brush						fullSqueezeBrush			= Brushes.Yellow;
		private Brush						lineBrush					= Brushes.DimGray;
		private Brush						upBrushUp					= Brushes.Lime;
		private Brush						upBrushDown					= Brushes.DarkGreen;
		private Brush						downBrushUp					= Brushes.LightCoral;
		private Brush						downBrushDown				= Brushes.Red;
		private Brush						neutralBrushUp				= Brushes.LightGray;
		private Brush						neutralBrushDown			= Brushes.DimGray;
		private Brush						upBrushOutline				= Brushes.Black;
		private Brush						downBrushOutline			= Brushes.Black;
		private Brush						neutralBrushOutline			= Brushes.Black;
		private Brush						signalBackBrush				= Brushes.Black;
		private Brush						alertBackBrush				= Brushes.Black;
		private Brush						errorBrush					= Brushes.Black;
		private SimpleFont					triangleFont				= null;
		private SimpleFont					errorFont;
		private int 						plot0Width 					= 7;
		private int 						plot1Width 					= 3;
		private int 						plot2Width 					= 3;
		private int 						lineWidth 					= 1;
		private DashStyleHelper				lineStyle					= DashStyleHelper.Solid;
		private int							triangleFontSize			= 7;
		private string						triangleStringUp			= "5";
		private string						triangleStringDown			= "6";
		private string						errorText1					= "The amaSqueeze only works on price data.";
		private string						errorText2					= "The amaSqueeze cannot be used with a negative displacement.";
		private int							rearmSeconds				= 30;
		private string 						squeezeAlert				= "squeezealert.wav";
		private string						endOfSqueezeAlert			= "endofsqueezealert.wav";
		private string 						longSignalAlert				= "longsignalalert.wav";
		private string 						shortSignalAlert			= "shortsignalalert.wav";
		private string						pathSqueezeAlert			= "";
		private string						pathEndOfSqueezeAlert		= "";
		private string						pathLongSignalAlert			= "";
		private string						pathShortSignalAlert		= "";
		private string						versionString				= "v 2.9  -  March 30, 2021";
		private Series<int>					bbSqueezeOn;
		private Series<int>					bbSqueezeCount;
		private Series<int>					kcSqueezeOn;
		private Series<int>					kcSqueezeCount;
		private Series<int>					squeezeCount;
		private Series<double>				diff;
		private Series<double>				logStdDev;
		private Series<double>				squares;
		private Series<double>				mean;
		private Series<double>				squareMean;
		private Series<double>				squeezeOn;
		private Series<double>				trend;
		private Series<double>				longSignal;
		private Series<double>				shortSignal;
		private amaATR						avgTrueRange;
		private amaATR						avgTrueRangeDiff;
		private amaStdDev					standardDeviation;
		private amaBalancedMomentum			fastMomentum;
		private amaBalancedMomentum			slowMomentum;
		private ATR							barVolatility;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "\r\nThe Squeeze indicator allows for identifying low volatility and consolidating markets. The Bollinger squeeze detects low volatility by comparing "
												+ "the current width of the Bollinger Bands to the average width over the normalization period. The Bollinger-Keltner squeeze detects a consolidating market " 
												+ "by comparing the width of Bollinger Bands to the width of the Keltner Channel. The 'squeeze' is on, when the Bollinger Bands are inside the Keltner Channel. " 
												+ "The full squeeze is a combination of the Bollinger squeeze and the Bollinger-Keltner squeeze and detects low volatility during a consolidating market."; 
				Name						= "amaSqueeze";
				IsSuspendedWhileInactive	= false;
				ArePlotsConfigurable		= false;
				AreLinesConfigurable		= false;
				DrawOnPricePanel			= true;
				AddPlot(new Stroke(Brushes.Gray, 5), PlotStyle.Bar, "ZScore LogStdDev");	
				AddPlot(new Stroke(Brushes.Gray, 3), PlotStyle.Bar, "Trend Strength");	
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "BB Squeeze Frame");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "BB Squeeze Dots");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "BB Keltner Squeeze Frame");
				AddPlot(new Stroke(Brushes.Gray, 2), PlotStyle.Dot, "BB Keltner Squeeze Dots");
				AddLine(Brushes.Gray, 0, "BB Keltner Squeeze");
				AddLine(Brushes.Gray, -1.2, "BB Squeeze");
			}
			else if (State == State.Configure)
			{
				if(Calculate == Calculate.OnEachTick)
					Calculate = Calculate.OnPriceChange;
				displacement = Displacement;
				BarsRequiredToPlot = Math.Max(squeezePeriod + volaPeriod, Math.Max(slowMomentumPeriod, -displacement));
				totalBarsRequiredToPlot = BarsRequiredToPlot + displacement;
				Plots[0].Brush = volaBrush;
				if(autoBarWidth)
					Plots[0].AutoWidth = true;
				else
				{	
					Plots[0].AutoWidth = false;
					Plots[0].Width = plot0Width;
				}	
				Plots[1].Brush = trendBrush;
				Plots[1].Width = plot1Width;
				Plots[2].Width = plot2Width + 1;
				Plots[3].Width = plot2Width;
				Plots[4].Width = plot2Width + 1;
				Plots[5].Width = plot2Width;
				if(squeezeType == amaSqueezeType.BB_Squeeze)
				{	
					Plots[4].Brush = Brushes.Transparent;
					Plots[5].Brush = Brushes.Transparent;
				}	
				else if(squeezeType == amaSqueezeType.BB_Keltner_Squeeze)
				{	
					Plots[2].Brush = Brushes.Transparent;
					Plots[3].Brush = Brushes.Transparent;
				}	
				Lines[0].Brush = lineBrush;
				Lines[0].Width 	= lineWidth; 
				Lines[0].DashStyleHelper = lineStyle;
				Lines[1].Brush = lineBrush;
				Lines[1].Width 	= lineWidth; 
				Lines[1].DashStyleHelper = lineStyle;
				Lines[1].Value = -minSqueezeStrength;
			}
			else if (State == State.DataLoaded)
			{
				bbSqueezeOn = new Series<int>(this, MaximumBarsLookBack.Infinite);
				bbSqueezeCount = new Series<int>(this, MaximumBarsLookBack.Infinite);
				kcSqueezeOn = new Series<int>(this, MaximumBarsLookBack.Infinite);
				kcSqueezeCount = new Series<int>(this, MaximumBarsLookBack.Infinite);
				squeezeCount = new Series<int>(this, MaximumBarsLookBack.Infinite);
				diff = new Series<double>(this, MaximumBarsLookBack.Infinite);
				logStdDev = new Series<double>(this, MaximumBarsLookBack.Infinite);
				squares = new Series<double>(this, squeezePeriod < 250 ? MaximumBarsLookBack.TwoHundredFiftySix : MaximumBarsLookBack.Infinite);
				mean = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				squareMean = new Series<double>(this, MaximumBarsLookBack.TwoHundredFiftySix);
				squeezeOn = new Series<double>(this, MaximumBarsLookBack.Infinite);
				trend = new Series<double>(this, MaximumBarsLookBack.Infinite);
				longSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
				shortSignal = new Series<double>(this, MaximumBarsLookBack.Infinite);
				avgTrueRange = amaATR(Inputs[0], amaATRCalcMode.Arithmetic, volaPeriod);				
				avgTrueRangeDiff = amaATR(Inputs[0], amaATRCalcMode.Arithmetic, squeezePeriod);				
				standardDeviation = amaStdDev(volaPeriod);
		    	fastMomentum = amaBalancedMomentum(fastMomentumPeriod);
				slowMomentum = amaBalancedMomentum(slowMomentumPeriod);
				barVolatility = ATR(Closes[0], 256);
				if(Input is PriceSeries)
					calculateFromPriceData = true;
				else
					calculateFromPriceData = false;
				sessionIterator = new SessionIterator(Bars);
			}	
			else if(State == State.Historical)
			{	
				minDev0 = TickSize / squeezePeriod;
				triangleFont = new SimpleFont("Webdings", 3*triangleFontSize);
				pathSqueezeAlert= string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, squeezeAlert);
				pathEndOfSqueezeAlert= string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, endOfSqueezeAlert);
				pathLongSignalAlert = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, longSignalAlert);
				pathShortSignalAlert = string.Format( @"{0}sounds\{1}", NinjaTrader.Core.Globals.InstallDir, shortSignalAlert);
				if(ChartBars != null)
				{	
					errorBrush = ChartControl.Properties.AxisPen.Brush;
					errorBrush.Freeze();
					errorFont = new SimpleFont("Arial", 24);
				}	
				if(!calculateFromPriceData)
				{
					Draw.TextFixed(this, "error text 1", errorText1, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
					errorMessage = true;
				}	
				else if(displacement < 0)
				{
					Draw.TextFixed(this, "error text 2", errorText2, TextPosition.Center, errorBrush, errorFont, Brushes.Transparent, Brushes.Transparent, 0);  
					errorMessage = true;
				}
			}	
		}

		protected override void OnBarUpdate()
		{
			if(errorMessage)
				return;
			
			stdDev0 = standardDeviation[0];
			logStdDev[0] = Math.Log10(Math.Max(stdDev0, minDev0));
			currentInput = logStdDev[0];
			squares[0] = currentInput * currentInput;
			if(CurrentBar == 0)
			{
				mean[0] = currentInput;
				squareMean[0] = squares[0];
				zScoreStdDev0 = 0.0;
			}	
			else	
			{	
				if(IsFirstTickOfBar)
				{
					priorMean = mean[1];
					priorSquareMean = squareMean[1];
				}	
				squares[0] = currentInput * currentInput;
				if(CurrentBar < squeezePeriod)
				{
					mean[0] = (CurrentBar * priorMean + currentInput)/(CurrentBar + 1);
					squareMean[0] = (CurrentBar * priorSquareMean + squares[0])/(CurrentBar + 1);
				}
				else
				{
					priorInput = logStdDev[squeezePeriod];
					mean[0] = priorMean + (currentInput - priorInput)/squeezePeriod;
					squareMean[0] = priorSquareMean + (squares[0] - squares[squeezePeriod])/squeezePeriod;
				}	
				variance = squareMean[0] - mean[0] * mean[0];
				if(variance.ApproxCompare(0) > 0)
					zScoreStdDev0 = (currentInput - mean[0])/Math.Sqrt(variance);
				else
					zScoreStdDev0 = 0.0;
			}
			ZScoreStdDev[0] = zScoreStdDev0;
			diff0 = stdDevMultiplier * stdDev0 - offsetMultiplier * avgTrueRange[0];
			diff[0] = diff0;
			TrendStrength[0] = diff0/avgTrueRangeDiff[0];
			Values[2][0] = -minSqueezeStrength;
			Values[3][0] = -minSqueezeStrength;
			Values[4][0] = 0.0;
			Values[5][0] = 0.0;
			
			if(CurrentBar < squeezePeriod)
			{
				bbSqueezeOn[0] = 0;
				bbSqueezeCount[0] = 0;
			}
			else if(zScoreStdDev0 < -minSqueezeStrength)
			{
				bbSqueezeOn[0] = 1;
				bbSqueezeCount[0] = bbSqueezeCount[1] + 1;
			}	
			else
			{
				bbSqueezeOn[0] = 0;
				bbSqueezeCount[0] = 0;
			}
			if(CurrentBar < volaPeriod)
			{
				kcSqueezeOn[0] = 0;
				kcSqueezeCount[0] = 0;
			}
			else if(diff0 < 0)
			{
				kcSqueezeOn[0] = 1;
				kcSqueezeCount[0] = squeezeCount[1] + 1;
			}	
			else
			{
				kcSqueezeOn[0] = 0;
				kcSqueezeCount[0] = 0;
			}
			
			if(squeezeType == amaSqueezeType.BB_Squeeze)
			{
				squeezeOn[0] = bbSqueezeOn[0];
				squeezeCount[0] = bbSqueezeCount[0];
				if(CurrentBar < squeezePeriod)
				{
					trend[0] = 0.0;
					longSignal[0] = 0.0;
					shortSignal[0] = 0.0;
					return;
				}
				if(squeezeOn[0] > 0.5)
				{	
					PlotBrushes[2][0] = Brushes.Black;
					PlotBrushes[3][0] = bbSqueezeBrush;
				}	
				else
				{	
					PlotBrushes[2][0] = Brushes.Transparent;
					PlotBrushes[3][0] = Brushes.Transparent;
				}	
			}
			else if(squeezeType == amaSqueezeType.BB_Keltner_Squeeze)
			{	
				squeezeOn[0] = kcSqueezeOn[0];
				squeezeCount[0] = kcSqueezeCount[0];
				if(CurrentBar < volaPeriod)
				{
					trend[0] = 0.0;
					longSignal[0] = 0.0;
					shortSignal[0] = 0.0;
					return;
				}
				if(squeezeOn[0] > 0.5)
				{	
					PlotBrushes[4][0] = Brushes.Black;
					PlotBrushes[5][0] = kcSqueezeBrush;
				}	
				else
				{	
					PlotBrushes[4][0] = Brushes.Transparent;
					PlotBrushes[5][0] = Brushes.Transparent;
				}	
			}	
			else if(squeezeType == amaSqueezeType.Full_Squeeze)
			{	
				squeezeOn[0] = Math.Max(0, bbSqueezeOn[0] + kcSqueezeOn[0] - 1);
				squeezeCount[0] = Math.Min(bbSqueezeCount[0], kcSqueezeCount[0]);
				if(CurrentBar < Math.Max(squeezePeriod, volaPeriod))
				{
					trend[0] = 0.0;
					longSignal[0] = 0.0;
					shortSignal[0] = 0.0;
					return;
				}
				if(squeezeOn[0] > 0.5)
				{	
					PlotBrushes[2][0] = Brushes.Black;
					PlotBrushes[3][0] = fullSqueezeBrush;
				}	
				else if(bbSqueezeOn[0] > 0.5)
				{	
					PlotBrushes[2][0] = Brushes.Black;
					PlotBrushes[3][0] = bbSqueezeBrush;
				}	
				else
				{
					PlotBrushes[2][0] = Brushes.Transparent;
					PlotBrushes[3][0] = Brushes.Transparent;
				}	
				if(squeezeOn[0] > 0.5)
				{	
					PlotBrushes[4][0] = Brushes.Black;
					PlotBrushes[5][0] = fullSqueezeBrush;
				}	
				else if(kcSqueezeOn[0] > 0.5)
				{	
					PlotBrushes[4][0] = Brushes.Black;
					PlotBrushes[5][0] = kcSqueezeBrush;
				}	
				else
				{
					PlotBrushes[4][0] = Brushes.Transparent;
					PlotBrushes[5][0] = Brushes.Transparent;
				}	
			}			
			
			if(CurrentBar < slowMomentumPeriod)
			{	
				trend[0] = 0.0;
				longSignal[0] = 0.0;
				shortSignal[0] = 0.0;
				return;	
			}	
			else if(fastMomentum[0] > 0 && slowMomentum[0] > 0)
				trend[0] = 1;
			else if (fastMomentum[0] < 0 && slowMomentum[0] < 0)
				trend[0] = -1;
			else
				trend[0] = 0;
			
			if(IsFirstTickOfBar)
			{	
				isLongTriggerBar = false;
				for (int i = 1; i <= maxTriggerBars; i++)
				{
					if(squeezeCount[i] >= minSqueezeBars )
					{	
						isLongTriggerBar = true;
						break;	
					}	
					else if (squeezeCount[i] > 0)
					{	
						isLongTriggerBar = false;
						break;
					}	
					else if (longSignal[i] > 0.5)
					{	
						isLongTriggerBar = false;
						break;
					}	
				}
				isShortTriggerBar = false;
				for (int i = 1; i <= maxTriggerBars; i++)
				{
					if(squeezeCount[i] >= minSqueezeBars )
					{	
						isShortTriggerBar = true;
						break;	
					}	
					else if (squeezeCount[i] > 0)
					{	
						isShortTriggerBar = false;
						break;	
					}	
					else if (shortSignal[i] > 0.5)
					{	
						isShortTriggerBar = false;
						break;
					}	
				}
			}	
			if(isLongTriggerBar && squeezeOn[0] < 0.5 && trend[0] > 0.5 && Close[0] > High[1] && Close[0] > Median[0])
			{	
				longSignal[0] = 1.0;
				shortSignal[0] = 0.0;
			}	
			else if (isShortTriggerBar && squeezeOn[0] < 0.5 && trend[0] < -0.5 && Close[0] < Low[1] && Close[0] < Median[0])
			{	
				longSignal[0] = 0.0;
				shortSignal[0] = 1.0;
			}
			else
			{	
				longSignal[0] = 0.0;
				shortSignal[0] = 0.0;
			}
			
			if(showTriangles)
			{	
				if(IsFirstTickOfBar)
				{	
					margin = barVolatility[1];
					isSignalPlotted = false;
				}	
				if(showTriangles)
				{	
					if (longSignal[0] > 0.5)
					{	
						Draw.Text(this, "signal" + CurrentBar, false, triangleStringUp, 0, Low[0] - 0.5*margin, - 3*triangleFontSize, upBrushUp, triangleFont, TextAlignment.Center, Brushes.Transparent, signalBackBrush, 100);
						isSignalPlotted = true;
					}	
					else if (shortSignal[0] > 0.5)
					{	
						Draw.Text(this, "signal" + CurrentBar, false, triangleStringDown, 0, High[0] + 0.5*margin, 6*triangleFontSize, downBrushDown, triangleFont, TextAlignment.Center, Brushes.Transparent, signalBackBrush, 100);
						isSignalPlotted = true;
					}	
					else if (isSignalPlotted)
					{	
						RemoveDrawObject("signal" + CurrentBar);
						isSignalPlotted = false;
					}
				}	
			}		
			
			if(showPaintBars && CurrentBar >= totalBarsRequiredToPlot)
			{
				if(trend[0] > 0.5)
				{	
					if(Open[0] < Close[0])
						BarBrushes[-displacement] = upBrushUp;
					else
						BarBrushes[-displacement] = upBrushDown;
					CandleOutlineBrushes[-displacement] = upBrushOutline;
				}
				else if (trend[0] < -0.5)
				{	
					if(Open[0] < Close[0])
						BarBrushes[-displacement] = downBrushUp;
					else
						BarBrushes[-displacement] = downBrushDown;
					CandleOutlineBrushes[-displacement] = downBrushOutline;
				}
				else
				{	
					if(Open[0] < Close[0])
						BarBrushes[-displacement] = neutralBrushUp;
					else
						BarBrushes[-displacement] = neutralBrushDown;
					CandleOutlineBrushes[-displacement] = neutralBrushOutline;
				}
			}
			
			if (soundAlerts && State == State.Realtime && IsConnected())
			{
				if(squeezeOn[0] > 0.5 && squeezeOn[1] < 0.5)		
				{
					try
					{
						if(squeezeType == amaSqueezeType.BB_Squeeze)	
							Alert("Squeeze", Priority.Medium, "Squeeze", pathSqueezeAlert, rearmSeconds, alertBackBrush, bbSqueezeBrush);
						else
							Alert("Squeeze", Priority.Medium, "Squeeze", pathSqueezeAlert, rearmSeconds, alertBackBrush, kcSqueezeBrush);
					}
					catch{}
				}
				else if(squeezeOn[0] < 0.5 && squeezeOn[1] > 0.5)		
				{
					try
					{
						if(squeezeType == amaSqueezeType.BB_Squeeze)	
							Alert("EndOfSqueeze", Priority.Medium, "End of Squeeze", pathEndOfSqueezeAlert, rearmSeconds, alertBackBrush, bbSqueezeBrush);
						else
							Alert("EndOfSqueeze", Priority.Medium, "End of Squeeze", pathEndOfSqueezeAlert, rearmSeconds, alertBackBrush, kcSqueezeBrush);
					}
					catch{}
				}
				if(longSignal[0] > 0.5)
				{
					try
					{
							Alert("LongSignal", Priority.Medium,"Long Entry", pathLongSignalAlert, rearmSeconds, alertBackBrush, upBrushUp);
					}
					catch{}
				}
				else if(shortSignal[0] > 0.5)
				{
					try
					{
							Alert("ShortSignal", Priority.Medium,"Short Entry", pathShortSignalAlert, rearmSeconds, alertBackBrush, downBrushDown);
					}
					catch{}
				}
			}	
		}

		#region Properties
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ZScoreStdDev
		{
			get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> TrendStrength
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> SqueezeOn
		{
			get { return squeezeOn; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Trend
		{
			get { return trend; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> LongSignal
		{
			get { return longSignal; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> ShortSignal
		{
			get { return shortSignal; }
		}
		
		[NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Squeeze type", Description = "Select between three different squeeze algorithms", GroupName = "Algorithmic Options", Order = 0)]
		public amaSqueezeType SqueezeType
		{	
            get { return squeezeType; }
            set { squeezeType = value; }
		}
			
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Lookback period", Description = "Sets the lookback period for Bollinger bands and Keltner channel", GroupName = "Input Parameters", Order = 0)]
		public int VolaPeriod
		{	
            get { return volaPeriod; }
            set { volaPeriod = value; }
		}
		
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Std. dev. multiplier", Description = "Select standard deviation multiplier for Bollinger Bands", GroupName = "Input Parameters", Order = 1)]
		public double StdDevMultiplier
		{	
            get { return stdDevMultiplier; }
            set { stdDevMultiplier = value; }
		}
		
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "ATR multiplier", Description = "Select offset multiplier for Keltner Channel", GroupName = "Input Parameters", Order = 2)]
		public double OffsetMultiplier
		{	
            get { return offsetMultiplier; }
            set { offsetMultiplier = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Normalization period", Description = "Select lookback period for detecting the Bollinger squeeze", GroupName = "Bollinger Squeeze", Order = 0)]
		public int SqueezePeriod
		{	
            get { return squeezePeriod; }
            set { squeezePeriod = value; }
		}
			
		[Range(0, double.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Squeeze strength", Description = "Sets the required strength for the Bollinger squeeze", GroupName = "Bollinger Squeeze", Order = 1)]
		public double MinSqueezeStrength
		{	
            get { return minSqueezeStrength; }
            set { minSqueezeStrength = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Fast momentum period", Description = "Sets the lookback period for the fast balanced momentum", GroupName = "Trend Filter", Order = 0)]
		public int FastMomentumPeriod
		{	
            get { return fastMomentumPeriod; }
            set { fastMomentumPeriod = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Slow momentum period", Description = "Sets the lookback period for the slow balanced momentum", GroupName = "Trend Filter", Order = 1)]
		public int SlowMomentumPeriod
		{	
            get { return slowMomentumPeriod; }
            set { slowMomentumPeriod = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Minimum squeeze bars", Description = "Sets the minimum number of squeeze bars necessary for generating a trade signal", GroupName = "Trade Signals", Order = 0)]
		public int MinSqueezeBars
		{	
            get { return minSqueezeBars; }
            set { minSqueezeBars = value; }
		}
		
		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Maximum trigger bars", Description = "Sets the maximum number of possible trigger bars after a squeeze ", GroupName = "Trade Signals", Order = 1)]
		public int MaxTriggerBars
		{	
            get { return maxTriggerBars; }
            set { maxTriggerBars = value; }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show paint bars", GroupName = "Display Options", Order = 0)]
  		[RefreshProperties(RefreshProperties.All)] 
       	public bool ShowPaintBars
        {
            get { return showPaintBars; }
            set { showPaintBars = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Show trade signals", GroupName = "Display Options", Order = 1)]
  		[RefreshProperties(RefreshProperties.All)] 
       	public bool ShowTriangles
        {
            get { return showTriangles; }
            set { showTriangles = value; }
        }
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Z-score volatility", Description = "Sets the color for the Z-score calculated from volatility", GroupName = "Plots", Order = 0)]
		public System.Windows.Media.Brush VolaBrush
		{ 
			get {return volaBrush;}
			set {volaBrush = value;}
		}

		[Browsable(false)]
		public string VolaBrushSerializable
		{
			get { return Serialize.BrushToString(volaBrush); }
			set { volaBrush = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Auto-adjust bar width", Description = "Auto-adjusts bar width of Z-score to match price bars", GroupName = "Plots", Order = 1)]
     	[RefreshProperties(RefreshProperties.All)] 
       	public bool AutoBarWidth
        {
            get { return autoBarWidth; }
            set { autoBarWidth = value; }
        }
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width z-score", Description = "Sets the plot width for the Z-score calculated from volatility", GroupName = "Plots", Order = 2)]
		public int Plot0Width
		{	
            get { return plot0Width; }
            set { plot0Width = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Trend strength", Description = "Sets the color for the trend strength", GroupName = "Plots", Order = 3)]
		public System.Windows.Media.Brush TrendBrush
		{ 
			get {return trendBrush;}
			set {trendBrush = value;}
		}

		[Browsable(false)]
		public string TrendBrushSerializable
		{
			get { return Serialize.BrushToString(trendBrush); }
			set { trendBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width trend strength", Description = "Sets the plot width for the trend strength", GroupName = "Plots", Order = 4)]
		public int Plot1Width
		{	
            get { return plot1Width; }
            set { plot1Width = value; }
		}
			
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "BB Squeeze dots", Description = "Sets the color for the BB squeeze dots", GroupName = "Plots", Order = 5)]
		public System.Windows.Media.Brush BBSqueezeBrush
		{ 
			get {return bbSqueezeBrush;}
			set {bbSqueezeBrush = value;}
		}

		[Browsable(false)]
		public string BBSqueezeBrushSerializable
		{
			get { return Serialize.BrushToString(bbSqueezeBrush); }
			set { bbSqueezeBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "BB Keltner Squeeze dots", Description = "Sets the color for the BB Keltner squeeze dots", GroupName = "Plots", Order = 6)]
		public System.Windows.Media.Brush KCSqueezeBrush
		{ 
			get {return kcSqueezeBrush;}
			set {kcSqueezeBrush = value;}
		}

		[Browsable(false)]
		public string KCSqueezeBrushSerializable
		{
			get { return Serialize.BrushToString(kcSqueezeBrush); }
			set { kcSqueezeBrush = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Full Squeeze dots", Description = "Sets the color for the full squeeze dots", GroupName = "Plots", Order = 7)]
		public System.Windows.Media.Brush FullSqueezeBrush
		{ 
			get {return fullSqueezeBrush;}
			set {fullSqueezeBrush = value;}
		}

		[Browsable(false)]
		public string FullSqueezeBrushSerializable
		{
			get { return Serialize.BrushToString(fullSqueezeBrush); }
			set { fullSqueezeBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width squeeze dots", Description = "Sets the plot width for the squeeze dots", GroupName = "Plots", Order = 8)]
		public int Plot2Width
		{	
            get { return plot2Width; }
            set { plot2Width = value; }
		}
		
		[Range(1, 256)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Triangle size", Description = "Allows for adjusting the triangle size", GroupName = "Plots", Order = 9)]
		public int TriangleFontSize
		{	
            get { return triangleFontSize; }
            set { triangleFontSize = value; }
		}
				
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Zeroline", Description = "Sets the color for the zeroline ", GroupName = "Lines", Order = 0)]
		public System.Windows.Media.Brush LineBrush
		{ 
			get {return lineBrush;}
			set {lineBrush = value;}
		}

		[Browsable(false)]
		public string LineBrushSerializable
		{
			get { return Serialize.BrushToString(lineBrush); }
			set { lineBrush = Serialize.StringToBrush(value); }
		}
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Plot width zeroline", Description = "Sets the plot width for the zeroline", GroupName = "Lines", Order = 1)]
		public int LineWidth
		{	
            get { return lineWidth; }
            set { lineWidth = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish Upclose", Description = "Sets the color for a bullish trend", GroupName = "Paint Bars", Order = 0)]
		public Brush UpBrushUp
		{ 
			get {return upBrushUp;}
			set {upBrushUp = value;}
		}

		[Browsable(false)]
		public string UpBrushUpSerializable
		{
			get { return Serialize.BrushToString(upBrushUp); }
			set { upBrushUp = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish Downclose", Description = "Sets the color for a bullish trend", GroupName = "Paint Bars", Order = 1)]
		public Brush UpBrushDown
		{ 
			get {return upBrushDown;}
			set {upBrushDown = value;}
		}

		[Browsable(false)]
		public string UpBrushDownSerializable
		{
			get { return Serialize.BrushToString(upBrushDown); }
			set { upBrushDown = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bullish candle outline", Description = "Sets the color for candle outlines", GroupName = "Paint Bars", Order = 2)]
		public Brush UpBrushOutline
		{ 
			get {return upBrushOutline;}
			set {upBrushOutline = value;}
		}

		[Browsable(false)]
		public string UpBrushOutlineSerializable
		{
			get { return Serialize.BrushToString(upBrushOutline); }
			set { upBrushOutline = Serialize.StringToBrush(value); }
		}					
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish Upclose", Description = "Sets the color for a bearish trend", GroupName = "Paint Bars", Order = 3)]
		public Brush DownBrushUp
		{ 
			get {return downBrushUp;}
			set {downBrushUp = value;}
		}

		[Browsable(false)]
		public string DownBrushUpSerializable
		{
			get { return Serialize.BrushToString(downBrushUp); }
			set { downBrushUp = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish Downclose", Description = "Sets the color for a bearish trend", GroupName = "Paint Bars", Order = 4)]
		public Brush DownBrushDown
		{ 
			get {return downBrushDown;}
			set {downBrushDown = value;}
		}

		[Browsable(false)]
		public string DownBrushDownSerializable
		{
			get { return Serialize.BrushToString(downBrushDown); }
			set { downBrushDown = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Bearish candle outline", Description = "Sets the color for candle outlines", GroupName = "Paint Bars", Order = 5)]
		public Brush DownBrushOutline
		{ 
			get {return downBrushOutline;}
			set {downBrushOutline = value;}
		}
		
		[Browsable(false)]
		public string DownBrushOutlineSerializable
		{
			get { return Serialize.BrushToString(downBrushOutline); }
			set { downBrushOutline = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Neutral Upclose", Description = "Sets the color for a neutral trend", GroupName = "Paint Bars", Order = 6)]
		public System.Windows.Media.Brush NeutralBrushUp
		{ 
			get {return neutralBrushUp;}
			set {neutralBrushUp = value;}
		}

		[Browsable(false)]
		public string NeutralBrushUpSerializable
		{
			get { return Serialize.BrushToString(neutralBrushUp); }
			set { neutralBrushUp = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Neutral Downclose", Description = "Sets the color for a neutral trend", GroupName = "Paint Bars", Order = 7)]
		public System.Windows.Media.Brush NeutralBrushDown
		{ 
			get {return neutralBrushDown;}
			set {neutralBrushDown = value;}
		}

		[Browsable(false)]
		public string NeutralBrushDownSerializable
		{
			get { return Serialize.BrushToString(neutralBrushDown); }
			set { neutralBrushDown = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Neutral candle outline", Description = "Sets the color for candle outlines", GroupName = "Paint Bars", Order = 8)]
		public System.Windows.Media.Brush NeutralBrushOutline
		{ 
			get {return neutralBrushOutline;}
			set {neutralBrushOutline = value;}
		}
		
		[Browsable(false)]
		public string NeutralBrushOutlineSerializable
		{
			get { return Serialize.BrushToString(neutralBrushOutline); }
			set { neutralBrushOutline = Serialize.StringToBrush(value); }
		}
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Sound alerts", GroupName = "Sound Alerts", Order = 0)]
        public bool SoundAlerts
        {
            get { return soundAlerts; }
            set { soundAlerts = value; }
        }
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Squeeze", Description = "Sound file for squeeze alert", GroupName = "Sound Alerts", Order = 1)]
		public string SqueezeAlert
		{	
            get { return squeezeAlert; }
            set { squeezeAlert = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "End of squeeze", Description = "Sound file for end of squeeze alert", GroupName = "Sound Alerts", Order = 2)]
		public string EndOfSqueezeAlert
		{	
            get { return endOfSqueezeAlert; }
            set { endOfSqueezeAlert = value; }
		}		

		[Display(ResourceType = typeof(Custom.Resource), Name = "Long signal", Description = "Sound file for long signal alert", GroupName = "Sound Alerts", Order = 3)]
		public string LongSignalAlert
		{	
            get { return longSignalAlert; }
            set { longSignalAlert = value; }
		}		
		
		[Display(ResourceType = typeof(Custom.Resource), Name = "Short signal", Description = "Sound file for short signal alert", GroupName = "Sound Alerts", Order = 4)]
		public string ShortSignalAlert
		{	
            get { return shortSignalAlert; }
            set { shortSignalAlert = value; }
		}		
		
		[Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Rearm seconds", Description = "Rearm time for alerts in seconds", GroupName = "Sound Alerts", Order = 5)]
		public int RearmSeconds
		{	
            get { return rearmSeconds; }
            set { rearmSeconds = value; }
		}
		
		[XmlIgnore]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Release and date", Description = "Release and date", GroupName = "Version", Order = 0)]
		public string VersionString
		{	
            get { return versionString; }
            set { ; }
		}
		#endregion
		
		#region Miscellaneous
		
		private bool IsConnected()
        {
			if ( Bars != null && Bars.Instrument.GetMarketDataConnection().PriceStatus == NinjaTrader.Cbi.ConnectionStatus.Connected
					&& sessionIterator.IsInSession(Now, true, true))
				return true;
			else
            	return false;
        }
		
		private DateTime Now
		{
          get 
			{ 
				DateTime now = (Bars.Instrument.GetMarketDataConnection().Options.Provider == NinjaTrader.Cbi.Provider.Playback ? Bars.Instrument.GetMarketDataConnection().Now : DateTime.Now); 

				if (now.Millisecond > 0)
					now = NinjaTrader.Core.Globals.MinDate.AddSeconds((long) System.Math.Floor(now.Subtract(NinjaTrader.Core.Globals.MinDate).TotalSeconds));

				return now;
			}
		}
		#endregion	
	}
}

namespace NinjaTrader.NinjaScript.Indicators
{		
	public class amaSqueezeTypeConverter : NinjaTrader.NinjaScript.IndicatorBaseConverter
	{
		public override bool GetPropertiesSupported(ITypeDescriptorContext context) { return true; }

		public override PropertyDescriptorCollection GetProperties(ITypeDescriptorContext context, object value, Attribute[] attributes)
		{
			PropertyDescriptorCollection propertyDescriptorCollection = base.GetPropertiesSupported(context) ? base.GetProperties(context, value, attributes) : TypeDescriptor.GetProperties(value, attributes);

			amaSqueeze			thisSqueezeInstance				= (amaSqueeze) value;
			bool				autoBarWidthFromInstance		= thisSqueezeInstance.AutoBarWidth;
			
			PropertyDescriptorCollection adjusted = new PropertyDescriptorCollection(null);
			
			foreach (PropertyDescriptor thisDescriptor in propertyDescriptorCollection)
			{
				if (autoBarWidthFromInstance && thisDescriptor.Name == "Plot0Width") 
					adjusted.Add(new PropertyDescriptorExtended(thisDescriptor, o => value, null, new Attribute[] {new BrowsableAttribute(false), }));
				else	
					adjusted.Add(thisDescriptor);
			}
			return adjusted;
		}
	}
}

#region Global Enums

public enum amaSqueezeType
{
	BB_Squeeze,
	BB_Keltner_Squeeze,
	Full_Squeeze
}
#endregion

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private LizardIndicators.amaSqueeze[] cacheamaSqueeze;
		public LizardIndicators.amaSqueeze amaSqueeze(amaSqueezeType squeezeType, int volaPeriod, double stdDevMultiplier, double offsetMultiplier, int squeezePeriod, double minSqueezeStrength, int fastMomentumPeriod, int slowMomentumPeriod, int minSqueezeBars, int maxTriggerBars)
		{
			return amaSqueeze(Input, squeezeType, volaPeriod, stdDevMultiplier, offsetMultiplier, squeezePeriod, minSqueezeStrength, fastMomentumPeriod, slowMomentumPeriod, minSqueezeBars, maxTriggerBars);
		}

		public LizardIndicators.amaSqueeze amaSqueeze(ISeries<double> input, amaSqueezeType squeezeType, int volaPeriod, double stdDevMultiplier, double offsetMultiplier, int squeezePeriod, double minSqueezeStrength, int fastMomentumPeriod, int slowMomentumPeriod, int minSqueezeBars, int maxTriggerBars)
		{
			if (cacheamaSqueeze != null)
				for (int idx = 0; idx < cacheamaSqueeze.Length; idx++)
					if (cacheamaSqueeze[idx] != null && cacheamaSqueeze[idx].SqueezeType == squeezeType && cacheamaSqueeze[idx].VolaPeriod == volaPeriod && cacheamaSqueeze[idx].StdDevMultiplier == stdDevMultiplier && cacheamaSqueeze[idx].OffsetMultiplier == offsetMultiplier && cacheamaSqueeze[idx].SqueezePeriod == squeezePeriod && cacheamaSqueeze[idx].MinSqueezeStrength == minSqueezeStrength && cacheamaSqueeze[idx].FastMomentumPeriod == fastMomentumPeriod && cacheamaSqueeze[idx].SlowMomentumPeriod == slowMomentumPeriod && cacheamaSqueeze[idx].MinSqueezeBars == minSqueezeBars && cacheamaSqueeze[idx].MaxTriggerBars == maxTriggerBars && cacheamaSqueeze[idx].EqualsInput(input))
						return cacheamaSqueeze[idx];
			return CacheIndicator<LizardIndicators.amaSqueeze>(new LizardIndicators.amaSqueeze(){ SqueezeType = squeezeType, VolaPeriod = volaPeriod, StdDevMultiplier = stdDevMultiplier, OffsetMultiplier = offsetMultiplier, SqueezePeriod = squeezePeriod, MinSqueezeStrength = minSqueezeStrength, FastMomentumPeriod = fastMomentumPeriod, SlowMomentumPeriod = slowMomentumPeriod, MinSqueezeBars = minSqueezeBars, MaxTriggerBars = maxTriggerBars }, input, ref cacheamaSqueeze);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.LizardIndicators.amaSqueeze amaSqueeze(amaSqueezeType squeezeType, int volaPeriod, double stdDevMultiplier, double offsetMultiplier, int squeezePeriod, double minSqueezeStrength, int fastMomentumPeriod, int slowMomentumPeriod, int minSqueezeBars, int maxTriggerBars)
		{
			return indicator.amaSqueeze(Input, squeezeType, volaPeriod, stdDevMultiplier, offsetMultiplier, squeezePeriod, minSqueezeStrength, fastMomentumPeriod, slowMomentumPeriod, minSqueezeBars, maxTriggerBars);
		}

		public Indicators.LizardIndicators.amaSqueeze amaSqueeze(ISeries<double> input , amaSqueezeType squeezeType, int volaPeriod, double stdDevMultiplier, double offsetMultiplier, int squeezePeriod, double minSqueezeStrength, int fastMomentumPeriod, int slowMomentumPeriod, int minSqueezeBars, int maxTriggerBars)
		{
			return indicator.amaSqueeze(input, squeezeType, volaPeriod, stdDevMultiplier, offsetMultiplier, squeezePeriod, minSqueezeStrength, fastMomentumPeriod, slowMomentumPeriod, minSqueezeBars, maxTriggerBars);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.LizardIndicators.amaSqueeze amaSqueeze(amaSqueezeType squeezeType, int volaPeriod, double stdDevMultiplier, double offsetMultiplier, int squeezePeriod, double minSqueezeStrength, int fastMomentumPeriod, int slowMomentumPeriod, int minSqueezeBars, int maxTriggerBars)
		{
			return indicator.amaSqueeze(Input, squeezeType, volaPeriod, stdDevMultiplier, offsetMultiplier, squeezePeriod, minSqueezeStrength, fastMomentumPeriod, slowMomentumPeriod, minSqueezeBars, maxTriggerBars);
		}

		public Indicators.LizardIndicators.amaSqueeze amaSqueeze(ISeries<double> input , amaSqueezeType squeezeType, int volaPeriod, double stdDevMultiplier, double offsetMultiplier, int squeezePeriod, double minSqueezeStrength, int fastMomentumPeriod, int slowMomentumPeriod, int minSqueezeBars, int maxTriggerBars)
		{
			return indicator.amaSqueeze(input, squeezeType, volaPeriod, stdDevMultiplier, offsetMultiplier, squeezePeriod, minSqueezeStrength, fastMomentumPeriod, slowMomentumPeriod, minSqueezeBars, maxTriggerBars);
		}
	}
}

#endregion
