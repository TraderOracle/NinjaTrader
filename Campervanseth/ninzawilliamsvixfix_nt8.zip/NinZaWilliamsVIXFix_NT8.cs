#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private ninZaWilliamsVIXFix[] cacheninZaWilliamsVIXFix;

		
		public ninZaWilliamsVIXFix ninZaWilliamsVIXFix(int topPeriod, int topBandPeriod, double topBandDeviation, int bottomPeriod, int bottomBandPeriod, double bottomBandDeviation)
		{
			return ninZaWilliamsVIXFix(Input, topPeriod, topBandPeriod, topBandDeviation, bottomPeriod, bottomBandPeriod, bottomBandDeviation);
		}


		
		public ninZaWilliamsVIXFix ninZaWilliamsVIXFix(ISeries<double> input, int topPeriod, int topBandPeriod, double topBandDeviation, int bottomPeriod, int bottomBandPeriod, double bottomBandDeviation)
		{
			if (cacheninZaWilliamsVIXFix != null)
				for (int idx = 0; idx < cacheninZaWilliamsVIXFix.Length; idx++)
					if (cacheninZaWilliamsVIXFix[idx].TopPeriod == topPeriod && cacheninZaWilliamsVIXFix[idx].TopBandPeriod == topBandPeriod && cacheninZaWilliamsVIXFix[idx].TopBandDeviation == topBandDeviation && cacheninZaWilliamsVIXFix[idx].BottomPeriod == bottomPeriod && cacheninZaWilliamsVIXFix[idx].BottomBandPeriod == bottomBandPeriod && cacheninZaWilliamsVIXFix[idx].BottomBandDeviation == bottomBandDeviation && cacheninZaWilliamsVIXFix[idx].EqualsInput(input))
						return cacheninZaWilliamsVIXFix[idx];
			return CacheIndicator<ninZaWilliamsVIXFix>(new ninZaWilliamsVIXFix(){ TopPeriod = topPeriod, TopBandPeriod = topBandPeriod, TopBandDeviation = topBandDeviation, BottomPeriod = bottomPeriod, BottomBandPeriod = bottomBandPeriod, BottomBandDeviation = bottomBandDeviation }, input, ref cacheninZaWilliamsVIXFix);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.ninZaWilliamsVIXFix ninZaWilliamsVIXFix(int topPeriod, int topBandPeriod, double topBandDeviation, int bottomPeriod, int bottomBandPeriod, double bottomBandDeviation)
		{
			return indicator.ninZaWilliamsVIXFix(Input, topPeriod, topBandPeriod, topBandDeviation, bottomPeriod, bottomBandPeriod, bottomBandDeviation);
		}


		
		public Indicators.ninZaWilliamsVIXFix ninZaWilliamsVIXFix(ISeries<double> input , int topPeriod, int topBandPeriod, double topBandDeviation, int bottomPeriod, int bottomBandPeriod, double bottomBandDeviation)
		{
			return indicator.ninZaWilliamsVIXFix(input, topPeriod, topBandPeriod, topBandDeviation, bottomPeriod, bottomBandPeriod, bottomBandDeviation);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.ninZaWilliamsVIXFix ninZaWilliamsVIXFix(int topPeriod, int topBandPeriod, double topBandDeviation, int bottomPeriod, int bottomBandPeriod, double bottomBandDeviation)
		{
			return indicator.ninZaWilliamsVIXFix(Input, topPeriod, topBandPeriod, topBandDeviation, bottomPeriod, bottomBandPeriod, bottomBandDeviation);
		}


		
		public Indicators.ninZaWilliamsVIXFix ninZaWilliamsVIXFix(ISeries<double> input , int topPeriod, int topBandPeriod, double topBandDeviation, int bottomPeriod, int bottomBandPeriod, double bottomBandDeviation)
		{
			return indicator.ninZaWilliamsVIXFix(input, topPeriod, topBandPeriod, topBandDeviation, bottomPeriod, bottomBandPeriod, bottomBandDeviation);
		}

	}
}

#endregion
