//
// ADIPRICELINETIMER
// Combines ADIPRICELINE (Ask/Bid/Last lines anchored to the current bar's X
// position) with ADITRADYBARTIMER (time/tick/volume countdown with alerts).
// The timer/counter text is rendered directly ON the chosen price line
// (default: Last), riding along it at a horizontal offset from the current
// bar, rather than floating above/below the bar's high/low.
//
// Two background states behind the text:
//   - BackColor       : always drawn, so the text reads clearly over candles/grid
//   - AlertBackColor  : swapped in when the configured alert condition trips,
//                       so it visually stands out
//
#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Data;
using NinjaTrader.Core.FloatingPoint;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public enum AdiPriceLineAttach
	{
		Ask,
		Bid,
		Last
	}

	public class ADIPRICELINETIMER : Indicator
	{
		private string displayText = string.Empty;
		private DateTime now = Core.Globals.Now;
		private bool timeFlag = false;
		private bool isAlert = false;
		private System.Windows.Threading.DispatcherTimer timer;
		private int barType, lastVBar, lastTKBar;
		private Gui.Tools.SimpleFont textFont;
		private TimeSpan timeAlertLevel;

		// SharpDX resources
		private SharpDX.DirectWrite.TextFormat textFormat;
		private SharpDX.Direct2D1.Brush textBrushDX;
		private SharpDX.Direct2D1.Brush alertTextBrushDX;
		private SharpDX.Direct2D1.Brush backBrushDX;
		private SharpDX.Direct2D1.Brush alertBackBrushDX;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description						= "Ask/Bid/Last price lines anchored to the current bar, with a bar timer/counter riding on the line.";
				Name							= "ADIPRICELINETIMER";
				Calculate						= Calculate.OnPriceChange;
				IsOverlay						= true;
				ShowTransparentPlotsInDataBox	= false;
				DrawOnPricePanel				= true;
				IsSuspendedWhileInactive 		= true;
				DisplayInDataBox				= false;

				// Lines
				ShowAskLine 					= false;
				ShowBidLine 					= false;
				ShowLastLine 					= true;
				AskStroke						= new Stroke(Brushes.DarkGreen, DashStyleHelper.Dash, 1);
				BidStroke						= new Stroke(Brushes.Blue, DashStyleHelper.Dash, 1);
				LastStroke						= new Stroke(Brushes.Yellow, DashStyleHelper.Dash, 1);

				// Timer text
				AttachTo						= AdiPriceLineAttach.Last;
				HorizontalOffsetPixels			= 60;
				ShowText						= false;
				textFont						= new Gui.Tools.SimpleFont("Arial", 14);
				TextColor						= Brushes.Black;
				TextAlertColor					= Brushes.Black;
				BackColor						= Brushes.Yellow;
				AlertBackColor					= Brushes.Red;

				// Alerts
				SoundsOn						= false;
				UpSoundFile						= @"C:\Program Files (x86)\NinjaTrader 8\sounds\Alert2.Wav";
				SetTickAlert					= false;
				SetTimeAlert					= false;
				SetVolumeAlert					= false;
				VolumeAlertLevel				= 100;
				TimeAlertLevel					= TimeSpan.Parse("00:00:10");
				TickAlertLevel					= 100;
			}
			else if (State == State.Configure)
			{
				AddPlot(ShowAskLine ? AskStroke.Brush : Brushes.Transparent,	"Ask");
				AddPlot(ShowBidLine ? BidStroke.Brush : Brushes.Transparent,	"Bid");
				AddPlot(ShowLastLine ? LastStroke.Brush : Brushes.Transparent,	"Last");
			}
			else if (State == State.DataLoaded)
			{
				// Determine bar type for the timer/counter
				if (BarsPeriod.BarsPeriodType == BarsPeriodType.Tick
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Tick)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Tick))
				{
					barType = 1;  // tick counter
				}
				else if (BarsPeriod.BarsPeriodType == BarsPeriodType.Volume
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Volume)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Volume))
				{
					barType = 2;  // volume counter
				}
				else if (BarsPeriod.BarsPeriodType == BarsPeriodType.Minute
					|| BarsPeriod.BarsPeriodType == BarsPeriodType.Second
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Minute)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Second)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Minute)
					|| (BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric && BarsPeriod.BaseBarsPeriodType == BarsPeriodType.Second))
				{
					barType = 3;  // time based
				}
				else
				{
					barType = 4;  // unsupported
					displayText = "Use Minute/Tick/Volume";
				}
			}
			else if (State == State.Realtime)
			{
				if (barType == 3 && timer == null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						timer = new System.Windows.Threading.DispatcherTimer { Interval = new TimeSpan(0, 0, 1), IsEnabled = true };
						timer.Tick += OnTimerTick;
					});
				}
			}
			else if (State == State.Terminated)
			{
				if (timer != null)
				{
					timer.IsEnabled = false;
					timer = null;
				}

				if (textFormat != null)		{ textFormat.Dispose(); textFormat = null; }
				if (textBrushDX != null)		{ textBrushDX.Dispose(); textBrushDX = null; }
				if (alertTextBrushDX != null)	{ alertTextBrushDX.Dispose(); alertTextBrushDX = null; }
				if (backBrushDX != null)		{ backBrushDX.Dispose(); backBrushDX = null; }
				if (alertBackBrushDX != null)	{ alertBackBrushDX.Dispose(); alertBackBrushDX = null; }
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < 1 || barType == 4 || barType == 3) return;

			// Volume counter
			if (barType == 2)
			{
				long vol = (long)Volume[0];
				double volumeCount = (BarsPeriod.BarsPeriodType == BarsPeriodType.HeikenAshi || BarsPeriod.BarsPeriodType == BarsPeriodType.Volumetric)
					? BarsPeriod.BaseBarsPeriodValue - vol
					: BarsPeriod.Value - vol;

				displayText = ShowText ? "Vol: " + volumeCount : volumeCount.ToString();
				isAlert = SetVolumeAlert && volumeCount <= VolumeAlertLevel;

				if (isAlert && CurrentBar != lastVBar && SoundsOn)
				{
					lastVBar = CurrentBar;
					PlaySound(UpSoundFile);
				}
			}

			// Tick counter
			if (barType == 1)
			{
				double periodValue = (BarsPeriod.BarsPeriodType == BarsPeriodType.Tick) ? BarsPeriod.Value : BarsPeriod.BaseBarsPeriodValue;
				double tickCount = periodValue - Bars.TickCount;
				displayText = ShowText ? "Ticks: " + tickCount : tickCount.ToString();
				isAlert = SetTickAlert && tickCount <= TickAlertLevel;

				if (isAlert && CurrentBar != lastTKBar && SoundsOn)
				{
					lastTKBar = CurrentBar;
					PlaySound(UpSoundFile);
				}
			}
		}

		private void OnTimerTick(object sender, EventArgs e)
		{
			if (ChartControl == null || Bars == null || Bars.Count < 2) return;

			TimeSpan barTimeLeft = Bars.GetTime(Bars.Count - 1).Subtract(Now);

			string timeLeft;
			if (barTimeLeft.Ticks < 0)
				timeLeft = "00:00";
			else if (barTimeLeft.TotalHours >= 1)
				timeLeft = barTimeLeft.Hours.ToString("00") + ":" + barTimeLeft.Minutes.ToString("00") + ":" + barTimeLeft.Seconds.ToString("00");
			else
				timeLeft = barTimeLeft.Minutes.ToString("00") + ":" + barTimeLeft.Seconds.ToString("00");

			displayText = ShowText ? "Time: " + timeLeft : timeLeft;
			isAlert = SetTimeAlert && barTimeLeft.TotalSeconds <= TimeAlertLevel.TotalSeconds && barTimeLeft.TotalSeconds > 0;

			if (isAlert && !timeFlag && SoundsOn)
			{
				timeFlag = true;
				PlaySound(UpSoundFile);
			}

			if (barTimeLeft.TotalSeconds <= 0)
				timeFlag = false;

			ChartControl.InvalidateVisual();
		}

		public override void OnCalculateMinMax()
		{
			double tmpMin = double.MaxValue;
			double tmpMax = double.MinValue;

			if (Values[0].Count > 0 && ShowAskLine && Values[0].IsValidDataPointAt(Values[0].Count - 1))
			{
				double askTmp = Values[0].GetValueAt(Values[0].Count - 1);
				tmpMin = Math.Min(tmpMin, askTmp);
				tmpMax = Math.Max(tmpMax, askTmp);
			}

			if (Values[1].Count > 0 && ShowBidLine && Values[1].IsValidDataPointAt(Values[1].Count - 1))
			{
				double bidTmp = Values[1].GetValueAt(Values[1].Count - 1);
				tmpMin = Math.Min(tmpMin, bidTmp);
				tmpMax = Math.Max(tmpMax, bidTmp);
			}

			if (Values[2].Count > 0 && ShowLastLine && Values[2].IsValidDataPointAt(Values[2].Count - 1))
			{
				double lastTmp = Values[2].GetValueAt(Values[2].Count - 1);
				tmpMin = Math.Min(tmpMin, lastTmp);
				tmpMax = Math.Max(tmpMax, lastTmp);
			}

			MinValue = tmpMin;
			MaxValue = tmpMax;
		}

		protected override void OnMarketData(MarketDataEventArgs e)
		{
			if (e.MarketDataType != MarketDataType.Last || CurrentBar < 0)
				return;

			Values[0][0] = e.Ask;
			Values[1][0] = e.Bid;
			Values[2][0] = e.Price;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (BarsArray[0] == null || ChartBars == null || CurrentBar < 0)
				return;

			ChartPanel	panel 	= chartControl.ChartPanels[chartScale.PanelIndex];
			float 		endX 	= panel.X + panel.W;

			// Pin the start of the lines to the current (last) bar's X pixel position.
			float startX = chartControl.GetXByBarIndex(ChartBars, CurrentBar);

			if (startX < panel.X)
				startX = panel.X;
			if (startX > endX)
				return;

			float? askY = null, bidY = null, lastY = null;

			if (Values[0].Count > 0 && ShowAskLine && Values[0].IsValidDataPointAt(Values[0].Count - 1))
			{
				askY = chartScale.GetYByValue(Values[0].GetValueAt(Values[0].Count - 1));
				RenderTarget.DrawLine(new SharpDX.Vector2(startX, askY.Value), new SharpDX.Vector2(endX, askY.Value), AskStroke.BrushDX, AskStroke.Width, AskStroke.StrokeStyle);
			}

			if (Values[1].Count > 0 && ShowBidLine && Values[1].IsValidDataPointAt(Values[1].Count - 1))
			{
				bidY = chartScale.GetYByValue(Values[1].GetValueAt(Values[1].Count - 1));
				RenderTarget.DrawLine(new SharpDX.Vector2(startX, bidY.Value), new SharpDX.Vector2(endX, bidY.Value), BidStroke.BrushDX, BidStroke.Width, BidStroke.StrokeStyle);
			}

			if (Values[2].Count > 0 && ShowLastLine && Values[2].IsValidDataPointAt(Values[2].Count - 1))
			{
				lastY = chartScale.GetYByValue(Values[2].GetValueAt(Values[2].Count - 1));
				RenderTarget.DrawLine(new SharpDX.Vector2(startX, lastY.Value), new SharpDX.Vector2(endX, lastY.Value), LastStroke.BrushDX, LastStroke.Width, LastStroke.StrokeStyle);
			}

			// --- Timer / counter text riding on the selected line ---
			if (string.IsNullOrEmpty(displayText))
				return;

			int attachIdx = (int)AttachTo; // Ask=0, Bid=1, Last=2
			if (Values[attachIdx].Count == 0 || !Values[attachIdx].IsValidDataPointAt(Values[attachIdx].Count - 1))
				return;

			float lineY = chartScale.GetYByValue(Values[attachIdx].GetValueAt(Values[attachIdx].Count - 1));

			if (textFormat == null)
			{
				textFormat = new SharpDX.DirectWrite.TextFormat(
					Core.Globals.DirectWriteFactory,
					textFont.Family.ToString(),
					SharpDX.DirectWrite.FontWeight.Bold,
					SharpDX.DirectWrite.FontStyle.Normal,
					(float)textFont.Size);
			}

			if (textBrushDX == null)
				textBrushDX = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDXHelperPLT.BrushToColor(TextColor));
			if (alertTextBrushDX == null)
				alertTextBrushDX = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDXHelperPLT.BrushToColor(TextAlertColor));
			if (backBrushDX == null)
				backBrushDX = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDXHelperPLT.BrushToColor(BackColor));
			if (alertBackBrushDX == null)
				alertBackBrushDX = new SharpDX.Direct2D1.SolidColorBrush(RenderTarget, SharpDXHelperPLT.BrushToColor(AlertBackColor));

			var textLayout = new SharpDX.DirectWrite.TextLayout(Core.Globals.DirectWriteFactory, displayText, textFormat, 200, 50);
			float textWidth  = textLayout.Metrics.Width;
			float textHeight = textLayout.Metrics.Height;

			const float padding = 3f;

			float drawX = startX + HorizontalOffsetPixels;
			// Keep the label from running off the right edge of the panel
			if (drawX + textWidth + padding > endX)
				drawX = endX - textWidth - padding;
			if (drawX < startX)
				drawX = startX;

			float drawY = lineY - textHeight / 2f;

			var backRect = new SharpDX.RectangleF(drawX - padding, drawY - padding, textWidth + padding * 2, textHeight + padding * 2);
			RenderTarget.FillRectangle(backRect, isAlert ? alertBackBrushDX : backBrushDX);

			RenderTarget.DrawTextLayout(new SharpDX.Vector2(drawX, drawY), textLayout, isAlert ? alertTextBrushDX : textBrushDX);

			textLayout.Dispose();
		}

		public override void OnRenderTargetChanged()
		{
			AskStroke	.RenderTarget = RenderTarget;
			BidStroke	.RenderTarget = RenderTarget;
			LastStroke	.RenderTarget = RenderTarget;

			if (textBrushDX != null)		{ textBrushDX.Dispose(); textBrushDX = null; }
			if (alertTextBrushDX != null)	{ alertTextBrushDX.Dispose(); alertTextBrushDX = null; }
			if (backBrushDX != null)		{ backBrushDX.Dispose(); backBrushDX = null; }
			if (alertBackBrushDX != null)	{ alertBackBrushDX.Dispose(); alertBackBrushDX = null; }
		}

		private DateTime Now
		{
			get
			{
				now = (Cbi.Connection.PlaybackConnection != null ? Cbi.Connection.PlaybackConnection.Now : Core.Globals.Now);
				if (now.Millisecond > 0)
					now = Core.Globals.MinDate.AddSeconds((long)Math.Floor(now.Subtract(Core.Globals.MinDate).TotalSeconds));
				return now;
			}
		}

		#region Properties
		[XmlIgnore]
		[Browsable(false)]
		public double AskLine => Values[0].GetValueAt(Values[0].Count - 1);

		[XmlIgnore]
		[Browsable(false)]
		public double BidLine => Values[1].GetValueAt(Values[1].Count - 1);

		[XmlIgnore]
		[Browsable(false)]
		public double LastLine => Values[2].GetValueAt(Values[2].Count - 1);

		// --- Lines ---
		[NinjaScriptProperty]
		[Display(Name = "ShowAskLine", GroupName = "Price Lines", Order = 0)]
		public bool ShowAskLine { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ShowBidLine", GroupName = "Price Lines", Order = 1)]
		public bool ShowBidLine { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ShowLastLine", GroupName = "Price Lines", Order = 2)]
		public bool ShowLastLine { get; set; }

		[Display(Name = "AskLineStroke", GroupName = "Price Lines", Order = 3)]
		public Stroke AskStroke { get; set; }

		[Display(Name = "BidLineStroke", GroupName = "Price Lines", Order = 4)]
		public Stroke BidStroke { get; set; }

		[Display(Name = "LastLineStroke", GroupName = "Price Lines", Order = 5)]
		public Stroke LastStroke { get; set; }

		// --- Timer text ---
		[Display(Name = "Attach timer to", Description = "Which line the timer/counter text rides on", Order = 0, GroupName = "Bar Timer")]
		public AdiPriceLineAttach AttachTo { get; set; }

		[Range(0, 500)]
		[Display(Name = "Horizontal offset (pixels)", Description = "Distance from the current bar to place the label along the line", Order = 1, GroupName = "Bar Timer")]
		public int HorizontalOffsetPixels { get; set; }

		[Display(Name = "Show label text", Description = "Show 'Time:' / 'Ticks:' / 'Vol:' prefix", Order = 2, GroupName = "Bar Timer")]
		public bool ShowText { get; set; }

		[Display(Name = "Text Font", GroupName = "Bar Timer", Order = 3)]
		public Gui.Tools.SimpleFont TextFont
		{
			get { return textFont; }
			set { textFont = value; }
		}

		[XmlIgnore]
		[Display(Name = "Text color", Order = 4, GroupName = "Bar Timer")]
		public System.Windows.Media.Brush TextColor { get; set; }

		[Browsable(false)]
		public string TextColorSerializable
		{
			get { return Serialize.BrushToString(TextColor); }
			set { TextColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Text color (alert)", Order = 5, GroupName = "Bar Timer")]
		public System.Windows.Media.Brush TextAlertColor { get; set; }

		[Browsable(false)]
		public string TextAlertColorSerializable
		{
			get { return Serialize.BrushToString(TextAlertColor); }
			set { TextAlertColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Background (constant)", Description = "Always-visible background behind the label", Order = 6, GroupName = "Bar Timer")]
		public System.Windows.Media.Brush BackColor { get; set; }

		[Browsable(false)]
		public string BackColorSerializable
		{
			get { return Serialize.BrushToString(BackColor); }
			set { BackColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Background (alert)", Description = "Swapped in when the alert condition trips", Order = 7, GroupName = "Bar Timer")]
		public System.Windows.Media.Brush AlertBackColor { get; set; }

		[Browsable(false)]
		public string AlertBackColorSerializable
		{
			get { return Serialize.BrushToString(AlertBackColor); }
			set { AlertBackColor = Serialize.StringToBrush(value); }
		}

		// --- Alerts ---
		[Display(Name = "Enable Tick Alert", Order = 0, GroupName = "Alerts")]
		public bool SetTickAlert { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Tick Alert level", Order = 1, GroupName = "Alerts")]
		public int TickAlertLevel { get; set; }

		[Display(Name = "Enable Time Alert", Order = 2, GroupName = "Alerts")]
		public bool SetTimeAlert { get; set; }

		[Display(Name = "Time Alert level", Order = 3, GroupName = "Alerts")]
		public TimeSpan TimeAlertLevel
		{
			get { return timeAlertLevel; }
			set { timeAlertLevel = value; }
		}

		[Browsable(false)]
		public string timeAlertLevelSerialize
		{
			get { return timeAlertLevel.ToString(); }
			set { timeAlertLevel = TimeSpan.Parse(value); }
		}

		[Display(Name = "Enable Volume Alert", Order = 4, GroupName = "Alerts")]
		public bool SetVolumeAlert { get; set; }

		[Range(1, int.MaxValue)]
		[Display(Name = "Volume Alert level", Order = 5, GroupName = "Alerts")]
		public int VolumeAlertLevel { get; set; }

		[Display(Name = "Sound Alert", Order = 6, GroupName = "Alerts")]
		public bool SoundsOn { get; set; }

		[Display(Name = "Alert sound file", Order = 7, GroupName = "Alerts")]
		[PropertyEditor("NinjaTrader.Gui.Tools.FilePathPicker", Filter = "Wav Files (*.wav)|*.wav")]
		public string UpSoundFile { get; set; }
		#endregion
	}

	public static class SharpDXHelperPLT
	{
		public static SharpDX.Color BrushToColor(System.Windows.Media.Brush brush)
		{
			var solidBrush = brush as System.Windows.Media.SolidColorBrush;
			if (solidBrush != null)
				return new SharpDX.Color(solidBrush.Color.R, solidBrush.Color.G, solidBrush.Color.B, solidBrush.Color.A);
			return SharpDX.Color.White;
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ADIPRICELINETIMER[] cacheADIPRICELINETIMER;
		public ADIPRICELINETIMER ADIPRICELINETIMER(bool showAskLine, bool showBidLine, bool showLastLine)
		{
			return ADIPRICELINETIMER(Input, showAskLine, showBidLine, showLastLine);
		}

		public ADIPRICELINETIMER ADIPRICELINETIMER(ISeries<double> input, bool showAskLine, bool showBidLine, bool showLastLine)
		{
			if (cacheADIPRICELINETIMER != null)
				for (int idx = 0; idx < cacheADIPRICELINETIMER.Length; idx++)
					if (cacheADIPRICELINETIMER[idx] != null && cacheADIPRICELINETIMER[idx].ShowAskLine == showAskLine && cacheADIPRICELINETIMER[idx].ShowBidLine == showBidLine && cacheADIPRICELINETIMER[idx].ShowLastLine == showLastLine && cacheADIPRICELINETIMER[idx].EqualsInput(input))
						return cacheADIPRICELINETIMER[idx];
			return CacheIndicator<ADIPRICELINETIMER>(new ADIPRICELINETIMER(){ ShowAskLine = showAskLine, ShowBidLine = showBidLine, ShowLastLine = showLastLine }, input, ref cacheADIPRICELINETIMER);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ADIPRICELINETIMER ADIPRICELINETIMER(bool showAskLine, bool showBidLine, bool showLastLine)
		{
			return indicator.ADIPRICELINETIMER(Input, showAskLine, showBidLine, showLastLine);
		}

		public Indicators.ADIPRICELINETIMER ADIPRICELINETIMER(ISeries<double> input , bool showAskLine, bool showBidLine, bool showLastLine)
		{
			return indicator.ADIPRICELINETIMER(input, showAskLine, showBidLine, showLastLine);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ADIPRICELINETIMER ADIPRICELINETIMER(bool showAskLine, bool showBidLine, bool showLastLine)
		{
			return indicator.ADIPRICELINETIMER(Input, showAskLine, showBidLine, showLastLine);
		}

		public Indicators.ADIPRICELINETIMER ADIPRICELINETIMER(ISeries<double> input , bool showAskLine, bool showBidLine, bool showLastLine)
		{
			return indicator.ADIPRICELINETIMER(input, showAskLine, showBidLine, showLastLine);
		}
	}
}

#endregion
