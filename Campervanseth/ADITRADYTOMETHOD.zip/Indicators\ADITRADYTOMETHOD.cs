// ADITRADYTOMETHOD - NinjaTrader 8 port of the Sierra Chart study "TO Method v4" (build 6).
// Contains only what the Sierra study contains: the scored REVERSAL signal (BUY / SELL / BUY+ / SELL+) with stop / target
// tracking, the TraderOracle trampoline, engulfing-at-band and squeeze dots, the Resistance Cloud (Nadaraya-Watson envelope),
// LITTLE RIZZY measured-move targets, the REVERSAL VOLUME PATTERNS, alerts 1-10, outer Bollinger alert bands and 30 colour themes.
// Evaluates on bar close only: Sierra's forming-bar evaluation, live target-before-stop and intrabar touch blink do not exist here
// (a bar that holds both the stop and the target counts as a stop).
// Original concept: TraderOracle (Mozilla Public License 2.0). Rendering approach follows ADITRADYNEWNEBULA.

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Data;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using DX  = SharpDX;
using D2D = SharpDX.Direct2D1;
using DW  = SharpDX.DirectWrite;
#endregion

#region Global enums
public enum ADITRADYTOMLineStyle { Solid, Dotted, Dashed }
public enum ADITRADYTOMDirection { Off, BuysOnly, SellsOnly, Both }
public enum ADITRADYTOMTagText { BuySell, LongShort }
public enum ADITRADYTOMAlert4Band { AlertBollinger, CloudInnerEdge }
public enum ADITRADYTOMTrampBand { AsTraderOracle, RequireBandTouch }
public enum ADITRADYTOMEngulfRule { OlympusEngulfingBB, ClassicEngulfingAtBand, ClassicEngulfingAnywhere }
public enum ADITRADYTOMTheme
{
	T01_ClassicNeon_dark,
	T02_MidnightOcean_dark,
	T03_EmeraldRuby_dark,
	T04_Solarized_dark,
	T05_NordAurora_dark,
	T06_Dracula_dark,
	T07_Monokai_dark,
	T08_Gruvbox_dark,
	T09_TokyoNight_dark,
	T10_CatppuccinMocha_dark,
	T11_TerminalAmber_dark,
	T12_Cyberpunk_dark,
	T13_AuroraBorealis_dark,
	T14_SunsetBoulevard_dark,
	T15_SteelCopper_dark,
	T16_ForestCanopy_dark,
	T17_RoyalVelvet_dark,
	T18_Graphite_dark,
	T19_Vaporwave_dark,
	T20_Tropical_dark,
	T21_TwilightRose_dark,
	T22_ColorSafe_dark,
	T23_PaperClassic_light,
	T24_Solarized_light,
	T25_SalmonPaper_light,
	T26_Nordic_light,
	T27_InkCoral_light,
	T28_EarthTones_light,
	T29_ColorSafe_light,
	T30_Monochrome_light,
	Custom
}

// Dropdown listing the .wav files in NinjaTrader's sounds folder (plus a blank "use default" entry).
public class ADITRADYTOMSoundConverter : TypeConverter
{
	public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
	public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return false; }
	public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
	{
		var list = new List<string> { "" };
		try
		{
			string dir = System.IO.Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds");
			if (System.IO.Directory.Exists(dir))
				list.AddRange(System.IO.Directory.GetFiles(dir, "*.wav")
					.Select(System.IO.Path.GetFileName)
					.OrderBy(f => f, StringComparer.OrdinalIgnoreCase));
		}
		catch { }
		return new StandardValuesCollection(list);
	}
}
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	public class ADITRADYTOMETHOD : Indicator
	{
		#region Constants
		private const int rsiLen = 14, bbLen = 20;
		private const double bbMult = 2.0;
		private const int waeFast = 20, waeSlow = 40;       // Waddah Explosion trend value (Little Rizzy break tag), standard LazyBear settings
		private const double waeSens = 150.0;
		#endregion

		#region Helper types
		private sealed class PEma
		{
			private readonly int len; private readonly double alpha;
			private readonly Queue<double> seed = new Queue<double>();
			public double Value = double.NaN;
			public PEma(int l, bool wilder = false) { len = Math.Max(1, l); alpha = wilder ? 1.0 / len : 2.0 / (len + 1); }
			public double Next(double x)
			{
				if (double.IsNaN(x) || double.IsInfinity(x)) { Value = double.NaN; seed.Clear(); return Value; }
				if (double.IsNaN(Value))
				{
					seed.Enqueue(x);
					if (seed.Count > len) seed.Dequeue();
					if (seed.Count == len) { double s = 0; foreach (double q in seed) s += q; Value = s / len; seed.Clear(); }
					return Value;
				}
				Value = alpha * x + (1 - alpha) * Value;
				return Value;
			}
		}

		private enum MKind { Glyph, Tag }

		private sealed class Marker
		{
			public int Bar; public bool Below; public string Text; public Color Col; public Color TextCol;
			public float Size; public string Tip; public MKind Kind; public bool InCloud; public double Price = double.NaN;
			public bool Filled; public double StemPrice = double.NaN, GlowPrice = double.NaN, GlowHalf; public Color GlowCol;
		}

		private sealed class HoverItem { public DX.RectangleF Rect; public string Tip; }
		private sealed class TpMark { public int Bar; public double Price; public bool IsBuy; public int SignalBar; }
		private sealed class GrailPend { public int Score, Flags; public double Stop, Target; public bool FP, FD, FQ, FT; }
		private sealed class GrailTrade { public int Bar; public bool IsBuy; public double Stop, Target; public int Score, Res, ResBar; }   // Res: 0 open, 1 target, -1 stop, 2 expired
		private sealed class RizLevel
		{
			public int SetupId, Dir, ExtIndex, TouchSide, TouchBar = -1, BrokenAt = -1, FrozenEnd = -1;
			public double Value, Distance; public bool Touched; public string BreakTxt;
			public DateTime BlinkStart = DateTime.MinValue;
		}
		#endregion

		#region Colour themes (from TO Method v4)
		private struct TomTheme
		{
			public Color Buy, Sell, BuyPlus, SellPlus, Trampoline, Squeeze, Volume, Target, Expired, CloudUpper, CloudLower;
			private static Color C(int[] v, int k) { return Color.FromRgb((byte)v[k * 3], (byte)v[k * 3 + 1], (byte)v[k * 3 + 2]); }
			public TomTheme(params int[] v)
			{
				Buy = C(v, 0); Sell = C(v, 1); BuyPlus = C(v, 2); SellPlus = C(v, 3); Trampoline = C(v, 4); Squeeze = C(v, 5);
				Volume = C(v, 6); Target = C(v, 7); Expired = C(v, 8); CloudUpper = C(v, 9); CloudLower = C(v, 10);
			}
		}
		// Same 30 themes, same order, as RG_THEMES in the Sierra Chart study (Custom = last enum value).
		private static readonly TomTheme[] TomThemes = new TomTheme[]
		{
			new TomTheme(0,230,255, 255,60,170, 0,230,255, 255,60,170, 230,30,30, 255,196,0, 0,128,255, 252,236,188, 176,73,14, 224,49,73, 0,168,107),
			new TomTheme(64,224,208, 255,127,80, 0,245,212, 255,99,64, 255,214,102, 180,160,255, 77,148,255, 200,230,255, 150,90,70, 190,90,80, 40,140,150),
			new TomTheme(46,204,113, 230,57,90, 0,230,118, 255,40,90, 241,196,15, 155,89,182, 52,152,219, 236,240,241, 140,100,60, 150,50,70, 30,120,90),
			new TomTheme(38,139,210, 203,75,22, 80,165,235, 230,100,40, 211,54,130, 181,137,0, 42,161,152, 238,232,213, 101,123,131, 170,60,55, 90,95,160),
			new TomTheme(163,190,140, 191,97,106, 143,214,120, 220,90,100, 180,142,173, 235,203,139, 136,192,208, 236,239,244, 160,105,85, 150,85,95, 94,129,172),
			new TomTheme(80,250,123, 255,85,85, 40,220,100, 255,60,60, 189,147,249, 241,250,140, 139,233,253, 255,184,108, 150,110,80, 190,80,140, 130,105,190),
			new TomTheme(166,226,46, 249,38,114, 140,210,20, 230,20,95, 253,151,31, 174,129,255, 102,217,239, 248,248,242, 150,120,90, 150,70,110, 70,130,150),
			new TomTheme(142,192,124, 251,73,52, 120,200,95, 255,100,70, 211,134,155, 250,189,47, 120,160,200, 235,219,178, 175,90,30, 165,100,60, 69,133,136),
			new TomTheme(115,218,202, 247,118,142, 80,235,205, 255,95,125, 187,154,247, 224,175,104, 158,206,106, 235,236,245, 170,110,75, 170,90,120, 70,110,180),
			new TomTheme(166,227,161, 243,139,168, 130,220,125, 240,110,150, 250,179,135, 203,166,247, 116,199,236, 249,226,175, 160,130,120, 180,110,140, 90,150,170),
			new TomTheme(60,220,100, 255,70,70, 0,255,110, 255,40,40, 255,176,0, 200,120,255, 70,140,255, 235,235,235, 140,100,40, 150,50,50, 40,120,70),
			new TomTheme(0,255,159, 255,0,110, 60,255,190, 255,60,150, 0,184,255, 252,238,10, 189,0,255, 255,140,0, 110,60,130, 150,20,90, 20,110,150),
			new TomTheme(120,255,200, 255,110,180, 60,240,170, 240,80,160, 180,130,255, 255,230,120, 90,170,255, 210,240,255, 120,100,150, 130,70,150, 40,130,120),
			new TomTheme(255,200,87, 255,94,98, 255,175,40, 255,60,80, 170,120,255, 100,210,255, 0,200,170, 235,225,245, 130,90,70, 170,70,90, 150,120,60),
			new TomTheme(110,180,230, 230,130,80, 70,160,240, 240,110,50, 190,120,220, 230,200,120, 120,200,170, 220,225,230, 130,90,70, 150,90,70, 70,110,140),
			new TomTheme(140,200,90, 215,100,70, 110,190,60, 230,80,50, 180,140,220, 240,210,110, 100,170,200, 215,225,235, 120,95,70, 140,80,60, 60,110,70),
			new TomTheme(255,200,70, 200,110,255, 255,180,20, 180,80,255, 255,100,120, 100,230,200, 90,150,255, 245,235,215, 130,80,100, 130,70,150, 150,120,50),
			new TomTheme(64,214,160, 240,96,96, 30,190,135, 225,70,70, 230,230,230, 210,180,100, 100,150,220, 185,175,215, 110,110,110, 120,95,100, 90,110,115),
			new TomTheme(1,205,254, 255,113,206, 0,170,255, 255,70,190, 255,251,150, 5,255,161, 185,103,255, 255,190,120, 120,80,130, 170,70,150, 60,90,170),
			new TomTheme(0,220,160, 255,90,95, 0,200,140, 255,60,70, 255,200,0, 190,120,255, 0,160,255, 255,240,210, 150,100,60, 170,70,90, 30,120,150),
			new TomTheme(150,215,170, 240,120,160, 110,210,150, 240,80,140, 255,190,110, 190,150,255, 100,200,220, 245,225,230, 130,90,110, 150,80,120, 80,130,110),
			new TomTheme(86,180,233, 235,110,20, 40,160,230, 213,94,0, 204,121,167, 240,228,66, 0,158,115, 230,230,230, 150,120,60, 180,90,40, 0,114,178),
			new TomTheme(0,140,90, 200,30,50, 0,120,75, 180,20,40, 230,110,0, 120,60,180, 20,90,200, 150,120,40, 170,140,130, 210,90,100, 60,160,120),
			new TomTheme(38,139,210, 220,50,47, 20,110,190, 200,30,30, 211,54,130, 181,137,0, 42,161,152, 88,110,117, 147,161,161, 210,110,80, 108,113,196),
			new TomTheme(0,153,77, 153,15,61, 0,130,65, 204,0,0, 225,105,20, 89,51,128, 15,84,153, 38,42,51, 190,160,140, 204,120,140, 120,170,60),
			new TomTheme(100,140,80, 191,97,106, 80,125,60, 170,70,80, 190,120,30, 150,100,150, 94,129,172, 76,86,106, 170,150,130, 200,130,135, 110,150,170),
			new TomTheme(0,110,130, 230,90,70, 0,90,110, 210,60,45, 140,50,170, 180,130,0, 60,140,60, 90,90,100, 190,150,140, 220,140,120, 90,160,170),
			new TomTheme(70,120,60, 170,70,40, 50,105,40, 150,50,25, 40,100,140, 175,125,25, 110,80,140, 100,80,60, 180,160,140, 190,120,90, 120,160,110),
			new TomTheme(0,114,178, 213,94,0, 0,90,150, 190,75,0, 204,121,167, 205,135,0, 0,158,115, 40,40,40, 170,170,170, 225,150,110, 86,180,233),
			new TomTheme(0,130,80, 190,40,40, 0,110,65, 165,25,25, 60,60,60, 130,130,130, 90,110,150, 120,100,70, 180,180,180, 175,150,150, 140,165,155),
		};
		#endregion

		#region Fields
		private readonly object sync = new object();

		private PEma rsiUp, rsiDn, eFast, eSlow, kAtr;
		private Series<double> sMacd, sYhC, sYhH, sYhL, sRange;
		private Series<double> sUN, sUA, sLN, sLA;                  // Resistance Cloud: upper near / avg, lower near / avg
		private double[] kernelW; private double kernelWSum; private int firstCloudBar = -1;

		// drawings
		private readonly Dictionary<int, List<Marker>> markers = new Dictionary<int, List<Marker>>();

		// ---- Reversal signal / volume patterns / TraderOracle patterns
		private PEma atrG; private double emaGrail = double.NaN;
		private Series<double> sTdBull, sTdBear, sUpperBB, sLowerBB, oGrail, oBull, oBear, oRiz;
		private Series<bool> sVolUp, sVolDn;
		private readonly List<GrailTrade> gTrades = new List<GrailTrade>();
		private readonly List<TpMark> tpMarks = new List<TpMark>();
		private int lastGrailBuy = -1000000, lastGrailSell = -1000000;
		private Color gBuyCol, gSellCol, gBuyPlusCol, gSellPlusCol, trampCol, squeezeCol, themeCloudUp, themeCloudDn;
		private GrailPend gPendBuy, gPendSell; private double gAtrNow = double.NaN;
		private bool v4TrBuy, v4TrSell, v4SqBuy, v4SqSell; private int sqState;
		private Series<double> sqA, sqD, sqH;
		private readonly Dictionary<int, int> engulfFlags = new Dictionary<int, int>();   // bar -> 1 bullish / 2 bearish engulfing at band

		// ---- Little Rizzy
		private readonly List<RizLevel> rizWatched = new List<RizLevel>();   // newest first; [0] = latest setup's target
		private readonly List<RizLevel> rizRetired = new List<RizLevel>();
		private bool rizActive; private int rizDir, rizSetupId;
		private double rizA1V, rizA2V, rizSlope, rizTarget; private int rizA1, rizA2;
		private int lastHighIdx = -1, prevHighIdx = -1, lastLowIdx = -1, prevLowIdx = -1;
		private double lastHighVal, prevHighVal, lastLowVal, prevLowVal;

		// rendering
		private readonly Dictionary<uint, D2D.SolidColorBrush> dxBrushes = new Dictionary<uint, D2D.SolidColorBrush>();
		private readonly Dictionary<string, DW.TextFormat> fmts = new Dictionary<string, DW.TextFormat>();
		private D2D.StrokeStyle dotStyle, dashStyle;
		private readonly List<HoverItem> hoverItems = new List<HoverItem>();
		private string hoverTip; private DX.Vector2 hoverPt; private bool mouseHooked;
		#endregion

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description = "TO Method v4 (Sierra Chart port): scored reversal signal, Little Rizzy, volume patterns, resistance cloud, TraderOracle trampoline / engulfing / squeeze dots, 30 colour themes.";
				Name = "ADITRADYTOMETHOD";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = false;
				DrawOnPricePanel = true;
				PaintPriceMarkers = false;
				IsSuspendedWhileInactive = true;
				ScaleJustification = ScaleJustification.Right;
				BarsRequiredToPlot = 0;

				ColorTheme = ADITRADYTOMTheme.T01_ClassicNeon_dark;
				GrailBuyBrush = TomFrozenBrush(Color.FromRgb(0, 230, 255));
				GrailSellBrush = TomFrozenBrush(Color.FromRgb(255, 60, 170));
				TrampBrush = TomFrozenBrush(Color.FromRgb(230, 30, 30)); SqueezeDotBrush = TomFrozenBrush(Color.FromRgb(255, 196, 0));
				VolumeBrush = TomFrozenBrush(Color.FromRgb(0, 128, 255)); RizTargetBrush = TomFrozenBrush(Color.FromRgb(252, 236, 188)); RizExpiredBrush = TomFrozenBrush(Color.FromRgb(176, 73, 14));
				CloudUpperBrush = TomFrozenBrush(Color.FromRgb(224, 49, 73)); CloudLowerBrush = TomFrozenBrush(Color.FromRgb(0, 168, 107));

				ShowCloud = true; CloudTransparency = 78; DrawBehindBars = true;
				KernelLookback = 256; KernelAlpha = 3.5; KernelStart = 30; KernelAtrLength = 66; NearFactor = 1.95; FarFactor = 7.0;

				ShowGrail = true; GrailTagText = ADITRADYTOMTagText.BuySell; GrailMinScore = 3; GrailLookback = 20; GrailPersistence = 6; GrailCooldown = 5;
				GrailUseVolume = true; GrailQuietVolume = 1.0; GrailClimaxVolume = 2.5; GrailEmaLength = 200; GrailBandVeto = 3.0; GrailWideRangeVeto = 1.6;
				GrailStopBuffer = 0.1; GrailMinRisk = 0.3; GrailTargetR = 1.5; GrailMaxTrack = 30; GrailShowStopTarget = false; GrailShowTp = false; GrailFontSize = 11; GrailTagBackground = true;
				GrailAlert4Band = ADITRADYTOMAlert4Band.AlertBollinger; GrailBandOnClose = false; GrailOpenEqTicks = 0;
				GrailTagOffsetAtr = 0.3; GrailPinStem = false; GrailPinStemLen = 1.0; GrailGlow = true; ShowOpenEqMarks = true;

				ShowSierraTramp = true; V4TrampMode = ADITRADYTOMTrampBand.AsTraderOracle; V4TrampRsiHigh = 80; V4TrampRsiLow = 20;
				ShowEngulf = true; EngulfRule = ADITRADYTOMEngulfRule.OlympusEngulfingBB; EngulfSkipDoji = true;
				ShowSierraSqueeze = false; SqueezeDotTicks = 2; ShowAlertBands = true;

				ShowVolPatterns = true; VolP1 = true; VolP2 = true; VolP3 = true; VolP4 = true; VolRsiFilter = true; VolRsiOB = 56; VolRsiOS = 44; VolColorByPattern = false; VolOffsetTicks = 4;
				ShowRizzy = true; RizPivotStrength = 3; RizMinAnchor = 3; RizBearish = true; RizBullish = true; RizInvalidate = true; RizNewReplaces = true;
				RizNumPrev = 0; RizExtendPrev = true; RizReversals = true; RizReversalWindow = 2; RizRequireColor = false; RizBreakTicks = 0;
				RizShowLabels = false; RizAlerts = false; RizTouchAlert = true; RizBlinkMs = 250; RizCollapsePct = 20; RizBrokenPct = 50;
				RizRevOffsetTicks = 3; RizTouchedWidth = 11; RizApproachWidth = 11; RizBaseWidth = 2; RizBrokenWidth = 3; RizZonePct = 50; RizFarFadePct = 50;

				EnableAlerts = true; AlertSound = "Alert2.wav";
				GrailAlertSignalDir = ADITRADYTOMDirection.Both; GrailAlertTargetDir = ADITRADYTOMDirection.Both;
				GrailAlertOpenEqDir = ADITRADYTOMDirection.Both; GrailAlertOpenEqBandDir = ADITRADYTOMDirection.Both;
				V4AlertTrampDir = ADITRADYTOMDirection.Off; V4AlertEngulfDir = ADITRADYTOMDirection.Off; V4AlertSqueezeDir = ADITRADYTOMDirection.Off;
				V4AlertWickDir = ADITRADYTOMDirection.Off; V4AlertSqCloudDir = ADITRADYTOMDirection.Off; V4AlertTrCloudDir = ADITRADYTOMDirection.Off;
				SndGrailSignal = ""; SndGrailTarget = ""; SndGrailOpenEq = ""; SndGrailOpenEqBand = ""; SndRizzy = ""; SndRizzyTouch = "";
				SndV4Tramp = ""; SndV4Engulf = ""; SndV4Squeeze = ""; SndV4SqCloud = ""; SndV4TrCloud = ""; SndWickCloud = "";
			}
			else if (State == State.Configure)
			{
				Calculate = Calculate.OnBarClose;
			}
			else if (State == State.DataLoaded)
			{
				InitColors();
				InitState();

				sMacd = S(); sYhC = S(); sYhH = S(); sYhL = S(); sRange = S();
				sUN = new Series<double>(this, MaximumBarsLookBack.Infinite);
				sUA = new Series<double>(this, MaximumBarsLookBack.Infinite);
				sLN = new Series<double>(this, MaximumBarsLookBack.Infinite);
				sLA = new Series<double>(this, MaximumBarsLookBack.Infinite);
				sTdBull = S(); sTdBear = S(); oGrail = S(); oBull = S(); oBear = S(); oRiz = S();
				sUpperBB = new Series<double>(this, MaximumBarsLookBack.Infinite);
				sLowerBB = new Series<double>(this, MaximumBarsLookBack.Infinite);
				sVolUp = B(); sVolDn = B();
				sqA = S(); sqD = S(); sqH = S();
			}
			else if (State == State.Historical)
			{
				if (DrawBehindBars) SetZOrder(-1);
				if (ChartControl != null && !mouseHooked)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						if (ChartPanel != null && !mouseHooked) { ChartPanel.MouseMove += OnPanelMouseMove; ChartPanel.MouseLeave += OnPanelMouseLeave; mouseHooked = true; }
					});
				}
			}
			else if (State == State.Terminated)
			{
				if (mouseHooked && ChartControl != null)
				{
					ChartControl.Dispatcher.InvokeAsync(() =>
					{
						if (ChartPanel != null) { ChartPanel.MouseMove -= OnPanelMouseMove; ChartPanel.MouseLeave -= OnPanelMouseLeave; }
					});
					mouseHooked = false;
				}
				DisposeDx();
				foreach (var f in fmts.Values) f.Dispose();
				fmts.Clear();
			}
		}

		private Series<double> S() { return new Series<double>(this); }
		private Series<bool> B() { return new Series<bool>(this); }

		private void InitState()
		{
			rsiUp = new PEma(rsiLen, true); rsiDn = new PEma(rsiLen, true);
			eFast = new PEma(waeFast); eSlow = new PEma(waeSlow); kAtr = new PEma(KernelAtrLength, true);

			// Rational quadratic kernel weights: the kernel averages KernelStart + 2 bars (as the library's loop is written)
			int n = KernelStart + 2;
			kernelW = new double[n]; kernelWSum = 0;
			double h2 = (double)KernelLookback * KernelLookback;
			for (int i = 0; i < n; i++)
			{
				double w = Math.Pow(1 + ((double)i * i) / (h2 * 2 * KernelAlpha), -KernelAlpha);
				kernelW[i] = w; kernelWSum += w;
			}
			firstCloudBar = -1;
			markers.Clear();
			atrG = new PEma(14, true); emaGrail = double.NaN; gTrades.Clear(); tpMarks.Clear();
			lastGrailBuy = lastGrailSell = -1000000;
			engulfFlags.Clear(); sqState = 0; gPendBuy = gPendSell = null; gAtrNow = double.NaN; v4TrBuy = v4TrSell = v4SqBuy = v4SqSell = false;
			rizWatched.Clear(); rizRetired.Clear(); rizActive = false; rizDir = 0; rizSetupId = 0;
			lastHighIdx = prevHighIdx = lastLowIdx = prevLowIdx = -1;
		}

		private void InitColors()
		{
			gBuyCol = TomBrushColor(GrailBuyBrush, Color.FromRgb(0, 230, 255));
			gSellCol = TomBrushColor(GrailSellBrush, Color.FromRgb(255, 60, 170));
			ApplyTheme();
		}

		// Colour theme: every marker colour of the signal / Rizzy / volume modules plus the cloud. Custom keeps the colour properties.
		private void ApplyTheme()
		{
			int ti = (int)ColorTheme;
			if (ti >= 0 && ti < TomThemes.Length)
			{
				TomTheme t = TomThemes[ti];
				gBuyCol = t.Buy; gSellCol = t.Sell; gBuyPlusCol = t.BuyPlus; gSellPlusCol = t.SellPlus;
				trampCol = t.Trampoline; squeezeCol = t.Squeeze; volArrowCol = t.Volume;
				rizTargetCol = t.Target; rizExpiredCol = t.Expired; cTpHit = t.Target; cRizInval = t.Expired;
				rizBrokenCol = Mix(Color.FromRgb(140, 140, 150), t.Target, 0.12);
				themeCloudUp = t.CloudUpper; themeCloudDn = t.CloudLower;
			}
			else
			{
				gBuyPlusCol = gBuyCol; gSellPlusCol = gSellCol;
				trampCol = TomBrushColor(TrampBrush, Color.FromRgb(230, 30, 30));
				squeezeCol = TomBrushColor(SqueezeDotBrush, Color.FromRgb(255, 196, 0));
				volArrowCol = TomBrushColor(VolumeBrush, Color.FromRgb(0, 128, 255));
				rizTargetCol = TomBrushColor(RizTargetBrush, Color.FromRgb(252, 236, 188));
				rizExpiredCol = TomBrushColor(RizExpiredBrush, Color.FromRgb(176, 73, 14));
				cTpHit = rizTargetCol; cRizInval = rizExpiredCol; rizBrokenCol = Color.FromRgb(140, 140, 150);
				themeCloudUp = TomBrushColor(CloudUpperBrush, Color.FromRgb(224, 49, 73));
				themeCloudDn = TomBrushColor(CloudLowerBrush, Color.FromRgb(0, 168, 107));
			}
		}

		protected override void OnBarUpdate()
		{
			lock (sync) { Compute(); }
		}

		private void Compute()
		{
			int cb = CurrentBar;
			double o = Open[0], h = High[0], l = Low[0], c = Close[0];
			bool isRed = c < o, isGreen = c > o;
			double c1 = cb > 0 ? Close[1] : double.NaN;
			double chg = cb > 0 ? c - c1 : double.NaN;

			// RSI(14), Wilder (volume patterns RSI filter)
			double upM = rsiUp.Next(double.IsNaN(chg) ? double.NaN : Math.Max(chg, 0));
			double dnM = rsiDn.Next(double.IsNaN(chg) ? double.NaN : -Math.Min(chg, 0));
			double rsiM = RsiFrom(upM, dnM);

			// Bollinger (20, 2): alert bands, trampoline, engulfing, open = prior close + band break
			double basisBB = Sma(Close, bbLen);
			double sd20 = Stdev(Close, bbLen);
			sUpperBB[0] = basisBB + bbMult * sd20; sLowerBB[0] = basisBB - bbMult * sd20;

			sRange[0] = h - l;   // volume pattern #4 (average bar range)

			// Waddah Explosion trend value (Little Rizzy break tag)
			double macd = eFast.Next(c) - eSlow.Next(c);
			sMacd[0] = macd;
			double t1 = cb > 0 ? (macd - sMacd[1]) * waeSens : double.NaN;

			// Resistance Cloud: Nadaraya-Watson rational quadratic envelope (non-repainting)
			double yC = double.NaN, yH = double.NaN, yL = double.NaN;
			if (cb >= KernelStart + 1)
			{
				double sc = 0, sh = 0, sl = 0;
				for (int i = 0; i < kernelW.Length; i++) { double w = kernelW[i]; sc += Close[i] * w; sh += High[i] * w; sl += Low[i] * w; }
				yC = sc / kernelWSum; yH = sh / kernelWSum; yL = sl / kernelWSum;
			}
			sYhC[0] = yC; sYhH[0] = yH; sYhL[0] = yL;
			double trK = double.NaN;
			if (!double.IsNaN(yC))
			{
				bool prevNa = cb == 0 || double.IsNaN(sYhH[1]);
				trK = prevNa ? yH - yL : Math.Max(Math.Max(yH - yL, Math.Abs(yH - sYhC[1])), Math.Abs(yL - sYhC[1]));
			}
			double ktr = kAtr.Next(trK);
			double upNear = yC + NearFactor * ktr, upFar = yC + FarFactor * ktr;
			double loNear = yC - NearFactor * ktr, loFar = yC - FarFactor * ktr;
			sUN[0] = upNear; sUA[0] = (upFar + upNear) / 2; sLN[0] = loNear; sLA[0] = (loFar + loNear) / 2;
			if (firstCloudBar < 0 && !double.IsNaN(upNear) && !double.IsNaN(loNear)) firstCloudBar = cb;
			bool brokeUp = h > upNear, brokeDown = l < loNear;

			// large-wick tests for the "large wick in cloud" alert
			bool upWick50 = isGreen && Math.Abs(h - c) > Math.Abs(o - c);
			bool downWick50 = isRed && Math.Abs(l - c) > Math.Abs(o - c);

			V4PatternStep(brokeUp, brokeDown, upWick50, downWick50);
			GrailStep();
			EmitV4Tags();
			VolStep(rsiM);
			RizzyStep(t1);
		}

		private void Fire(string tag, string instr, string what, string price, string soundFile)
		{
			string msg = "TO Method: " + instr + " | " + what + " @ " + price;
			string snd = string.IsNullOrWhiteSpace(soundFile) ? AlertSound : soundFile;
			Alert(tag, Priority.Medium, msg, NinjaTrader.Core.Globals.InstallDir + @"\sounds\" + snd, 0, Brushes.Black, Brushes.White);
		}

		#region Reversal Grail / Volume Patterns / Little Rizzy
		private const int grailDivFar = 30, grailDivNear = 6, grailAtrLen = 14, grailVolLen = 20, rizBlinkSteps = 6;
		private Color cTpHit = Color.FromRgb(255, 200, 60); private static readonly Color cRizRev = Color.FromRgb(255, 60, 220); private Color cRizInval = Color.FromRgb(255, 140, 0);
		private Color rizTargetCol = Color.FromRgb(252, 236, 188), rizBrokenCol = Color.FromRgb(140, 140, 150), rizExpiredCol = Color.FromRgb(176, 73, 14);
		private Color volArrowCol = Color.FromRgb(0, 128, 255);

		private static Color Mix(Color a, Color b, double t)
		{
			t = Math.Max(0, Math.Min(1, t));
			return Color.FromRgb((byte)Math.Round(a.R + (b.R - a.R) * t), (byte)Math.Round(a.G + (b.G - a.G) * t), (byte)Math.Round(a.B + (b.B - a.B) * t));
		}
		private static Color Contrast(Color c) { return 0.299 * c.R + 0.587 * c.G + 0.114 * c.B > 140 ? Color.FromRgb(20, 20, 20) : Colors.White; }
		private static string YN(bool b) { return b ? "yes" : "no"; }
		private string Instr() { return Instrument.MasterInstrument.Name + " " + TfLabel(); }
		private string Px(double v) { return Instrument.MasterInstrument.FormatPrice(v); }
		private bool DirOn(ADITRADYTOMDirection d, bool buy)
		{
			return d == ADITRADYTOMDirection.Both || (d == ADITRADYTOMDirection.BuysOnly && buy) || (d == ADITRADYTOMDirection.SellsOnly && !buy);
		}
		private DateTime BarOpenTime()
		{
			DateTime t = Time[0];
			switch (BarsPeriod.BarsPeriodType)
			{
				case BarsPeriodType.Minute: return t.AddMinutes(-BarsPeriod.Value);
				case BarsPeriodType.Second: return t.AddSeconds(-BarsPeriod.Value);
				default: return t;
			}
		}

		// Bollinger z-score of the close / relative volume at `ago` bars back (population std dev, like Pine)
		private bool ZAgo(int ago, int len, out double z)
		{
			z = 0;
			if (CurrentBar < ago + len - 1) return false;
			double sum = 0;
			for (int j = 0; j < len; j++) sum += Close[ago + j];
			double mean = sum / len, ss = 0;
			for (int j = 0; j < len; j++) { double d = Close[ago + j] - mean; ss += d * d; }
			double sd = Math.Sqrt(ss / len);
			if (sd <= 0) return false;
			z = (Close[ago] - mean) / sd;
			return true;
		}
		private bool RvAgo(int ago, int len, out double rv)
		{
			rv = 0;
			if (CurrentBar < ago + len - 1) return false;
			double sum = 0;
			for (int j = 0; j < len; j++) sum += Volume[ago + j];
			if (sum <= 0) return false;
			rv = Volume[ago] / (sum / len);
			return true;
		}

		// Did the bar `ago` bars back break the outer band (alert Bollinger band or cloud inner edge) on the signal's side?
		private bool BandBroken(int ago, bool isBuy)
		{
			if (CurrentBar < ago) return false;
			bool cloud = GrailAlert4Band == ADITRADYTOMAlert4Band.CloudInnerEdge;
			double lower = cloud ? sLN[ago] : sLowerBB[ago];
			double upper = cloud ? sUN[ago] : sUpperBB[ago];
			if (isBuy) return (GrailBandOnClose ? Close[ago] : Low[ago]) < lower;
			return (GrailBandOnClose ? Close[ago] : High[ago]) > upper;
		}

		// ------------------------------------------------------------------ REVERSAL GRAIL
		private void GrailStep()
		{
			int cb = CurrentBar;
			double o = Open[0], h = High[0], l = Low[0], c = Close[0];
			double tr = cb > 0 ? Math.Max(h - l, Math.Max(Math.Abs(h - Close[1]), Math.Abs(l - Close[1]))) : h - l;
			double atr = atrG.Next(tr);
			gAtrNow = atr; gPendBuy = null; gPendSell = null;
			emaGrail = double.IsNaN(emaGrail) ? c : emaGrail + (2.0 / (GrailEmaLength + 1.0)) * (c - emaGrail);
			sTdBull[0] = (cb >= 4 && c < Close[4]) ? sTdBull[1] + 1 : 0;
			sTdBear[0] = (cb >= 4 && c > Close[4]) ? sTdBear[1] + 1 : 0;
			oGrail[0] = 0; oBull[0] = 0; oBear[0] = 0;
			if (!ShowGrail) return;
			bool live = EnableAlerts && State == State.Realtime;

			// ---- stop / target tracking (stop is checked first when one bar holds both)
			for (int n = 0; n < gTrades.Count; n++)
			{
				GrailTrade t = gTrades[n];
				if (t.Res != 0 || cb <= t.Bar) continue;
				bool hitStop = t.IsBuy ? l <= t.Stop : h >= t.Stop;
				bool hitTgt = t.IsBuy ? h >= t.Target : l <= t.Target;
				if (hitStop) { t.Res = -1; t.ResBar = cb; }
				else if (hitTgt)
				{
					t.Res = 1; t.ResBar = cb;
					tpMarks.Add(new TpMark { Bar = cb, Price = t.Target, IsBuy = t.IsBuy, SignalBar = t.Bar });
					if (tpMarks.Count > 500) tpMarks.RemoveAt(0);
					if (live && DirOn(GrailAlertTargetDir, t.IsBuy))
						Fire("TOM_GrailTP" + t.Bar + "_" + cb, Instr(), "Grail " + (t.IsBuy ? "BUY" : "SELL") + " target hit at " + Px(t.Target) + ", stop not hit (signal " + (cb - t.Bar) + " bars ago)", Px(c), SndGrailTarget);
				}
				else if (cb - t.Bar >= GrailMaxTrack) { t.Res = 2; t.ResBar = cb; }
			}
			if (gTrades.Count > 600) gTrades.RemoveRange(0, 100);

			int warm = Math.Max(Math.Max(GrailLookback, grailDivFar), Math.Max(bbLen + 2, grailAtrLen));
			if (cb < warm || double.IsNaN(atr) || atr <= 0) return;

			double rangeATR = (h - l) / atr;
			bool vetoLowZ = false, vetoHighZ = false, vetoVol = false;
			for (int a = 0; a <= 2; a++)
			{
				double zz, rvv;
				if (ZAgo(a, bbLen, out zz))
				{
					if (zz < -GrailBandVeto) vetoLowZ = true;
					if (zz > GrailBandVeto) vetoHighZ = true;
				}
				if (GrailUseVolume && RvAgo(a, grailVolLen, out rvv) && rvv > GrailClimaxVolume) vetoVol = true;
			}
			bool commonVeto = rangeATR > GrailWideRangeVeto || vetoVol;
			double tdMaxBull = 0, tdMaxBear = 0;
			for (int a = 0; a <= 4; a++) { tdMaxBull = Math.Max(tdMaxBull, sTdBull[a]); tdMaxBear = Math.Max(tdMaxBear, sTdBear[a]); }
			double openEqTol = (GrailOpenEqTicks + 0.5) * TickSize;
			bool openEq = cb > 0 && Math.Abs(o - Close[1]) <= openEqTol;

			// ---- BULLISH
			bool atLow = true;
			for (int j = 1; j < GrailLookback; j++) if (Low[j] < l) { atLow = false; break; }
			if (atLow && !commonVeto && !vetoLowZ)
			{
				int score = 0; bool fP = false, fD = false, fQ = false, fT = false;
				if (tdMaxBull >= GrailPersistence) { score++; fP = true; }
				int r = 0;
				for (int a = 2; a >= 0; a--) if (Low[a] < Low[r]) r = a;
				int pv = grailDivFar;
				for (int a = grailDivFar; a >= grailDivNear; a--) if (Low[a] < Low[pv]) pv = a;
				double z1, z0, rv;
				if (Low[r] < Low[pv] && ZAgo(r, bbLen, out z1) && ZAgo(pv, bbLen, out z0) && z1 > z0) { score++; fD = true; }
				if (GrailUseVolume && RvAgo(r, grailVolLen, out rv) && rv < GrailQuietVolume) { score++; fQ = true; }
				if (c > emaGrail) { score++; fT = true; }
				oBull[0] = score;
				if (score >= GrailMinScore && cb - lastGrailBuy > GrailCooldown)
				{
					lastGrailBuy = cb;
					double risk = Math.Max(c - (l - GrailStopBuffer * atr), GrailMinRisk * atr);
					double stop = c - risk, target = c + GrailTargetR * risk;
					gTrades.Add(new GrailTrade { Bar = cb, IsBuy = true, Stop = stop, Target = target, Score = score });
					int flags = (openEq ? 1 : 0) | ((BandBroken(0, true) || BandBroken(1, true)) ? 2 : 0);
					oGrail[0] = score; 
					gPendBuy = new GrailPend { Score = score, Flags = flags, Stop = stop, Target = target, FP = fP, FD = fD, FQ = fQ, FT = fT };
					GrailAlert(true, score, flags, stop, target);
				}
			}

			// ---- BEARISH (mirror)
			bool atHigh = true;
			for (int j = 1; j < GrailLookback; j++) if (High[j] > h) { atHigh = false; break; }
			if (atHigh && !commonVeto && !vetoHighZ)
			{
				int score = 0; bool fP = false, fD = false, fQ = false, fT = false;
				if (tdMaxBear >= GrailPersistence) { score++; fP = true; }
				int r = 0;
				for (int a = 2; a >= 0; a--) if (High[a] > High[r]) r = a;
				int pv = grailDivFar;
				for (int a = grailDivFar; a >= grailDivNear; a--) if (High[a] > High[pv]) pv = a;
				double z1, z0, rv;
				if (High[r] > High[pv] && ZAgo(r, bbLen, out z1) && ZAgo(pv, bbLen, out z0) && z1 < z0) { score++; fD = true; }
				if (GrailUseVolume && RvAgo(r, grailVolLen, out rv) && rv < GrailQuietVolume) { score++; fQ = true; }
				if (c < emaGrail) { score++; fT = true; }
				oBear[0] = score;
				if (score >= GrailMinScore && cb - lastGrailSell > GrailCooldown)
				{
					lastGrailSell = cb;
					double risk = Math.Max((h + GrailStopBuffer * atr) - c, GrailMinRisk * atr);
					double stop = c + risk, target = c - GrailTargetR * risk;
					gTrades.Add(new GrailTrade { Bar = cb, IsBuy = false, Stop = stop, Target = target, Score = score });
					int flags = (openEq ? 1 : 0) | ((BandBroken(0, false) || BandBroken(1, false)) ? 2 : 0);
					if (oGrail[0] == 0) oGrail[0] = -score;
					
					gPendSell = new GrailPend { Score = score, Flags = flags, Stop = stop, Target = target, FP = fP, FD = fD, FQ = fQ, FT = fT };
					GrailAlert(false, score, flags, stop, target);
				}
			}
		}

		private string GrailTip(bool isBuy, int score, int flags, double stop, double target, bool fP, bool fD, bool fQ, bool fT)
		{
			bool cloudBand = GrailAlert4Band == ADITRADYTOMAlert4Band.CloudInnerEdge;
			return "REVERSAL GRAIL " + (isBuy ? "BUY" : "SELL") + "  \u00B7  score " + score + "/4"
				+ "\nPersistence (TD count): " + YN(fP)
				+ "\n%B momentum divergence: " + YN(fD)
				+ "\nQuiet volume: " + YN(fQ)
				+ "\nTrend side (EMA " + GrailEmaLength + "): " + YN(fT)
				+ "\n\nStop " + Px(stop) + "   Target " + Px(target) + " (" + GrailTargetR.ToString("0.0#", CultureInfo.InvariantCulture) + "R)"
				+ ((flags & 1) != 0 ? "\nSignal bar opened at the prior close" : "")
				+ ((flags & 2) != 0 ? "\nBroke the outer " + (cloudBand ? "cloud edge" : "Bollinger band") : "");
		}

		// One combined alert per signal; the sound is the most specific alert that matched (open=close+band > open=close > signal).
		private void GrailAlert(bool isBuy, int score, int flags, double stop, double target)
		{
			if (!EnableAlerts || State != State.Realtime) return;
			string snd = null;
			if (DirOn(GrailAlertSignalDir, isBuy)) snd = SndGrailSignal;
			if ((flags & 1) != 0 && DirOn(GrailAlertOpenEqDir, isBuy)) snd = SndGrailOpenEq;
			if ((flags & 3) == 3 && DirOn(GrailAlertOpenEqBandDir, isBuy)) snd = SndGrailOpenEqBand;
			if (snd == null) return;
			string what = "Grail " + (isBuy ? "BUY" : "SELL") + " signal, score " + score
				+ ((flags & 1) != 0 ? ", open = prior close" : "")
				+ ((flags & 2) != 0 ? (GrailAlert4Band == ADITRADYTOMAlert4Band.CloudInnerEdge ? ", cloud break" : ", band break") : "")
				+ ", stop " + Px(stop) + ", target " + Px(target);
			Fire("TOM_Grail" + (isBuy ? "B" : "S") + CurrentBar, Instr(), what, Px(Close[0]), snd);
		}


		// ------------------------------------------------------------------ TO METHOD v4: TraderOracle patterns (Sierra definitions)
		// Simple-average RSI(14) at `ago` bars back (Sierra sc.RSI with MOVAVGTYPE_SIMPLE).
		private double RsiSimpleAgo(int ago)
		{
			const int len = 14;
			if (CurrentBar < ago + len) return double.NaN;
			double g = 0, l = 0;
			for (int j = 0; j < len; j++) { double ch = Close[ago + j] - Close[ago + j + 1]; if (ch > 0) g += ch; else l -= ch; }
			if (l == 0) return g == 0 ? 50 : 100;
			return 100 - 100 / (1 + g / l);
		}

		private bool CloudTouch(int ago, bool isBuy)
		{
			if (CurrentBar < ago) return false;
			return isBuy ? Low[ago] < sLN[ago] : High[ago] > sUN[ago];   // NaN compares false
		}

		private void V4PatternStep(bool brokeUp, bool brokeDown, bool upWick, bool downWick)
		{
			int cb = CurrentBar;
			v4TrBuy = v4TrSell = v4SqBuy = v4SqSell = false;
			const int sqLen4 = 20;

			// ---- squeeze relaxer histogram, same recipe as the Sierra module: EMA of close, overwritten at the end of each bar by a linear-regression average
			double alpha = 2.0 / (sqLen4 + 1.0);
			double ema = cb == 0 ? Close[0] : alpha * Close[0] + (1.0 - alpha) * sqA[1];
			double hlh = Highest(High, sqLen4), lll = Lowest(Low, sqLen4);
			sqD[0] = (double.IsNaN(hlh) || double.IsNaN(lll)) ? double.NaN : Open[0] - ((hlh + lll) / 2.0 + ema) / 2.0;
			double hist = LinReg(sqD, sqLen4);
			sqH[0] = hist;
			double lrClose = LinReg(Close, sqLen4);
			sqA[0] = double.IsNaN(lrClose) ? ema : lrClose;
			if (cb >= 2 && !double.IsNaN(hist) && !double.IsNaN(sqH[1]))
			{
				double prevHist = sqH[1];
				if (hist <= 0 && hist > prevHist) { if (sqState == 0) { sqState = 1; v4SqBuy = true; } }
				else if (hist >= 0 && hist < prevHist) { if (sqState == 1) { sqState = 0; v4SqSell = true; } }
			}

			double upperBand = sUpperBB[0], lowerBand = sLowerBB[0];

			// ---- trampoline: green bar, then two red bars with a lower close, RSI beyond 80 / 20 on one of the three bars (mirror for buys)
			bool trBuy = false, trSell = false;
			if (cb >= 16)
			{
				double r0 = RsiSimpleAgo(0), r1 = RsiSimpleAgo(1), r2 = RsiSimpleAgo(2);
				bool rsiHigh = r0 > V4TrampRsiHigh || r1 > V4TrampRsiHigh || r2 > V4TrampRsiHigh;
				bool rsiLow = r0 < V4TrampRsiLow || r1 < V4TrampRsiLow || r2 < V4TrampRsiLow;
				bool bearPat = Close[0] < Open[0] && Close[1] < Open[1] && Close[2] > Open[2] && Close[0] < Close[1] && rsiHigh;
				bool bullPat = Close[0] > Open[0] && Close[1] > Open[1] && Close[2] < Open[2] && Close[0] > Close[1] && rsiLow;
				if (V4TrampMode == ADITRADYTOMTrampBand.AsTraderOracle)
				{
					// exactly as the TraderOracle module: the tick size is truncated to an int, so the band check almost always passes
					double iTick = (double)(int)TickSize;
					bool withUpper = (bearPat && High[2] >= upperBand - iTick) || (bullPat && Low[2] <= upperBand + iTick);
					bool withLower = (bearPat && High[2] >= lowerBand - iTick) || (bullPat && Low[2] <= lowerBand + iTick);
					if (withUpper || withLower) { trBuy = bullPat; trSell = bearPat; }
				}
				else
				{
					trSell = bearPat && High[2] >= upperBand - TickSize;
					trBuy = bullPat && Low[2] <= lowerBand + TickSize;
				}
			}
			v4TrBuy = trBuy; v4TrSell = trSell;

			// ---- engulfing candle at the band
			bool enBuy = false, enSell = false;
			if (cb >= 2)
			{
				double o = Open[0], c = Close[0], h = High[0], l = Low[0];
				bool green = o < c, red = o > c;
				double body = Math.Abs(o - c), prevBody = Math.Abs(Open[1] - Close[1]);
				double upperWick = green ? Math.Abs(h - c) : Math.Abs(h - o);
				double lowerWick = green ? Math.Abs(o - l) : Math.Abs(c - l);
				bool doji = upperWick > body && lowerWick > body;
				if (!(EngulfSkipDoji && doji))
				{
					bool bandBull = l < lowerBand && Low[1] < lowerBand;
					bool bandBear = h > upperBand && High[1] > upperBand;
					if (EngulfRule == ADITRADYTOMEngulfRule.OlympusEngulfingBB)
					{
						enBuy = bandBull && green && body > prevBody;
						enSell = bandBear && red && body > prevBody;
					}
					else
					{
						bool classicBull = Close[1] < Open[1] && green && h > High[1] && l < Low[1] && c > Open[1] && o < Close[1];
						bool classicBear = Close[1] > Open[1] && red && h > High[1] && l < Low[1] && o > Close[1] && c < Open[1];
						bool anywhere = EngulfRule == ADITRADYTOMEngulfRule.ClassicEngulfingAnywhere;
						enBuy = classicBull && (anywhere || bandBull);
						enSell = classicBear && (anywhere || bandBear);
					}
					if (enBuy) engulfFlags[cb] = 1;
					if (enSell) engulfFlags[cb] = 2;
				}
			}

			if (EnableAlerts && State == State.Realtime)
				V4Alerts(trBuy, trSell, enBuy, enSell, brokeDown && downWick, brokeUp && upWick);
		}

		// Alerts 5-10, combined into one entry per bar; the sound is the most specific alert that matched (10 > 9 > 8 > 5 > 6 > 7).
		private void V4Alerts(bool trB, bool trS, bool enB, bool enS, bool wickB, bool wickS)
		{
			var parts = new List<string>();
			int bestRank = -1; string snd = null;
			Action<int, string, string> hit = (rank, text, sound) => { parts.Add(text); if (rank > bestRank) { bestRank = rank; snd = sound; } };
			for (int side = 0; side < 2; side++)
			{
				bool b = side == 0; string w = b ? "BUY" : "SELL";
				bool tr = b ? trB : trS, en = b ? enB : enS, wk = b ? wickB : wickS, sq = b ? v4SqBuy : v4SqSell;
				bool trCloud = tr && (CloudTouch(0, b) || CloudTouch(1, b) || CloudTouch(2, b));
				bool sqCloud = sq && CloudTouch(0, b);
				if (tr && DirOn(V4AlertTrampDir, b)) hit(2, w + " trampoline", SndV4Tramp);
				if (trCloud && DirOn(V4AlertTrCloudDir, b)) hit(5, w + " trampoline in cloud", SndV4TrCloud);
				if (en && DirOn(V4AlertEngulfDir, b)) hit(1, w + " engulfing candle at band", SndV4Engulf);
				if (sq && DirOn(V4AlertSqueezeDir, b)) hit(0, w + " squeeze dot", SndV4Squeeze);
				if (sqCloud && DirOn(V4AlertSqCloudDir, b)) hit(4, w + " squeeze dot in cloud", SndV4SqCloud);
				if (wk && DirOn(V4AlertWickDir, b)) hit(3, w + " large wick in cloud", SndWickCloud);
			}
			if (parts.Count > 0)
				Fire("TOM_V4_" + CurrentBar, Instr(), string.Join(" || ", parts.ToArray()), Px(Close[0]), snd);
		}

		// One tag per side per bar: signal and / or trampoline (optionally on a pin stem), A+ glow, squeeze dot, open = prior close diamond.
		private void EmitV4Tags()
		{
			int cb = CurrentBar;
			bool hasAtr = !double.IsNaN(gAtrNow) && gAtrNow > 0;
			double atr = hasAtr ? gAtrNow : 0;
			for (int side = 0; side < 2; side++)
			{
				bool isBuy = side == 0;
				GrailPend pend = isBuy ? gPendBuy : gPendSell;
				bool hasTr = ShowSierraTramp && (isBuy ? v4TrBuy : v4TrSell);
				bool hasSq = ShowSierraSqueeze && (isBuy ? v4SqBuy : v4SqSell);
				double extreme = isBuy ? Low[0] : High[0];
				double sgn = isBuy ? -1.0 : 1.0;
				if (pend != null || hasTr)
				{
					double off = GrailPinStem ? Math.Max(GrailPinStemLen * atr, 4 * TickSize) : Math.Max(GrailTagOffsetAtr * atr, 2 * TickSize);
					double gap = Math.Max(0.1 * atr, TickSize);
					string text, tip; Color col; float size = GrailFontSize; bool filled = true;
					if (pend != null)
					{
						bool aPlus = pend.Score >= 4;
						string word = GrailTagText == ADITRADYTOMTagText.LongShort ? (isBuy ? "LONG" : "SHORT") : (isBuy ? "BUY" : "SELL");
						text = word + (aPlus ? "+" : "") + (hasTr ? " \u00B7 TR" : "");
						col = aPlus ? (isBuy ? gBuyPlusCol : gSellPlusCol) : (isBuy ? gBuyCol : gSellCol);
						filled = GrailTagBackground || aPlus;
						tip = GrailTip(isBuy, pend.Score, pend.Flags, pend.Stop, pend.Target, pend.FP, pend.FD, pend.FQ, pend.FT)
							+ (hasTr ? "\n\nA TraderOracle trampoline also completed on this bar" : "");
					}
					else
					{
						text = "TR"; col = trampCol; size = Math.Max(6, GrailFontSize - 2); filled = GrailTagBackground;
						tip = "TRAMPOLINE (" + (isBuy ? "buy" : "sell") + ")\n" + (isBuy ? "Red bar, then two green bars with a higher close, RSI below " + V4TrampRsiLow : "Green bar, then two red bars with a lower close, RSI above " + V4TrampRsiHigh) + " on one of the three bars";
					}
					Marker m = AddMarker(cb, isBuy, text, col, size, MKind.Tag, tip, Contrast(col), false);
					m.Price = extreme + sgn * off; m.Filled = filled;
					if (GrailPinStem && off > gap) m.StemPrice = extreme + sgn * gap;
					if (GrailGlow && pend != null && pend.Score >= 4 && hasAtr) { m.GlowPrice = extreme; m.GlowHalf = 0.4 * atr; m.GlowCol = col; }
				}
				if (pend != null && ShowOpenEqMarks && (pend.Flags & 1) != 0)
				{
					bool band = (pend.Flags & 2) != 0;
					Marker dm = AddMarker(cb, isBuy, "\u25C6", band ? Color.FromRgb(255, 140, 0) : Color.FromRgb(120, 170, 255), band ? 11 : 8, MKind.Glyph,
						"OPEN = PRIOR CLOSE" + (band ? " + band break" : "") + "\nThe signal bar opened at the previous bar's close", Colors.White, false);
					dm.Price = Open[0];
				}
				if (hasSq)
				{
					Marker sm = AddMarker(cb, isBuy, "\u25CF", squeezeCol, Math.Max(6, GrailFontSize - 2), MKind.Glyph,
						"SQUEEZE DOT (" + (isBuy ? "buy" : "sell") + ")\nSqueeze momentum histogram turned " + (isBuy ? "up while at or below zero" : "down while at or above zero"), Colors.White, false);
					sm.Price = extreme + sgn * SqueezeDotTicks * TickSize;
				}
			}
		}

		// ------------------------------------------------------------------ REVERSAL VOLUME PATTERNS
		private void VolStep(double rsiM)
		{
			int cb = CurrentBar;
			sVolUp[0] = false; sVolDn[0] = false;
			if (!ShowVolPatterns || cb < 5) return;

			bool g0 = Close[0] > Open[0], g1 = Close[1] > Open[1], g2 = Close[2] > Open[2], g3 = Close[3] > Open[3], g4 = Close[4] > Open[4];
			bool r0 = !g0, r1 = !g1, r2 = !g2, r3 = !g3, r4 = !g4;     // a doji counts as red (as in the original)
			double v0 = Volume[0], v1 = Volume[1], v2 = Volume[2], v3 = Volume[3], v4 = Volume[4];

			bool up1 = v1 > v2 && v0 < v1 && g0 && r1 && r2;
			bool dn1 = v1 > v2 && v0 < v1 && r0 && g1 && g2;
			bool up2 = v2 > v3 && v3 > v4 && v1 < v2 && v0 < v2 && g0 && r1 && r2 && r3 && r4;
			bool dn2 = v2 > v3 && v3 > v4 && v1 < v2 && v0 < v2 && r0 && g1 && g2 && g3 && g4;
			bool up3 = r1 && r2 && r3 && r4 && g0 && v0 > v1 && v0 > v2 && v0 > v3 && v0 > v4;
			bool dn3 = g1 && g2 && g3 && g4 && r0 && v0 > v1 && v0 > v2 && v0 > v3 && v0 > v4;

			// pattern 4: pivot + long-wick candle
			double O = Open[0], C = Close[0], H = High[0], L = Low[0];
			double hlsma = Sma(sRange, 50); bool hv = !double.IsNaN(hlsma);
			const double wm = 10.0, bp = 1.0;
			bool wLong = (C > O && (O - L) >= (C - O) * wm && (H - C) <= (H - L) * bp)
				|| (C < O && (C - L) >= (O - C) * wm && (H - C) <= (H - L) * bp)
				|| ((C == O && C != H) && (H - L) >= (H - C) * wm && (H - C) <= (H - L) * bp)
				|| ((O == H && C == H) && hv && (H - L) >= hlsma);
			bool wShort = (C < O && (H - O) >= (O - C) * wm && (C - L) <= (H - L) * bp)
				|| (C > O && (H - C) >= (C - O) * wm && (C - L) <= (H - L) * bp)
				|| ((C == O && C != L) && (H - L) >= (C - L) * wm && (C - L) <= (H - L) * bp)
				|| ((O == L && C == L) && hv && (H - L) >= hlsma);
			bool pivH = H > High[1] && H > High[2] && H > High[3] && H > High[4] && H > High[5];
			bool pivL = L < Low[1] && L < Low[2] && L < Low[3] && L < Low[4] && L < Low[5];
			bool up4 = pivL && wLong, dn4 = pivH && wShort;

			if (!VolP1) { up1 = false; dn1 = false; }
			if (!VolP2) { up2 = false; dn2 = false; }
			if (!VolP3) { up3 = false; dn3 = false; }
			if (!VolP4) { up4 = false; dn4 = false; }
			bool up = up1 || up2 || up3 || up4, dn = dn1 || dn2 || dn3 || dn4;

			if (sVolUp[1]) up = false;          // no consecutive duplicates (previous bar's final value)
			if (sVolDn[1]) dn = false;
			if (VolRsiFilter)
			{
				if (double.IsNaN(rsiM) || rsiM < VolRsiOB) dn = false;
				if (double.IsNaN(rsiM) || rsiM > VolRsiOS) up = false;
			}
			sVolUp[0] = up; sVolDn[0] = dn;

			if (up) AddVolMarker(true, up1, up2, up3, up4, rsiM);
			if (dn) AddVolMarker(false, dn1, dn2, dn3, dn4, rsiM);
		}

		private void AddVolMarker(bool isBuy, bool p1, bool p2, bool p3, bool p4, double rsiM)
		{
			Color col = volArrowCol;
			if (VolColorByPattern)
			{
				if (p1) col = Color.FromRgb(255, 0, 255);
				if (p2) col = Color.FromRgb(128, 0, 128);
				if (p3) col = Color.FromRgb(0, 0, 255);
				if (p4) col = Color.FromRgb(255, 255, 0);
			}
			string pats = (p1 ? "#1 " : "") + (p2 ? "#2 " : "") + (p3 ? "#3 " : "") + (p4 ? "#4 " : "");
			string tip = "REVERSAL VOLUME PATTERN (" + (isBuy ? "buy" : "sell") + ")\nPattern " + pats.Trim()
				+ "\n#1 small, larger, small   #2 small, larger, even larger, small\n#3 four same-colour bars then a bigger opposite bar   #4 pivot + long wick"
				+ "\nRSI " + F0(rsiM) + (VolRsiFilter ? "  (RSI filter on)" : "");
			Marker vm = AddMarker(CurrentBar, isBuy, "\u25A0", col, 8, MKind.Glyph, tip, Colors.White, false);
			vm.Price = isBuy ? Low[0] - VolOffsetTicks * TickSize : High[0] + VolOffsetTicks * TickSize;
		}

		// ------------------------------------------------------------------ LITTLE RIZZY
		private int RizTouchSide(int ago, double L)
		{
			if (CurrentBar < ago + 1) return 0;
			double pc = Close[ago + 1];
			if (pc > L && Low[ago] <= L) return 1;       // came down from above
			if (pc < L && High[ago] >= L) return -1;     // came up from below
			return 0;
		}
		private bool RizBarTouches(double L) { return (Low[0] <= L && High[0] >= L) || RizTouchSide(0, L) != 0; }

		// +1 = touched from above and closed back above, -1 = touched from below and closed back below
		private int RizReversalAt(double L)
		{
			double buf = RizBreakTicks * TickSize;
			for (int t = 0; t <= RizReversalWindow && t < CurrentBar; t++)
			{
				int side = RizTouchSide(t, L);
				if (side == 0) continue;
				bool closedBack = false;
				for (int k = t; k > 0; k--)
					if ((side > 0 && Close[k] > L + buf) || (side < 0 && Close[k] < L - buf)) { closedBack = true; break; }
				if (closedBack) continue;
				if (side > 0 && Close[0] > L + buf && (!RizRequireColor || Close[0] > Open[0])) return 1;
				if (side < 0 && Close[0] < L - buf && (!RizRequireColor || Close[0] < Open[0])) return -1;
			}
			return 0;
		}

		private string RizBreakText(double wae)
		{
			DateTime bt = BarOpenTime();
			string w = double.IsNaN(wae) ? "+0" : (Math.Abs(wae) >= 1 ? wae.ToString("+0;-0;+0", CultureInfo.InvariantCulture) : wae.ToString("+0.00;-0.00;+0.00", CultureInfo.InvariantCulture));
			return " Broken " + bt.Hour + ":" + bt.Minute.ToString("00") + " / " + w + " / " + Volume[0].ToString("0", CultureInfo.InvariantCulture) + " ";
		}

		private void RizOnTouch(RizLevel lv, bool live)
		{
			lv.Touched = true;
			int side = RizTouchSide(0, lv.Value);
			if (side == 0) side = (CurrentBar >= 1 && Close[1] < lv.Value) ? -1 : 1;
			lv.TouchSide = side; lv.TouchBar = CurrentBar;
			if (lv.FrozenEnd >= 0 && lv.FrozenEnd < CurrentBar) lv.FrozenEnd = CurrentBar;
			if (live)
			{
				lv.BlinkStart = DateTime.UtcNow;
				if (EnableAlerts && RizTouchAlert)
					Fire("TOM_RizTouch" + lv.SetupId + "_" + CurrentBar, Instr(), "Little Rizzy: price touched " + (lv.Dir < 0 ? "Short" : "Long") + " TGT " + Px(lv.Value), Px(Close[0]), SndRizzyTouch);
			}
		}

		private void RizRetire(RizLevel lv)
		{
			if (lv.FrozenEnd < 0) lv.FrozenEnd = CurrentBar;
			rizRetired.Add(lv);
			if (rizRetired.Count > 300) rizRetired.RemoveAt(0);
		}

		private void RizzyStep(double wae)
		{
			int cb = CurrentBar;
			oRiz[0] = 0;
			if (!ShowRizzy) return;
			int S = RizPivotStrength;
			if (cb < 2 * S) return;
			bool live = State == State.Realtime;
			bool alerts = live && EnableAlerts && RizAlerts;
			double h = High[0], l = Low[0], c = Close[0];
			const double buf = 0.0;     // invalidation buffer (ticks): 0, as in the Sierra settings

			// ---- A. manage the active setup
			if (rizActive)
			{
				double lineHere = rizA1V + rizSlope * (cb - rizA1);
				bool killed = false;
				if (RizInvalidate)
				{
					if (rizDir < 0 && c > lineHere + buf) killed = true;
					else if (rizDir > 0 && c < lineHere - buf) killed = true;
					if (killed)
					{
						rizActive = false;
						Marker im = AddMarker(cb, false, "●", cRizInval, 11, MKind.Glyph, "LITTLE RIZZY — setup invalidated\nA close went beyond the trend line", Colors.White, false);
						im.Price = c;
						if (alerts) Fire("TOM_RizInval" + cb, Instr(), "Little Rizzy: setup invalidated (close beyond trend line)", Px(c), SndRizzy);
					}
				}
				if (rizActive && ((rizDir < 0 && l <= rizTarget) || (rizDir > 0 && h >= rizTarget)))
				{
					rizActive = false;
					if (alerts) Fire("TOM_RizTgt" + cb, Instr(), "Little Rizzy: measured move target reached", Px(c), SndRizzy);
				}
			}

			// ---- A2. watched target levels: touch, break, touch-and-reverse
			bool revUp = false, revDn = false;
			for (int n = 0; n < rizWatched.Count; n++)
			{
				RizLevel lv = rizWatched[n];
				if (!lv.Touched && RizBarTouches(lv.Value)) RizOnTouch(lv, live);
				if (lv.BrokenAt < 0 && lv.Touched)
				{
					double rb = RizBreakTicks * TickSize;
					if ((lv.TouchSide > 0 && c < lv.Value - rb) || (lv.TouchSide < 0 && c > lv.Value + rb))
					{
						lv.BrokenAt = cb;
						if (lv.FrozenEnd >= 0 && lv.FrozenEnd < cb) lv.FrozenEnd = cb;
						lv.BreakTxt = RizBreakText(wae);
					}
				}
				if (RizReversals)
				{
					int rr = RizReversalAt(lv.Value);
					if (rr > 0) revUp = true; else if (rr < 0) revDn = true;
				}
			}
			if (revUp) { Marker rm = AddMarker(cb, true, "▲", cRizRev, 12, MKind.Glyph, "LITTLE RIZZY — target level touched from above, closed back above (reversal up)", Colors.White, false); rm.Price = Low[0] - RizRevOffsetTicks * TickSize; }
			if (revDn) { Marker rm = AddMarker(cb, false, "▼", cRizRev, 12, MKind.Glyph, "LITTLE RIZZY — target level touched from below, closed back below (reversal down)", Colors.White, false); rm.Price = High[0] + RizRevOffsetTicks * TickSize; }
			if ((revUp || revDn) && alerts)
				Fire("TOM_RizRev" + cb, Instr(), revUp ? "Little Rizzy: target level touched, price reversed up" : "Little Rizzy: target level touched, price reversed down", Px(c), SndRizzy);

			// ---- B. confirm the pivot that sits S bars back
			bool newHigh = false, newLow = false;
			if (cb - S - S >= 0)
			{
				double PH = High[S], PL = Low[S];
				bool isHigh = true, isLow = true;
				for (int k = -S; k <= S; k++)
				{
					if (k == 0) continue;
					if (High[S - k] > PH) isHigh = false;
					if (Low[S - k] < PL) isLow = false;
					if (!isHigh && !isLow) break;
				}
				int p = cb - S;
				if (isHigh && p != lastHighIdx) { prevHighIdx = lastHighIdx; prevHighVal = lastHighVal; lastHighIdx = p; lastHighVal = PH; newHigh = true; }
				if (isLow && p != lastLowIdx) { prevLowIdx = lastLowIdx; prevLowVal = lastLowVal; lastLowIdx = p; lastLowVal = PL; newLow = true; }
			}

			// ---- C. build a new setup from the two latest pivots
			for (int pass = 0; pass < 2; pass++)
			{
				int dir = pass == 0 ? -1 : 1;
				if (dir < 0 && (!RizBearish || !newHigh)) continue;
				if (dir > 0 && (!RizBullish || !newLow)) continue;
				if (rizActive && !RizNewReplaces) continue;

				int a1 = dir < 0 ? prevHighIdx : prevLowIdx, a2 = dir < 0 ? lastHighIdx : lastLowIdx;
				double a1v = dir < 0 ? prevHighVal : prevLowVal, a2v = dir < 0 ? lastHighVal : lastLowVal;
				if (a1 < 0 || a2 <= a1) continue;
				if (a2 - a1 < RizMinAnchor) continue;
				if (dir < 0 && a2v >= a1v) continue;      // need a lower high
				if (dir > 0 && a2v <= a1v) continue;      // need a higher low

				double slope = (a2v - a1v) / (a2 - a1);
				int extIdx = a1; double extV = dir < 0 ? Bars.GetLow(a1) : Bars.GetHigh(a1);
				for (int k = a1; k <= a2; k++)
				{
					if (dir < 0 && Bars.GetLow(k) < extV) { extV = Bars.GetLow(k); extIdx = k; }
					else if (dir > 0 && Bars.GetHigh(k) > extV) { extV = Bars.GetHigh(k); extIdx = k; }
				}
				double lineAtExt = a1v + slope * (extIdx - a1);
				double dist = dir < 0 ? lineAtExt - extV : extV - lineAtExt;
				if (dist <= 0) continue;
				double target = dir < 0 ? extV - dist : extV + dist;

				bool resolved = false;      // line already broken, or target already met, since A2 was confirmed
				for (int k = a2 + 1; k <= cb; k++)
				{
					double lineK = a1v + slope * (k - a1), ck = Bars.GetClose(k);
					if (RizInvalidate)
					{
						if (dir < 0 && ck > lineK + buf) { resolved = true; break; }
						if (dir > 0 && ck < lineK - buf) { resolved = true; break; }
					}
					if (dir < 0 && Bars.GetLow(k) <= target) { resolved = true; break; }
					if (dir > 0 && Bars.GetHigh(k) >= target) { resolved = true; break; }
				}
				if (resolved) continue;

				if (rizWatched.Count > 0 && !RizExtendPrev) rizWatched[0].FrozenEnd = cb;   // outgoing line stops here
				RizLevel nl = new RizLevel { SetupId = ++rizSetupId, Dir = dir, ExtIndex = extIdx, Value = target, Distance = dist };
				rizWatched.Insert(0, nl);
				while (rizWatched.Count > 1 + RizNumPrev)
				{
					RizLevel old = rizWatched[rizWatched.Count - 1];
					rizWatched.RemoveAt(rizWatched.Count - 1);
					RizRetire(old);
				}
				rizActive = true; rizDir = dir; rizA1 = a1; rizA1V = a1v; rizA2 = a2; rizA2V = a2v; rizSlope = slope; rizTarget = target;
				if (alerts) Fire("TOM_RizSetup" + cb, Instr(), "Little Rizzy: " + (dir < 0 ? "bearish" : "bullish") + " setup, target " + Px(target), Px(c), SndRizzy);
				break;      // one new setup per bar
			}

			oRiz[0] = rizActive ? rizDir : 0;
		}
		#endregion

		#region Module rendering
		private void RenderGrailLevels(ChartControl cc, ChartScale cs, int from, int to)
		{
			if (!ShowGrail || !GrailShowStopTarget || gTrades.Count == 0) return;
			GrailTrade t = gTrades[gTrades.Count - 1];
			int end = t.Res == 0 ? Math.Min(CurrentBar, t.Bar + GrailMaxTrack) : t.ResBar;
			if (end < from || t.Bar > to) return;
			float x0 = XAt(cc, t.Bar), x1 = XAt(cc, end);
			var st = Style(ADITRADYTOMLineStyle.Dashed);
			float ys = cs.GetYByValue(t.Stop), yt = cs.GetYByValue(t.Target);
			RenderTarget.DrawLine(new DX.Vector2(x0, ys), new DX.Vector2(x1, ys), Dx(Color.FromRgb(200, 80, 80)), 2f, st);
			RenderTarget.DrawLine(new DX.Vector2(x0, yt), new DX.Vector2(x1, yt), Dx(Color.FromRgb(80, 160, 255)), 2f, st);
		}

		private void RenderTpMarks(ChartControl cc, ChartScale cs, int from, int to)
		{
			if (!ShowGrail || !GrailShowTp) return;
			var f = Fmt("Segoe UI", 10f, true);
			foreach (var tp in tpMarks)
			{
				if (tp.Bar < from || tp.Bar > to) continue;
				float x = cc.GetXByBarIndex(ChartBars, tp.Bar), y = cs.GetYByValue(tp.Price);
				var sz = Measure("TP", f);
				float w = sz.X + 8, hh = sz.Y + 2;
				var rect = new DX.RectangleF(x + 2, y - hh / 2, w, hh);
				RenderTarget.FillRectangle(rect, Dx(cTpHit));
				Text("TP", f, x + 6, y - sz.Y / 2, Contrast(cTpHit));
				hoverItems.Add(new HoverItem { Rect = rect, Tip = "TARGET HIT\nGrail " + (tp.IsBuy ? "BUY" : "SELL") + " target " + Px(tp.Price) + " reached before its stop (" + (tp.Bar - tp.SignalBar) + " bars after the signal)" });
			}
		}

		// state: 0 untouched, 1 touched, 2 broken, 3 expired
		private void RizSpan(RizLevel lv, int state, bool blinking, int fullEnd, out int begin, out int end)
		{
			begin = lv.ExtIndex; end = fullEnd;
			if (!blinking && (state == 1 || state == 2) && lv.TouchBar >= 0)
			{
				int len = lv.TouchBar - lv.ExtIndex;
				int pct = state == 2 ? RizBrokenPct : RizCollapsePct;
				int half = (int)(len * pct / 200.0 + 0.5);
				if (half < 1) half = 1;
				begin = lv.TouchBar - half; end = lv.TouchBar + half;
				if (lv.BrokenAt > end) end = lv.BrokenAt;
			}
			else if (state == 3)
			{
				int len = fullEnd - lv.ExtIndex;
				int seg = (int)(len * RizCollapsePct / 100.0 + 0.5);
				if (seg < 2) seg = 2;
				end = lv.ExtIndex + seg;
				if (end > fullEnd) end = fullEnd;
			}
			if (end <= begin) end = begin + 1;
		}

		private void RenderRizzy(ChartControl cc, ChartScale cs, int from, int to)
		{
			if (!ShowRizzy || (rizWatched.Count == 0 && rizRetired.Count == 0)) return;
			int last = CurrentBar;
			double price = ChartBars.Bars.GetClose(Math.Min(last, ChartBars.Bars.Count - 1));
			Color bg = ChartBg(), fg = ChartFg();
			bool anyBlink = false;
			for (int pass = 0; pass < 2; pass++)
			{
				List<RizLevel> list = pass == 0 ? rizRetired : rizWatched;
				for (int n = 0; n < list.Count; n++) DrawRizLevel(list[n], pass == 0, cc, cs, from, to, last, price, bg, fg, ref anyBlink);
			}
			if (anyBlink && ChartControl != null)
			{
				ChartControl chart = ChartControl;
				int delay = Math.Max(50, RizBlinkMs);
				System.Threading.Tasks.Task.Delay(delay).ContinueWith(tk =>
				{
					try { chart.Dispatcher.InvokeAsync(() => chart.InvalidateVisual()); } catch { }
				});
			}
		}

		private void DrawRizLevel(RizLevel lv, bool retired, ChartControl cc, ChartScale cs, int from, int to, int last, double price, Color bg, Color fg, ref bool anyBlink)
		{
			int state = lv.BrokenAt >= 0 ? 2 : lv.Touched ? 1 : retired ? 3 : 0;
			int left = 0;
			if (!retired && lv.BlinkStart != DateTime.MinValue)
			{
				int step = (int)((DateTime.UtcNow - lv.BlinkStart).TotalMilliseconds / Math.Max(50, RizBlinkMs));
				left = rizBlinkSteps - step;
				if (left < 0) left = 0;
			}
			bool blinking = left > 0;
			if (blinking) anyBlink = true;
			int fullEnd = lv.FrozenEnd >= 0 ? lv.FrozenEnd : last;
			int begin, end;
			RizSpan(lv, state, blinking, fullEnd, out begin, out end);
			if (end < from || begin > to) return;
			if (blinking && left % 2 == 1) return;      // hidden step of the blink

			Color col; float w; bool dashed;
			if (blinking) { col = Colors.White; w = RizTouchedWidth; dashed = false; }
			else if (state == 2) { col = Mix(rizBrokenCol, bg, 0.10); w = RizBrokenWidth; dashed = false; }
			else if (state == 3) { col = rizExpiredCol; w = RizBaseWidth; dashed = true; }
			else if (state == 1) { col = rizTargetCol; w = RizTouchedWidth; dashed = false; }
			else
			{
				double zone = lv.Distance * RizZonePct / 100.0;
				double p = zone > 0 ? 1.0 - Math.Abs(price - lv.Value) / zone : 0.0;
				p = Math.Max(0, Math.Min(1, p));
				w = RizBaseWidth + (float)Math.Round(p * (RizApproachWidth - RizBaseWidth));
				col = Mix(rizTargetCol, bg, (RizFarFadePct / 100.0) * (1.0 - p));
				dashed = true;
			}
			if (w < 1) w = 1;

			float x0 = XAt(cc, begin), x1 = XAt(cc, end), y = cs.GetYByValue(lv.Value);
			var st = dashed ? Style(ADITRADYTOMLineStyle.Dashed) : null;
			if (st != null) RenderTarget.DrawLine(new DX.Vector2(x0, y), new DX.Vector2(x1, y), Dx(col), w, st);
			else RenderTarget.DrawLine(new DX.Vector2(x0, y), new DX.Vector2(x1, y), Dx(col), w);

			var f = Fmt("Segoe UI", 11f, true);
			float mid = XAt(cc, (begin + end) / 2);
			string status = state == 2 ? "broken" : state == 1 ? "touched" : state == 3 ? "expired (never touched)" : "untouched";
			if (state == 2)
			{
				float bx = cc.GetXByBarIndex(ChartBars, Math.Min(lv.BrokenAt, ChartBars.Bars.Count - 1));
				var xc = Dx(Mix(rizBrokenCol, fg, 0.15));
				RenderTarget.DrawLine(new DX.Vector2(bx - 5, y - 5), new DX.Vector2(bx + 5, y + 5), xc, 2f);
				RenderTarget.DrawLine(new DX.Vector2(bx - 5, y + 5), new DX.Vector2(bx + 5, y - 5), xc, 2f);
				string tag = lv.BreakTxt ?? " Broken ";
				var sz = Measure(tag, f);
				Text(tag, f, mid - sz.X / 2, y - sz.Y - w / 2 - 1, Mix(rizBrokenCol, fg, 0.55));
			}
			else if (state == 3)
			{
				var sz = Measure("expired", f);
				Text("expired", f, mid - sz.X / 2, y - sz.Y - w / 2 - 1, Mix(rizExpiredCol, fg, 0.20));
			}
			else if (RizShowLabels)
			{
				string lbl = (lv.Dir < 0 ? "Short" : "Long") + " TGT " + Px(lv.Value);
				var sz = Measure(lbl, f);
				Text(lbl, f, x1 + 4, y - sz.Y / 2, rizTargetCol);
			}

			float hh = Math.Max(12f, w);
			hoverItems.Add(new HoverItem
			{
				Rect = new DX.RectangleF(Math.Min(x0, x1), y - hh / 2, Math.Max(4f, Math.Abs(x1 - x0)), hh),
				Tip = "LITTLE RIZZY — " + (lv.Dir < 0 ? "SHORT" : "LONG") + " TARGET " + Px(lv.Value)
					+ "\nMeasured move " + Px(lv.Distance) + "\nStatus: " + status
					+ (state == 2 && lv.BreakTxt != null ? "\n" + lv.BreakTxt.Trim() : "")
			});
		}
		#endregion

		#region Math helpers (NaN if not enough bars or any NaN in the window)
		private double Sma(ISeries<double> s, int len)
		{
			if (len < 1 || CurrentBar < len - 1) return double.NaN;
			double sum = 0;
			for (int i = 0; i < len; i++) { double x = s[i]; if (double.IsNaN(x)) return double.NaN; sum += x; }
			return sum / len;
		}
		private double Stdev(ISeries<double> s, int len)
		{
			double m = Sma(s, len);
			if (double.IsNaN(m)) return double.NaN;
			double ss = 0;
			for (int i = 0; i < len; i++) { double d = s[i] - m; ss += d * d; }
			return Math.Sqrt(ss / len);
		}
		private double Highest(ISeries<double> s, int len)
		{
			if (len < 1 || CurrentBar < len - 1) return double.NaN;
			double m = double.MinValue;
			for (int i = 0; i < len; i++) { double x = s[i]; if (double.IsNaN(x)) return double.NaN; if (x > m) m = x; }
			return m;
		}
		private double Lowest(ISeries<double> s, int len)
		{
			if (len < 1 || CurrentBar < len - 1) return double.NaN;
			double m = double.MaxValue;
			for (int i = 0; i < len; i++) { double x = s[i]; if (double.IsNaN(x)) return double.NaN; if (x < m) m = x; }
			return m;
		}
		private double LinReg(ISeries<double> s, int len)
		{
			if (len < 2 || CurrentBar < len - 1) return double.NaN;
			double sx = 0, sy = 0, sxx = 0, sxy = 0;
			for (int i = 0; i < len; i++)
			{
				double y = s[i]; if (double.IsNaN(y)) return double.NaN;
				double x = len - 1 - i;
				sx += x; sy += y; sxx += x * x; sxy += x * y;
			}
			double slope = (len * sxy - sx * sy) / (len * sxx - sx * sx);
			double intercept = (sy - slope * sx) / len;
			return intercept + slope * (len - 1);
		}
		private static double RsiFrom(double up, double dn)
		{
			if (double.IsNaN(up) || double.IsNaN(dn)) return double.NaN;
			return dn == 0 ? 100 : up == 0 ? 0 : 100 - (100 / (1 + up / dn));
		}
		private static string F0(double x) { return double.IsNaN(x) ? "–" : Math.Round(x).ToString("0", CultureInfo.InvariantCulture); }
		#endregion

		#region Color helpers
		// Brushes made in SetDefaults live on whatever thread NinjaTrader used; freeze them so any thread can read them.
		private static SolidColorBrush TomFrozenBrush(Color c) { var b = new SolidColorBrush(c); b.Freeze(); return b; }
		private static Color TomBrushColor(Brush b, Color fallback)
		{
			SolidColorBrush sb = b as SolidColorBrush;
			if (sb == null) return fallback;
			try { return sb.Color; } catch { }
			try
			{
				Color r = fallback;
				System.Windows.Application.Current.Dispatcher.Invoke(new Action(() => { r = sb.Color; }));
				return r;
			}
			catch { }
			return fallback;
		}
		private static Color T(Color c, double transp)
		{
			transp = Math.Max(0, Math.Min(100, transp));
			return Color.FromArgb((byte)Math.Round(255 * (100 - transp) / 100.0), c.R, c.G, c.B);
		}
		private static uint Argb(Color c) { return ((uint)c.A << 24) | ((uint)c.R << 16) | ((uint)c.G << 8) | c.B; }
		private Color ChartFg()
		{
			var b = ChartControl != null ? ChartControl.Properties.ChartText as SolidColorBrush : null;
			return b != null ? b.Color : Colors.WhiteSmoke;
		}
		private Color ChartBg()
		{
			var b = ChartControl != null ? ChartControl.Properties.ChartBackground as SolidColorBrush : null;
			return b != null ? b.Color : Color.FromRgb(20, 20, 24);
		}
		#endregion

		#region Drawing registries
		private Marker AddMarker(int bar, bool below, string text, Color col, float size, MKind kind, string tip, Color textCol, bool inCloud)
		{
			var m = new Marker { Bar = bar, Below = below, Text = text, Col = col, Size = size, Kind = kind, Tip = tip, TextCol = textCol, InCloud = inCloud };
			List<Marker> list;
			if (!markers.TryGetValue(bar, out list)) { list = new List<Marker>(); markers[bar] = list; }
			list.Add(m);
			return m;
		}

		private string TfLabel()
		{
			int v = BarsPeriod.Value;
			switch (BarsPeriod.BarsPeriodType)
			{
				case BarsPeriodType.Tick: return v + "T";
				case BarsPeriodType.Second: return v + "s";
				case BarsPeriodType.Minute: return v < 60 ? v + "m" : (v % 60 == 0 ? (v / 60) + "h" : v + "m");
				case BarsPeriodType.Range: return v + "R";
				case BarsPeriodType.Volume: return v + "V";
				case BarsPeriodType.Day: return "D";
				case BarsPeriodType.Week: return "W";
				default: return BarsPeriod.ToString();
			}
		}
		#endregion

		#region Rendering
		public override void OnRenderTargetChanged() { DisposeDx(); }

		private void DisposeDx()
		{
			foreach (var b in dxBrushes.Values) if (b != null && !b.IsDisposed) b.Dispose();
			dxBrushes.Clear();
			if (dotStyle != null) { dotStyle.Dispose(); dotStyle = null; }
			if (dashStyle != null) { dashStyle.Dispose(); dashStyle = null; }
		}

		private D2D.SolidColorBrush Dx(Color c)
		{
			uint k = Argb(c);
			D2D.SolidColorBrush b;
			if (!dxBrushes.TryGetValue(k, out b) || b == null || b.IsDisposed)
			{
				b = new D2D.SolidColorBrush(RenderTarget, new DX.Color4(c.R / 255f, c.G / 255f, c.B / 255f, c.A / 255f));
				dxBrushes[k] = b;
			}
			return b;
		}

		private D2D.StrokeStyle Style(ADITRADYTOMLineStyle st)
		{
			if (st == ADITRADYTOMLineStyle.Solid) return null;
			if (st == ADITRADYTOMLineStyle.Dotted)
			{
				if (dotStyle == null)
					dotStyle = new D2D.StrokeStyle(NinjaTrader.Core.Globals.D2DFactory, new D2D.StrokeStyleProperties { DashStyle = D2D.DashStyle.Dot, DashCap = D2D.CapStyle.Round });
				return dotStyle;
			}
			if (dashStyle == null)
				dashStyle = new D2D.StrokeStyle(NinjaTrader.Core.Globals.D2DFactory, new D2D.StrokeStyleProperties { DashStyle = D2D.DashStyle.Dash });
			return dashStyle;
		}

		private DW.TextFormat Fmt(string family, float size, bool bold)
		{
			string key = family + "|" + size.ToString(CultureInfo.InvariantCulture) + "|" + bold;
			DW.TextFormat f;
			if (!fmts.TryGetValue(key, out f))
			{
				f = new DW.TextFormat(NinjaTrader.Core.Globals.DirectWriteFactory, family, bold ? DW.FontWeight.Bold : DW.FontWeight.Normal, DW.FontStyle.Normal, size);
				f.WordWrapping = DW.WordWrapping.NoWrap;
				fmts[key] = f;
			}
			return f;
		}

		private DX.Vector2 Measure(string s, DW.TextFormat f)
		{
			using (var tl = new DW.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, s ?? "", f, 4000, 4000))
				return new DX.Vector2(tl.Metrics.WidthIncludingTrailingWhitespace, tl.Metrics.Height);
		}

		private void Text(string s, DW.TextFormat f, float x, float y, Color c, bool colorFont = false)
		{
			D2D.DrawTextOptions opt = D2D.DrawTextOptions.NoSnap;
			if (colorFont) opt |= (D2D.DrawTextOptions)4;   // EnableColorFont (emoji)
			using (var tl = new DW.TextLayout(NinjaTrader.Core.Globals.DirectWriteFactory, s ?? "", f, 4000, 4000))
				RenderTarget.DrawTextLayout(new DX.Vector2(x, y), tl, Dx(c), opt);
		}

		private float XAt(ChartControl cc, int idx)
		{
			int lastIdx = ChartBars.Bars.Count - 1;
			if (idx < 0) idx = 0;
			if (idx <= lastIdx) return cc.GetXByBarIndex(ChartBars, idx);
			return cc.GetXByBarIndex(ChartBars, lastIdx) + (float)((idx - lastIdx) * cc.Properties.BarDistance);
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (ChartBars == null || RenderTarget == null || IsInHitTest) return;
			base.OnRender(chartControl, chartScale);

			lock (sync)
			{
				if (CurrentBar < 2) return;
				var oldAA = RenderTarget.AntialiasMode;
				RenderTarget.AntialiasMode = D2D.AntialiasMode.PerPrimitive;
				hoverItems.Clear();
				try
				{
					int from = Math.Max(1, ChartBars.FromIndex), to = Math.Min(ChartBars.ToIndex, CurrentBar);
					RenderEngulf(chartControl, from, to);
					if (ShowCloud)
					{
						FillBand(chartControl, chartScale, from, to, sUN, sUA, T(themeCloudUp, CloudTransparency));
						FillBand(chartControl, chartScale, from, to, sLN, sLA, T(themeCloudDn, CloudTransparency));
					}

					RenderAlertBands(chartControl, chartScale, from, to);
					if (ShowCloud) RenderCloudLines(chartControl, chartScale, from, to);
					RenderGrailLevels(chartControl, chartScale, from, to);
					RenderRizzy(chartControl, chartScale, from, to);
					RenderTpMarks(chartControl, chartScale, from, to);
					RenderMarkers(chartControl, chartScale, ChartBars.FromIndex, ChartBars.ToIndex);
					RenderTooltip();
				}
				finally { RenderTarget.AntialiasMode = oldAA; }
			}
		}

		// Engulfing candle at the band: faint background tint over the bar (cloud colours blended toward the chart background).
		private void RenderEngulf(ChartControl cc, int from, int to)
		{
			if (!ShowEngulf || engulfFlags.Count == 0) return;
			Color bg = ChartBg();
			Color bull = Mix(themeCloudDn, bg, 0.72), bear = Mix(themeCloudUp, bg, 0.72);
			float half = Math.Max(1f, (float)cc.Properties.BarDistance / 2f);
			for (int i = from; i <= to; i++)
			{
				int f;
				if (!engulfFlags.TryGetValue(i, out f)) continue;
				float x = cc.GetXByBarIndex(ChartBars, i);
				RenderTarget.FillRectangle(new DX.RectangleF(x - half, ChartPanel.Y, half * 2f, ChartPanel.H), Dx(f == 1 ? bull : bear));
			}
		}

		private void DrawSeriesLine(ChartControl cc, ChartScale cs, int from, int to, Series<double> ser, Color col, float width)
		{
			var br = Dx(col);
			bool have = false; DX.Vector2 prev = new DX.Vector2();
			for (int i = Math.Max(from - 1, 0); i <= to; i++)
			{
				double v = ser.GetValueAt(i);
				if (double.IsNaN(v)) { have = false; continue; }
				DX.Vector2 p = new DX.Vector2(cc.GetXByBarIndex(ChartBars, i), cs.GetYByValue(v));
				if (have) RenderTarget.DrawLine(prev, p, br, width);
				prev = p; have = true;
			}
		}

		// Edge lines of the resistance cloud: inner edges solid 2 px, outer edges 1 px blended toward the chart background.
		private void RenderCloudLines(ChartControl cc, ChartScale cs, int from, int to)
		{
			if (firstCloudBar < 0) return;
			Color bg = ChartBg();
			Color up = themeCloudUp, dn = themeCloudDn;
			DrawSeriesLine(cc, cs, from, to, sUA, Mix(up, bg, 0.35), 1f);
			DrawSeriesLine(cc, cs, from, to, sUN, up, 2f);
			DrawSeriesLine(cc, cs, from, to, sLN, dn, 2f);
			DrawSeriesLine(cc, cs, from, to, sLA, Mix(dn, bg, 0.35), 1f);
		}

		// Outer Bollinger bands (20, 2) used by the open = prior close + band break alert.
		private void RenderAlertBands(ChartControl cc, ChartScale cs, int from, int to)
		{
			if (!ShowAlertBands) return;
			var col = Dx(Color.FromRgb(130, 130, 160));
			for (int k = 0; k < 2; k++)
			{
				Series<double> ser = k == 0 ? sUpperBB : sLowerBB;
				bool have = false; DX.Vector2 prev = new DX.Vector2();
				for (int i = Math.Max(from - 1, 0); i <= to; i++)
				{
					double v = ser.GetValueAt(i);
					if (double.IsNaN(v)) { have = false; continue; }
					DX.Vector2 p = new DX.Vector2(cc.GetXByBarIndex(ChartBars, i), cs.GetYByValue(v));
					if (have) RenderTarget.DrawLine(prev, p, col, 1f);
					prev = p; have = true;
				}
			}
		}

		// Filled ribbon between two series over the visible range (one geometry per band)
		private void FillBand(ChartControl cc, ChartScale cs, int from, int to, Series<double> a, Series<double> b, Color col)
		{
			if (firstCloudBar < 0) return;
			int s = Math.Max(Math.Max(from - 1, 0), firstCloudBar);
			if (s >= to) return;
			var top = new List<DX.Vector2>(); var bot = new List<DX.Vector2>();
			for (int i = s; i <= to; i++)
			{
				double va = a.GetValueAt(i), vb = b.GetValueAt(i);
				if (double.IsNaN(va) || double.IsNaN(vb)) continue;
				float x = cc.GetXByBarIndex(ChartBars, i);
				top.Add(new DX.Vector2(x, cs.GetYByValue(va)));
				bot.Add(new DX.Vector2(x, cs.GetYByValue(vb)));
			}
			if (top.Count < 2) return;
			using (var g = new D2D.PathGeometry(NinjaTrader.Core.Globals.D2DFactory))
			{
				using (var sink = g.Open())
				{
					sink.BeginFigure(top[0], D2D.FigureBegin.Filled);
					for (int i = 1; i < top.Count; i++) sink.AddLine(top[i]);
					for (int i = bot.Count - 1; i >= 0; i--) sink.AddLine(bot[i]);
					sink.EndFigure(D2D.FigureEnd.Closed);
					sink.Close();
				}
				RenderTarget.FillGeometry(g, Dx(col));
			}
		}

		private void RenderMarkers(ChartControl cc, ChartScale cs, int from, int to)
		{
			const float gap = 4f;
			for (int i = from; i <= to; i++)
			{
				List<Marker> list;
				if (!markers.TryGetValue(i, out list)) continue;
				float x = cc.GetXByBarIndex(ChartBars, i);
				float yLow = cs.GetYByValue(ChartBars.Bars.GetLow(i)), yHigh = cs.GetYByValue(ChartBars.Bars.GetHigh(i));
				float stackBelow = 0, stackAbove = 0;
				foreach (var m in list)
				{
					if (!double.IsNaN(m.Price))
					{
						float yP = cs.GetYByValue(m.Price);
						if (m.Kind == MKind.Tag) DrawTagExtras(m, x, yP, cs, cc);
						DrawMarker(m, x, yP); continue;
					}
					float hgt = DrawMarker(m, x, m.Below ? yLow + gap + stackBelow : yHigh - gap - stackAbove);
					if (m.Below) stackBelow += hgt + 2; else stackAbove += hgt + 2;
				}
			}
		}

		// Glow behind an A+ bar and the pin stem of a signal tag.
		private void DrawTagExtras(Marker m, float x, float yTag, ChartScale cs, ChartControl cc)
		{
			if (m.GlowHalf > 0 && !double.IsNaN(m.GlowPrice))
			{
				float yc = cs.GetYByValue(m.GlowPrice);
				float ry = Math.Abs(cs.GetYByValue(m.GlowPrice + m.GlowHalf) - cs.GetYByValue(m.GlowPrice - m.GlowHalf)) / 2f;
				float rx = Math.Max(6f, (float)cc.Properties.BarDistance);
				RenderTarget.FillEllipse(new D2D.Ellipse(new DX.Vector2(x, yc), rx, Math.Max(ry, 4f)), Dx(T(m.GlowCol, 72)));
			}
			if (!double.IsNaN(m.StemPrice))
				RenderTarget.DrawLine(new DX.Vector2(x, cs.GetYByValue(m.StemPrice)), new DX.Vector2(x, yTag), Dx(m.Col), 1f);
		}

		private float DrawMarker(Marker m, float x, float y)
		{
			DX.RectangleF r;
			if (m.Kind == MKind.Tag)
			{
				var ft = Fmt("Segoe UI", m.Size, true);
				var tsz = Measure(m.Text, ft);
				if (m.Filled)
				{
					// Nebula-style callout: filled box, pointer notch aimed at the bar; (x, y) is the pointer tip
					float pad = 5f, pt = 4f, w = tsz.X + pad * 2, hb = tsz.Y + 2f;
					float top = m.Below ? y + pt : y - pt - hb;
					float edgeY = m.Below ? top : top + hb, farY = m.Below ? top + hb : top;
					using (var g = new D2D.PathGeometry(NinjaTrader.Core.Globals.D2DFactory))
					{
						using (var sink = g.Open())
						{
							sink.BeginFigure(new DX.Vector2(x, y), D2D.FigureBegin.Filled);
							sink.AddLine(new DX.Vector2(x + pt, edgeY));
							sink.AddLine(new DX.Vector2(x + w / 2, edgeY));
							sink.AddLine(new DX.Vector2(x + w / 2, farY));
							sink.AddLine(new DX.Vector2(x - w / 2, farY));
							sink.AddLine(new DX.Vector2(x - w / 2, edgeY));
							sink.AddLine(new DX.Vector2(x - pt, edgeY));
							sink.EndFigure(D2D.FigureEnd.Closed);
							sink.Close();
						}
						RenderTarget.FillGeometry(g, Dx(m.Col));
					}
					Text(m.Text, ft, x - tsz.X / 2, top + 1f, m.TextCol);
					r = new DX.RectangleF(x - w / 2, m.Below ? y : top, w, pt + hb);
				}
				else
				{
					float ttop = m.Below ? y : y - tsz.Y;
					r = new DX.RectangleF(x - tsz.X / 2, ttop, tsz.X, tsz.Y);
					Text(m.Text, ft, x - tsz.X / 2, ttop, m.Col);
				}
			}
			else
			{
				var f = Fmt("Segoe UI Symbol", m.Size, true);
				var sz = Measure(m.Text, f);
				float top = !double.IsNaN(m.Price) ? y - sz.Y / 2 : (m.Below ? y : y - sz.Y);
				Text(m.Text, f, x - sz.X / 2, top, m.Col);
				r = new DX.RectangleF(x - sz.X / 2, top, sz.X, sz.Y);
			}
			if (!string.IsNullOrEmpty(m.Tip)) hoverItems.Add(new HoverItem { Rect = r, Tip = m.Tip });
			return r.Height;
		}

		private void RenderTooltip()
		{
			if (string.IsNullOrEmpty(hoverTip)) return;
			var f = Fmt("Segoe UI", 11.5f, false);
			var sz = Measure(hoverTip, f);
			float pad = 7;
			float w = sz.X + pad * 2, h = sz.Y + pad * 2;
			float x = hoverPt.X + 14, y = hoverPt.Y + 14;
			if (x + w > ChartPanel.X + ChartPanel.W) x = hoverPt.X - w - 10;
			if (y + h > ChartPanel.Y + ChartPanel.H) y = hoverPt.Y - h - 10;
			var rect = new DX.RectangleF(x, y, w, h);
			Color bg = ChartBg(), fg = ChartFg();
			RenderTarget.FillRoundedRectangle(new D2D.RoundedRectangle { Rect = rect, RadiusX = 4, RadiusY = 4 }, Dx(T(bg, 4)));
			RenderTarget.DrawRoundedRectangle(new D2D.RoundedRectangle { Rect = rect, RadiusX = 4, RadiusY = 4 }, Dx(T(fg, 60)), 1f);
			Text(hoverTip, f, x + pad, y + pad, fg);
		}

		private void OnPanelMouseMove(object sender, MouseEventArgs e)
		{
			if (ChartControl == null || ChartPanel == null) return;
			Point p = e.GetPosition(ChartPanel);
			float mx = (float)ChartingExtensions.ConvertToHorizontalPixels(p.X, ChartControl.PresentationSource) + ChartPanel.X;
			float my = (float)ChartingExtensions.ConvertToVerticalPixels(p.Y, ChartControl.PresentationSource) + ChartPanel.Y;
			string tip = null;
			lock (sync)
			{
				for (int i = hoverItems.Count - 1; i >= 0; i--)
				{
					var r = hoverItems[i].Rect;
					if (mx >= r.Left - 2 && mx <= r.Right + 2 && my >= r.Top - 2 && my <= r.Bottom + 2) { tip = hoverItems[i].Tip; break; }
				}
			}
			bool changed = tip != hoverTip || (tip != null && (Math.Abs(mx - hoverPt.X) > 3 || Math.Abs(my - hoverPt.Y) > 3));
			hoverPt = new DX.Vector2(mx, my);
			if (changed) { hoverTip = tip; ChartControl.InvalidateVisual(); }
		}

		private void OnPanelMouseLeave(object sender, MouseEventArgs e)
		{
			if (hoverTip != null) { hoverTip = null; if (ChartControl != null) ChartControl.InvalidateVisual(); }
		}
		#endregion

		#region Properties
		// ---- 04. Cloud (Nadaraya-Watson) ----
		[Range(2, 2000)]
		[Display(Name = "Lookback window (h)", Order = 1, GroupName = "06. Resistance Cloud")]
		public int KernelLookback { get; set; }
		[Range(0.25, 100)]
		[Display(Name = "Relative weighting (alpha)", Order = 2, GroupName = "06. Resistance Cloud")]
		public double KernelAlpha { get; set; }
		[Range(1, 200)]
		[Display(Name = "Start regression at bar", Order = 3, GroupName = "06. Resistance Cloud")]
		public int KernelStart { get; set; }
		[Range(1, 500)]
		[Display(Name = "ATR length", Order = 4, GroupName = "06. Resistance Cloud")]
		public int KernelAtrLength { get; set; }
		[Range(0.5, 20)]
		[Display(Name = "Near ATR factor", Order = 5, GroupName = "06. Resistance Cloud")]
		public double NearFactor { get; set; }
		[Range(1, 30)]
		[Display(Name = "Far ATR factor", Order = 6, GroupName = "06. Resistance Cloud")]
		public double FarFactor { get; set; }

		[Display(Name = "Show resistance cloud", Order = 0, GroupName = "06. Resistance Cloud")]
		public bool ShowCloud { get; set; }
		[Range(0, 100)]
		[Display(Name = "Cloud transparency (100 = invisible)", Order = 7, GroupName = "06. Resistance Cloud")]
		public int CloudTransparency { get; set; }
		[Display(Name = "Draw behind bars", Order = 8, GroupName = "06. Resistance Cloud")]
		public bool DrawBehindBars { get; set; }
		[XmlIgnore]
		[Display(Name = "Custom: upper cloud color", Order = 8, GroupName = "01. Color Theme")]
		public Brush CloudUpperBrush { get; set; }
		[Browsable(false)]
		public string CloudUpperBrushSerializable { get { return Serialize.BrushToString(CloudUpperBrush); } set { CloudUpperBrush = Serialize.StringToBrush(value); } }
		[XmlIgnore]
		[Display(Name = "Custom: lower cloud color", Order = 9, GroupName = "01. Color Theme")]
		public Brush CloudLowerBrush { get; set; }
		[Browsable(false)]
		public string CloudLowerBrushSerializable { get { return Serialize.BrushToString(CloudLowerBrush); } set { CloudLowerBrush = Serialize.StringToBrush(value); } }

		// ---- 08. Colors ----

		// ---- 10. Alerts ----
		[Display(Name = "Enable alerts", Order = 1, GroupName = "07. Alerts")]
		public bool EnableAlerts { get; set; }
		[Display(Name = "Default sound (fallback)", Description = "Used for any alert whose sound is left blank.", Order = 2, GroupName = "07. Alerts")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string AlertSound { get; set; }
		[Display(Name = "Sound: alert 8 large wick in cloud", Order = 3, GroupName = "07. Alerts")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndWickCloud { get; set; }

		// ---- 11. Reversal Grail ----
		[Display(Name = "Show Reversal Grail signals", Order = 1, GroupName = "02. Reversal Logic")]
		public bool ShowGrail { get; set; }
		[Display(Name = "Tag text", Order = 2, GroupName = "02. Reversal Logic")]
		public ADITRADYTOMTagText GrailTagText { get; set; }
		[Range(1, 4)]
		[Display(Name = "Minimum score to signal (1-4)", Description = "3 = default, 2 = ~2.5x more signals with a smaller edge, 4 = A+ only.", Order = 3, GroupName = "02. Reversal Logic")]
		public int GrailMinScore { get; set; }
		[Range(3, 500)]
		[Display(Name = "Extreme lookback (bars)", Description = "The signal bar must be the lowest low (buy) / highest high (sell) of this many bars.", Order = 4, GroupName = "02. Reversal Logic")]
		public int GrailLookback { get; set; }
		[Range(1, 50)]
		[Display(Name = "Persistence count (TD-style)", Order = 5, GroupName = "02. Reversal Logic")]
		public int GrailPersistence { get; set; }
		[Range(0, 500)]
		[Display(Name = "Cooldown (bars between same-side signals)", Order = 6, GroupName = "02. Reversal Logic")]
		public int GrailCooldown { get; set; }
		[Display(Name = "Use volume (quiet-volume point, climax veto)", Order = 7, GroupName = "02. Reversal Logic")]
		public bool GrailUseVolume { get; set; }
		[Range(0.1, 10)]
		[Display(Name = "Quiet volume threshold (x average)", Order = 8, GroupName = "02. Reversal Logic")]
		public double GrailQuietVolume { get; set; }
		[Range(0.5, 20)]
		[Display(Name = "Climax volume veto (x average)", Order = 9, GroupName = "02. Reversal Logic")]
		public double GrailClimaxVolume { get; set; }
		[Range(2, 2000)]
		[Display(Name = "Trend EMA length", Order = 10, GroupName = "02. Reversal Logic")]
		public int GrailEmaLength { get; set; }
		[Range(0.5, 10)]
		[Display(Name = "Band blow-through veto (std devs)", Order = 11, GroupName = "02. Reversal Logic")]
		public double GrailBandVeto { get; set; }
		[Range(0.5, 10)]
		[Display(Name = "Wide-range bar veto (x ATR)", Order = 12, GroupName = "02. Reversal Logic")]
		public double GrailWideRangeVeto { get; set; }
		[Range(0, 5)]
		[Display(Name = "Stop buffer (x ATR)", Order = 13, GroupName = "02. Reversal Logic")]
		public double GrailStopBuffer { get; set; }
		[Range(0, 5)]
		[Display(Name = "Minimum risk (x ATR)", Order = 14, GroupName = "02. Reversal Logic")]
		public double GrailMinRisk { get; set; }
		[Range(0.1, 20)]
		[Display(Name = "Target (R multiple)", Order = 15, GroupName = "02. Reversal Logic")]
		public double GrailTargetR { get; set; }
		[Range(1, 2000)]
		[Display(Name = "Max bars to track stop/target", Order = 16, GroupName = "02. Reversal Logic")]
		public int GrailMaxTrack { get; set; }
		[Display(Name = "Show stop / target lines (latest signal)", Order = 17, GroupName = "02. Reversal Logic")]
		public bool GrailShowStopTarget { get; set; }
		[Display(Name = "Show TP tag where a target is hit", Order = 18, GroupName = "02. Reversal Logic")]
		public bool GrailShowTp { get; set; }
		[Range(6, 30)]
		[Display(Name = "Tag font size", Order = 19, GroupName = "02. Reversal Logic")]
		public int GrailFontSize { get; set; }
		[Display(Name = "Tag background (callout box like Nebula)", Description = "Off = plain coloured text for scores below 4.", Order = 30, GroupName = "02. Reversal Logic")]
		public bool GrailTagBackground { get; set; }
		[Display(Name = "Alert band (open = close + band break)", Order = 20, GroupName = "02. Reversal Logic")]
		public ADITRADYTOMAlert4Band GrailAlert4Band { get; set; }
		[Display(Name = "Band break needs a close beyond the band", Description = "Off = a wick beyond the band counts.", Order = 21, GroupName = "02. Reversal Logic")]
		public bool GrailBandOnClose { get; set; }
		[Range(0, 100)]
		[Display(Name = "Open = prior close tolerance (ticks)", Order = 22, GroupName = "02. Reversal Logic")]
		public int GrailOpenEqTicks { get; set; }
		[XmlIgnore]
		[Display(Name = "Buy tag color (Custom theme)", Order = 23, GroupName = "02. Reversal Logic")]
		public Brush GrailBuyBrush { get; set; }
		[Browsable(false)]
		public string GrailBuyBrushSerializable { get { return Serialize.BrushToString(GrailBuyBrush); } set { GrailBuyBrush = Serialize.StringToBrush(value); } }
		[XmlIgnore]
		[Display(Name = "Sell tag color (Custom theme)", Order = 24, GroupName = "02. Reversal Logic")]
		public Brush GrailSellBrush { get; set; }
		[Browsable(false)]
		public string GrailSellBrushSerializable { get { return Serialize.BrushToString(GrailSellBrush); } set { GrailSellBrush = Serialize.StringToBrush(value); } }

		// ---- 12. Little Rizzy ----
		[Display(Name = "Show Little Rizzy", Order = 1, GroupName = "03. Little Rizzy")]
		public bool ShowRizzy { get; set; }
		[Range(1, 20)]
		[Display(Name = "Pivot strength (bars each side)", Order = 2, GroupName = "03. Little Rizzy")]
		public int RizPivotStrength { get; set; }
		[Range(1, 200)]
		[Display(Name = "Min bars between trend line anchors", Order = 3, GroupName = "03. Little Rizzy")]
		public int RizMinAnchor { get; set; }
		[Display(Name = "Detect bearish (lower-high) setups", Order = 4, GroupName = "03. Little Rizzy")]
		public bool RizBearish { get; set; }
		[Display(Name = "Detect bullish (higher-low) setups", Order = 5, GroupName = "03. Little Rizzy")]
		public bool RizBullish { get; set; }
		[Display(Name = "A close beyond the trend line invalidates the setup", Order = 6, GroupName = "03. Little Rizzy")]
		public bool RizInvalidate { get; set; }
		[Display(Name = "A new pattern replaces the active setup", Order = 7, GroupName = "03. Little Rizzy")]
		public bool RizNewReplaces { get; set; }
		[Range(0, 10)]
		[Display(Name = "Previous setups' targets to keep watching", Order = 8, GroupName = "03. Little Rizzy")]
		public int RizNumPrev { get; set; }
		[Display(Name = "Previous target lines keep running right", Order = 9, GroupName = "03. Little Rizzy")]
		public bool RizExtendPrev { get; set; }
		[Range(0, 1000)]
		[Display(Name = "Reversal marker offset (ticks)", Order = 30, GroupName = "03. Little Rizzy")]
		public int RizRevOffsetTicks { get; set; }
		[Display(Name = "Mark touch-and-reverse arrows", Order = 10, GroupName = "03. Little Rizzy")]
		public bool RizReversals { get; set; }
		[Range(0, 20)]
		[Display(Name = "Reversal window (bars after the touch)", Order = 11, GroupName = "03. Little Rizzy")]
		public int RizReversalWindow { get; set; }
		[Display(Name = "Reversal bar must close the opposite color", Order = 12, GroupName = "03. Little Rizzy")]
		public bool RizRequireColor { get; set; }
		[Range(0, 100)]
		[Display(Name = "Close buffer for reversals and breaks (ticks)", Order = 13, GroupName = "03. Little Rizzy")]
		public int RizBreakTicks { get; set; }
		[Display(Name = "Show TGT text labels", Order = 14, GroupName = "03. Little Rizzy")]
		public bool RizShowLabels { get; set; }
		[Display(Name = "Alerts: new setup / invalidated / target / reversal", Order = 15, GroupName = "03. Little Rizzy")]
		public bool RizAlerts { get; set; }
		[Display(Name = "Alert when price touches a target level", Order = 16, GroupName = "03. Little Rizzy")]
		public bool RizTouchAlert { get; set; }
		[Range(50, 5000)]
		[Display(Name = "Touch blink step (ms)", Order = 17, GroupName = "03. Little Rizzy")]
		public int RizBlinkMs { get; set; }
		[Range(5, 100)]
		[Display(Name = "Touched / expired line length (% of original)", Order = 18, GroupName = "03. Little Rizzy")]
		public int RizCollapsePct { get; set; }
		[Range(5, 100)]
		[Display(Name = "Broken line length (% of original)", Order = 19, GroupName = "03. Little Rizzy")]
		public int RizBrokenPct { get; set; }
		[Range(1, 30)]
		[Display(Name = "Touched line thickness", Order = 20, GroupName = "03. Little Rizzy")]
		public int RizTouchedWidth { get; set; }
		[Range(1, 30)]
		[Display(Name = "Approach max thickness", Order = 21, GroupName = "03. Little Rizzy")]
		public int RizApproachWidth { get; set; }
		[Range(1, 30)]
		[Display(Name = "Untouched / expired line thickness", Order = 22, GroupName = "03. Little Rizzy")]
		public int RizBaseWidth { get; set; }
		[Range(1, 30)]
		[Display(Name = "Broken line thickness", Order = 23, GroupName = "03. Little Rizzy")]
		public int RizBrokenWidth { get; set; }
		[Range(1, 300)]
		[Display(Name = "Approach zone (% of the measured move)", Order = 24, GroupName = "03. Little Rizzy")]
		public int RizZonePct { get; set; }
		[Range(0, 90)]
		[Display(Name = "Far-line fade (%)", Order = 25, GroupName = "03. Little Rizzy")]
		public int RizFarFadePct { get; set; }

		// ---- 13. Reversal Volume Patterns ----
		[Display(Name = "Show volume pattern arrows", Order = 1, GroupName = "04. Reversal Volume Patterns")]
		public bool ShowVolPatterns { get; set; }
		[Display(Name = "Pattern 1: small, larger, small", Order = 2, GroupName = "04. Reversal Volume Patterns")]
		public bool VolP1 { get; set; }
		[Display(Name = "Pattern 2: small, larger, even larger, small", Order = 3, GroupName = "04. Reversal Volume Patterns")]
		public bool VolP2 { get; set; }
		[Display(Name = "Pattern 3: 4 same-color bars, bigger opposite bar", Order = 4, GroupName = "04. Reversal Volume Patterns")]
		public bool VolP3 { get; set; }
		[Display(Name = "Pattern 4: pivot + long wick", Order = 5, GroupName = "04. Reversal Volume Patterns")]
		public bool VolP4 { get; set; }
		[Display(Name = "Filter using RSI", Order = 6, GroupName = "04. Reversal Volume Patterns")]
		public bool VolRsiFilter { get; set; }
		[Range(1, 100)]
		[Display(Name = "RSI: sells only at or above", Order = 7, GroupName = "04. Reversal Volume Patterns")]
		public int VolRsiOB { get; set; }
		[Range(1, 100)]
		[Display(Name = "RSI: buys only at or below", Order = 8, GroupName = "04. Reversal Volume Patterns")]
		public int VolRsiOS { get; set; }
		[Range(0, 1000)]
		[Display(Name = "Arrow offset (ticks)", Order = 10, GroupName = "04. Reversal Volume Patterns")]
		public int VolOffsetTicks { get; set; }
		[Display(Name = "Color arrows by pattern", Description = "#1 fuchsia, #2 purple, #3 blue, #4 yellow.", Order = 9, GroupName = "04. Reversal Volume Patterns")]
		public bool VolColorByPattern { get; set; }

		// ---- 08. Alert Settings (Grail / Rizzy)  — all need "Enable alerts" in group 10 ----
		[Display(Name = "Grail: signal arrow appears", Order = 1, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection GrailAlertSignalDir { get; set; }
		[Display(Name = "Grail: target hit before stop", Order = 2, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection GrailAlertTargetDir { get; set; }
		[Display(Name = "Grail: signal bar open = prior close", Order = 3, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection GrailAlertOpenEqDir { get; set; }
		[Display(Name = "Grail: open = prior close + band break", Order = 4, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection GrailAlertOpenEqBandDir { get; set; }
		[Display(Name = "Sound: Grail signal", Order = 5, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndGrailSignal { get; set; }
		[Display(Name = "Sound: Grail target hit", Order = 6, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndGrailTarget { get; set; }
		[Display(Name = "Sound: Grail open = prior close", Order = 7, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndGrailOpenEq { get; set; }
		[Display(Name = "Sound: Grail open = close + band break", Order = 8, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndGrailOpenEqBand { get; set; }
		[Display(Name = "Sound: Little Rizzy setup / invalidated / target / reversal", Order = 9, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndRizzy { get; set; }
		[Display(Name = "Sound: Little Rizzy target touch", Order = 10, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndRizzyTouch { get; set; }

		// ---- TO Method v4 additions ----
		[Display(Name = "Color theme (Grail / Rizzy / volume / cloud)", Description = "The 30 themes of the Sierra study (dark / light chart). Custom uses the colours below and the Grail buy / sell tag colours.", Order = 0, GroupName = "01. Color Theme")]
		public ADITRADYTOMTheme ColorTheme { get; set; }
		[XmlIgnore]
		[Display(Name = "Custom: trampoline TR tag", Order = 3, GroupName = "01. Color Theme")]
		public Brush TrampBrush { get; set; }
		[Browsable(false)]
		public string TrampBrushSerializable { get { return Serialize.BrushToString(TrampBrush); } set { TrampBrush = Serialize.StringToBrush(value); } }
		[XmlIgnore]
		[Display(Name = "Custom: squeeze dots", Order = 4, GroupName = "01. Color Theme")]
		public Brush SqueezeDotBrush { get; set; }
		[Browsable(false)]
		public string SqueezeDotBrushSerializable { get { return Serialize.BrushToString(SqueezeDotBrush); } set { SqueezeDotBrush = Serialize.StringToBrush(value); } }
		[XmlIgnore]
		[Display(Name = "Custom: volume pattern arrows", Order = 5, GroupName = "01. Color Theme")]
		public Brush VolumeBrush { get; set; }
		[Browsable(false)]
		public string VolumeBrushSerializable { get { return Serialize.BrushToString(VolumeBrush); } set { VolumeBrush = Serialize.StringToBrush(value); } }
		[XmlIgnore]
		[Display(Name = "Custom: Little Rizzy target line", Order = 6, GroupName = "01. Color Theme")]
		public Brush RizTargetBrush { get; set; }
		[Browsable(false)]
		public string RizTargetBrushSerializable { get { return Serialize.BrushToString(RizTargetBrush); } set { RizTargetBrush = Serialize.StringToBrush(value); } }
		[XmlIgnore]
		[Display(Name = "Custom: Little Rizzy expired line", Order = 7, GroupName = "01. Color Theme")]
		public Brush RizExpiredBrush { get; set; }
		[Browsable(false)]
		public string RizExpiredBrushSerializable { get { return Serialize.BrushToString(RizExpiredBrush); } set { RizExpiredBrush = Serialize.StringToBrush(value); } }
		[Display(Name = "Tag distance from bar (x ATR)", Order = 25, GroupName = "02. Reversal Logic")]
		public double GrailTagOffsetAtr { get; set; }
		[Display(Name = "Pin stem under signal tags", Description = "Hang each tag on a thin stem, further from the bar.", Order = 26, GroupName = "02. Reversal Logic")]
		public bool GrailPinStem { get; set; }
		[Display(Name = "Pin stem length (x ATR)", Order = 27, GroupName = "02. Reversal Logic")]
		public double GrailPinStemLen { get; set; }
		[Display(Name = "Glow behind A+ (4/4) signals", Order = 28, GroupName = "02. Reversal Logic")]
		public bool GrailGlow { get; set; }
		[Display(Name = "Diamond at the open of open = prior close signals", Order = 29, GroupName = "02. Reversal Logic")]
		public bool ShowOpenEqMarks { get; set; }
		[Display(Name = "Show trampoline TR tags", Description = "Green bar, then two red bars with a lower close, RSI beyond 80 / 20 (mirror for buys).", Order = 1, GroupName = "05. TraderOracle Patterns")]
		public bool ShowSierraTramp { get; set; }
		[Display(Name = "Trampoline band check", Description = "As TraderOracle reproduces the module exactly (its band check almost always passes). Require band touch applies it as intended.", Order = 2, GroupName = "05. TraderOracle Patterns")]
		public ADITRADYTOMTrampBand V4TrampMode { get; set; }
		[Display(Name = "Trampoline RSI overbought", Order = 3, GroupName = "05. TraderOracle Patterns")]
		public int V4TrampRsiHigh { get; set; }
		[Display(Name = "Trampoline RSI oversold", Order = 4, GroupName = "05. TraderOracle Patterns")]
		public int V4TrampRsiLow { get; set; }
		[Display(Name = "Show engulfing-at-band background", Order = 5, GroupName = "05. TraderOracle Patterns")]
		public bool ShowEngulf { get; set; }
		[Display(Name = "Engulfing rule", Order = 6, GroupName = "05. TraderOracle Patterns")]
		public ADITRADYTOMEngulfRule EngulfRule { get; set; }
		[Display(Name = "Skip doji bars", Order = 7, GroupName = "05. TraderOracle Patterns")]
		public bool EngulfSkipDoji { get; set; }
		[Display(Name = "Show squeeze dots", Description = "Squeeze momentum turns up at or below zero (buy) / down at or above zero (sell).", Order = 8, GroupName = "05. TraderOracle Patterns")]
		public bool ShowSierraSqueeze { get; set; }
		[Display(Name = "Squeeze dot offset (ticks)", Order = 9, GroupName = "05. TraderOracle Patterns")]
		public int SqueezeDotTicks { get; set; }
		[Display(Name = "Show outer Bollinger alert bands (20, 2)", Order = 10, GroupName = "05. TraderOracle Patterns")]
		public bool ShowAlertBands { get; set; }
		[Display(Name = "Alert 5: trampoline", Order = 11, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection V4AlertTrampDir { get; set; }
		[Display(Name = "Alert 6: engulfing candle at band", Order = 12, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection V4AlertEngulfDir { get; set; }
		[Display(Name = "Alert 7: squeeze dot", Order = 13, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection V4AlertSqueezeDir { get; set; }
		[Display(Name = "Alert 8: large wick in cloud", Description = "Uses the Large wick in cloud sound of group 10.", Order = 14, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection V4AlertWickDir { get; set; }
		[Display(Name = "Alert 9: squeeze dot in cloud", Order = 15, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection V4AlertSqCloudDir { get; set; }
		[Display(Name = "Alert 10: trampoline in cloud (buys use the lower cloud)", Order = 16, GroupName = "08. Alert Settings")]
		public ADITRADYTOMDirection V4AlertTrCloudDir { get; set; }
		[Display(Name = "Sound: alert 5 trampoline", Order = 17, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndV4Tramp { get; set; }
		[Display(Name = "Sound: alert 6 engulfing", Order = 18, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndV4Engulf { get; set; }
		[Display(Name = "Sound: alert 7 squeeze dot", Order = 19, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndV4Squeeze { get; set; }
		[Display(Name = "Sound: alert 9 squeeze dot in cloud", Order = 20, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndV4SqCloud { get; set; }
		[Display(Name = "Sound: alert 10 trampoline in cloud", Order = 21, GroupName = "08. Alert Settings")]
		[TypeConverter(typeof(ADITRADYTOMSoundConverter))]
		public string SndV4TrCloud { get; set; }

		// ---- outputs for strategies / Market Analyzer ----
		/// <summary>Reversal signal: +score for a buy (3-4 by default), -score for a sell, 0 none</summary>
		[Browsable(false), XmlIgnore] public Series<double> GrailSignal { get { Update(); return oGrail; } }
		/// <summary>Bull score 0-4 on every qualifying lowest-low bar (the Sierra "Bull Score" subgraph)</summary>
		[Browsable(false), XmlIgnore] public Series<double> BullScore { get { Update(); return oBull; } }
		/// <summary>Bear score 0-4 on every qualifying highest-high bar (the Sierra "Bear Score" subgraph)</summary>
		[Browsable(false), XmlIgnore] public Series<double> BearScore { get { Update(); return oBear; } }
		/// <summary>Little Rizzy: +1 active bullish setup, -1 active bearish setup, 0 none</summary>
		[Browsable(false), XmlIgnore] public Series<double> RizzyState { get { Update(); return oRiz; } }
		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ADITRADYTOMETHOD[] cacheADITRADYTOMETHOD;
		public ADITRADYTOMETHOD ADITRADYTOMETHOD()
		{
			return ADITRADYTOMETHOD(Input);
		}

		public ADITRADYTOMETHOD ADITRADYTOMETHOD(ISeries<double> input)
		{
			if (cacheADITRADYTOMETHOD != null)
				for (int idx = 0; idx < cacheADITRADYTOMETHOD.Length; idx++)
					if (cacheADITRADYTOMETHOD[idx] != null &&  cacheADITRADYTOMETHOD[idx].EqualsInput(input))
						return cacheADITRADYTOMETHOD[idx];
			return CacheIndicator<ADITRADYTOMETHOD>(new ADITRADYTOMETHOD(), input, ref cacheADITRADYTOMETHOD);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ADITRADYTOMETHOD ADITRADYTOMETHOD()
		{
			return indicator.ADITRADYTOMETHOD(Input);
		}

		public Indicators.ADITRADYTOMETHOD ADITRADYTOMETHOD(ISeries<double> input )
		{
			return indicator.ADITRADYTOMETHOD(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ADITRADYTOMETHOD ADITRADYTOMETHOD()
		{
			return indicator.ADITRADYTOMETHOD(Input);
		}

		public Indicators.ADITRADYTOMETHOD ADITRADYTOMETHOD(ISeries<double> input )
		{
			return indicator.ADITRADYTOMETHOD(input);
		}
	}
}

#endregion
