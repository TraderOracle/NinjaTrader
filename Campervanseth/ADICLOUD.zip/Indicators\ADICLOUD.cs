//+----------------------------------------------------------------------------------------------+
//| ADICLOUD - Triple EMA Wave with Dual Crossover Clouds
//|
//| Features:
//|   - Fast / Mid / Slow EMA lines (configurable period, color, width, dash)
//|   - Cloud 1 (Fast-Mid) and Cloud 2 (Fast-Slow) filled bands, colored per-bar by trend
//|   - Bullish = Fast above the reference line, Bearish = Fast below the reference line
//+----------------------------------------------------------------------------------------------+

#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.DrawingTools;
using SharpDX;
using SharpDX.Direct2D1;
#endregion

namespace NinjaTrader.NinjaScript.Indicators
{
	[Gui.CategoryOrder("Periods", 10)]
	[Gui.CategoryOrder("Lines", 20)]
	[Gui.CategoryOrder("Cloud 1 (Fast-Mid)", 30)]
	[Gui.CategoryOrder("Cloud 2 (Fast-Slow)", 40)]
	public class ADICLOUD : Indicator
	{
		#region Variables

		// EMA sources (built-in NinjaScript EMA)
		private ISeries<double> fastEMAObj;
		private ISeries<double> midEMAObj;
		private ISeries<double> slowEMAObj;

		// Cached values for rendering (own series so we can GetValueAt in OnRender)
		private Series<double> fastSeries;
		private Series<double> midSeries;
		private Series<double> slowSeries;

		// SharpDX brushes for cloud fills
		private SharpDX.Direct2D1.Brush cloud1BullDX;
		private SharpDX.Direct2D1.Brush cloud1BearDX;
		private SharpDX.Direct2D1.Brush cloud2BullDX;
		private SharpDX.Direct2D1.Brush cloud2BearDX;

		private int barsRequired = 0;

		#endregion

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= "Triple EMA wave (Fast/Mid/Slow) with two colored crossover clouds: Cloud 1 (Fast-Mid) and Cloud 2 (Fast-Slow).";
				Name						= "ADICLOUD";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				IsSuspendedWhileInactive	= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				ArePlotsConfigurable		= false;
				IsAutoScale					= true;
				Displacement				= 0;
				MaximumBarsLookBack			= MaximumBarsLookBack.TwoHundredFiftySix;

				// Periods
				FastPeriod					= 16;
				MidPeriod					= 28;
				SlowPeriod					= 50;

				// Lines
				ShowEMALines				= true;
				FastLineColor				= new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(0xFF, 0xAA, 0xAA, 0xAA));
				FastLineWidth				= 1;
				FastLineDashStyle			= DashStyleHelper.Dot;
				MidLineColor				= new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(0xFF, 0xAA, 0xAA, 0xAA));
				MidLineWidth				= 1;
				MidLineDashStyle			= DashStyleHelper.Dot;
				SlowLineColor				= new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(0xFF, 0xAA, 0xAA, 0xAA));
				SlowLineWidth				= 1;
				SlowLineDashStyle			= DashStyleHelper.Dot;

				// Cloud 1 (Fast-Mid)
				ShowCloud1					= true;
				Cloud1BullColor				= new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(0xFF, 0x32, 0xE2, 0xE4));
				Cloud1BearColor				= new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(0xFF, 0xFF, 0x94, 0x73));
				Cloud1Opacity				= 30;

				// Cloud 2 (Fast-Slow)
				ShowCloud2					= true;
				Cloud2BullColor				= new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(0xFF, 0x00, 0xB3, 0xB3));
				Cloud2BearColor				= new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(0xFF, 0xB3, 0x59, 0x00));
				Cloud2Opacity				= 15;

				AddPlot(new Stroke(Brushes.Gray, 1), PlotStyle.Line, "Fast");
				AddPlot(new Stroke(Brushes.Gray, 1), PlotStyle.Line, "Mid");
				AddPlot(new Stroke(Brushes.Gray, 1), PlotStyle.Line, "Slow");
				SetZOrder(-1);
			}
			else if (State == State.Configure)
			{
				barsRequired = Math.Max(FastPeriod, Math.Max(MidPeriod, SlowPeriod));
				BarsRequiredToPlot = barsRequired;

				Plots[0].Brush			= ShowEMALines ? FastLineColor : Brushes.Transparent;
				Plots[0].Width			= FastLineWidth;
				Plots[0].DashStyleHelper	= FastLineDashStyle;

				Plots[1].Brush			= ShowEMALines ? MidLineColor : Brushes.Transparent;
				Plots[1].Width			= MidLineWidth;
				Plots[1].DashStyleHelper	= MidLineDashStyle;

				Plots[2].Brush			= ShowEMALines ? SlowLineColor : Brushes.Transparent;
				Plots[2].Width			= SlowLineWidth;
				Plots[2].DashStyleHelper	= SlowLineDashStyle;
			}
			else if (State == State.DataLoaded)
			{
				fastEMAObj	= EMA(FastPeriod);
				midEMAObj	= EMA(MidPeriod);
				slowEMAObj	= EMA(SlowPeriod);

				fastSeries	= new Series<double>(this, MaximumBarsLookBack.Infinite);
				midSeries	= new Series<double>(this, MaximumBarsLookBack.Infinite);
				slowSeries	= new Series<double>(this, MaximumBarsLookBack.Infinite);
			}
		}

		protected override void OnBarUpdate()
		{
			fastSeries[0]	= fastEMAObj[0];
			midSeries[0]	= midEMAObj[0];
			slowSeries[0]	= slowEMAObj[0];

			Values[0][0]	= fastSeries[0];
			Values[1][0]	= midSeries[0];
			Values[2][0]	= slowSeries[0];
		}

		#region Rendering

		public override void OnRenderTargetChanged()
		{
			if (cloud1BullDX != null) cloud1BullDX.Dispose();
			if (cloud1BearDX != null) cloud1BearDX.Dispose();
			if (cloud2BullDX != null) cloud2BullDX.Dispose();
			if (cloud2BearDX != null) cloud2BearDX.Dispose();

			if (RenderTarget != null)
			{
				try
				{
					cloud1BullDX = MakeOpacityBrush(Cloud1BullColor, Cloud1Opacity).ToDxBrush(RenderTarget);
					cloud1BearDX = MakeOpacityBrush(Cloud1BearColor, Cloud1Opacity).ToDxBrush(RenderTarget);
					cloud2BullDX = MakeOpacityBrush(Cloud2BullColor, Cloud2Opacity).ToDxBrush(RenderTarget);
					cloud2BearDX = MakeOpacityBrush(Cloud2BearColor, Cloud2Opacity).ToDxBrush(RenderTarget);
				}
				catch { }
			}
		}

		private System.Windows.Media.Brush MakeOpacityBrush(System.Windows.Media.Brush source, int opacityPct)
		{
			System.Windows.Media.Brush clone = source.Clone();
			clone.Opacity = Math.Max(0.0, Math.Min(1.0, opacityPct / 100.0));
			clone.Freeze();
			return clone;
		}

		protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
		{
			if (ChartBars == null || !IsVisible || (!ShowCloud1 && !ShowCloud2))
			{
				base.OnRender(chartControl, chartScale);
				return;
			}

			int lastBarPainted		= ChartBars.ToIndex;
			if (lastBarPainted < 0 || BarsArray[0].Count < lastBarPainted)
			{
				base.OnRender(chartControl, chartScale);
				return;
			}

			int lastBarCounted		= Inputs[0].Count - 1;
			int lastBarOnUpdate	= lastBarCounted - (Calculate == Calculate.OnBarClose ? 1 : 0);
			int lastBarIndex		= Math.Min(lastBarPainted, lastBarOnUpdate);
			int firstBarPainted	= ChartBars.FromIndex;
			int firstBarIndex		= Math.Max(barsRequired, firstBarPainted);

			if (lastBarIndex <= firstBarIndex)
			{
				base.OnRender(chartControl, chartScale);
				return;
			}

			SharpDX.Direct2D1.AntialiasMode oldAntialiasMode = RenderTarget.AntialiasMode;
			RenderTarget.AntialiasMode = SharpDX.Direct2D1.AntialiasMode.PerPrimitive;

			// Cloud 2 (Fast-Slow) drawn first, underneath Cloud 1
			if (ShowCloud2)
				DrawCloud(chartControl, chartScale, firstBarIndex, lastBarIndex, fastSeries, slowSeries, cloud2BullDX, cloud2BearDX);

			if (ShowCloud1)
				DrawCloud(chartControl, chartScale, firstBarIndex, lastBarIndex, fastSeries, midSeries, cloud1BullDX, cloud1BearDX);

			RenderTarget.AntialiasMode = oldAntialiasMode;

			base.OnRender(chartControl, chartScale);
		}

		private void DrawCloud(ChartControl chartControl, ChartScale chartScale, int firstBarIndex, int lastBarIndex,
			Series<double> upperSeries, Series<double> lowerSeries, SharpDX.Direct2D1.Brush bullBrush, SharpDX.Direct2D1.Brush bearBrush)
		{
			for (int idx = firstBarIndex; idx < lastBarIndex; idx++)
			{
				if (!upperSeries.IsValidDataPointAt(idx) || !upperSeries.IsValidDataPointAt(idx + 1))
					continue;
				if (!lowerSeries.IsValidDataPointAt(idx) || !lowerSeries.IsValidDataPointAt(idx + 1))
					continue;

				double aVal0 = upperSeries.GetValueAt(idx);
				double aVal1 = upperSeries.GetValueAt(idx + 1);
				double bVal0 = lowerSeries.GetValueAt(idx);
				double bVal1 = lowerSeries.GetValueAt(idx + 1);

				float x0 = chartControl.GetXByBarIndex(ChartBars, idx);
				float x1 = chartControl.GetXByBarIndex(ChartBars, idx + 1);
				float yA0 = chartScale.GetYByValue(aVal0);
				float yA1 = chartScale.GetYByValue(aVal1);
				float yB0 = chartScale.GetYByValue(bVal0);
				float yB1 = chartScale.GetYByValue(bVal1);

				bool isBull = aVal0 >= bVal0;
				SharpDX.Direct2D1.Brush brush = isBull ? bullBrush : bearBrush;
				if (brush == null) continue;

				SharpDX.Direct2D1.PathGeometry path = new SharpDX.Direct2D1.PathGeometry(Core.Globals.D2DFactory);
				using (path)
				{
					SharpDX.Direct2D1.GeometrySink sink = path.Open();
					sink.BeginFigure(new Vector2(x0, yA0), FigureBegin.Filled);
					sink.AddLine(new Vector2(x1, yA1));
					sink.AddLine(new Vector2(x1, yB1));
					sink.AddLine(new Vector2(x0, yB0));
					sink.EndFigure(FigureEnd.Closed);
					sink.Close();

					RenderTarget.FillGeometry(path, brush);
					sink.Dispose();
				}
			}
		}

		#endregion

		#region Properties

		// === Periods ===
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Fast period", GroupName = "Periods", Order = 0)]
		public int FastPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Mid period", GroupName = "Periods", Order = 1)]
		public int MidPeriod { get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Slow period", GroupName = "Periods", Order = 2)]
		public int SlowPeriod { get; set; }

		// === Lines ===
		[Display(Name = "Show EMA lines", GroupName = "Lines", Order = 0)]
		public bool ShowEMALines { get; set; }

		[XmlIgnore]
		[Display(Name = "Fast line color", GroupName = "Lines", Order = 1)]
		public System.Windows.Media.Brush FastLineColor { get; set; }
		[Browsable(false)]
		public string FastLineColorSerialize
		{ get { return Serialize.BrushToString(FastLineColor); } set { FastLineColor = Serialize.StringToBrush(value); } }

		[Range(1, 10)]
		[Display(Name = "Fast line width", GroupName = "Lines", Order = 2)]
		public int FastLineWidth { get; set; }

		[Display(Name = "Fast line dash", GroupName = "Lines", Order = 3)]
		public DashStyleHelper FastLineDashStyle { get; set; }

		[XmlIgnore]
		[Display(Name = "Mid line color", GroupName = "Lines", Order = 4)]
		public System.Windows.Media.Brush MidLineColor { get; set; }
		[Browsable(false)]
		public string MidLineColorSerialize
		{ get { return Serialize.BrushToString(MidLineColor); } set { MidLineColor = Serialize.StringToBrush(value); } }

		[Range(1, 10)]
		[Display(Name = "Mid line width", GroupName = "Lines", Order = 5)]
		public int MidLineWidth { get; set; }

		[Display(Name = "Mid line dash", GroupName = "Lines", Order = 6)]
		public DashStyleHelper MidLineDashStyle { get; set; }

		[XmlIgnore]
		[Display(Name = "Slow line color", GroupName = "Lines", Order = 7)]
		public System.Windows.Media.Brush SlowLineColor { get; set; }
		[Browsable(false)]
		public string SlowLineColorSerialize
		{ get { return Serialize.BrushToString(SlowLineColor); } set { SlowLineColor = Serialize.StringToBrush(value); } }

		[Range(1, 10)]
		[Display(Name = "Slow line width", GroupName = "Lines", Order = 8)]
		public int SlowLineWidth { get; set; }

		[Display(Name = "Slow line dash", GroupName = "Lines", Order = 9)]
		public DashStyleHelper SlowLineDashStyle { get; set; }

		// === Cloud 1 (Fast-Mid) ===
		[Display(Name = "Show cloud 1 (Fast-Mid)", GroupName = "Cloud 1 (Fast-Mid)", Order = 0)]
		public bool ShowCloud1 { get; set; }

		[XmlIgnore]
		[Display(Name = "Bullish color", GroupName = "Cloud 1 (Fast-Mid)", Order = 1)]
		public System.Windows.Media.Brush Cloud1BullColor { get; set; }
		[Browsable(false)]
		public string Cloud1BullColorSerialize
		{ get { return Serialize.BrushToString(Cloud1BullColor); } set { Cloud1BullColor = Serialize.StringToBrush(value); } }

		[XmlIgnore]
		[Display(Name = "Bearish color", GroupName = "Cloud 1 (Fast-Mid)", Order = 2)]
		public System.Windows.Media.Brush Cloud1BearColor { get; set; }
		[Browsable(false)]
		public string Cloud1BearColorSerialize
		{ get { return Serialize.BrushToString(Cloud1BearColor); } set { Cloud1BearColor = Serialize.StringToBrush(value); } }

		[Range(0, 100)]
		[Display(Name = "Opacity", GroupName = "Cloud 1 (Fast-Mid)", Order = 3)]
		public int Cloud1Opacity { get; set; }

		// === Cloud 2 (Fast-Slow) ===
		[Display(Name = "Show cloud 2 (Fast-Slow)", GroupName = "Cloud 2 (Fast-Slow)", Order = 0)]
		public bool ShowCloud2 { get; set; }

		[XmlIgnore]
		[Display(Name = "Bullish color", GroupName = "Cloud 2 (Fast-Slow)", Order = 1)]
		public System.Windows.Media.Brush Cloud2BullColor { get; set; }
		[Browsable(false)]
		public string Cloud2BullColorSerialize
		{ get { return Serialize.BrushToString(Cloud2BullColor); } set { Cloud2BullColor = Serialize.StringToBrush(value); } }

		[XmlIgnore]
		[Display(Name = "Bearish color", GroupName = "Cloud 2 (Fast-Slow)", Order = 2)]
		public System.Windows.Media.Brush Cloud2BearColor { get; set; }
		[Browsable(false)]
		public string Cloud2BearColorSerialize
		{ get { return Serialize.BrushToString(Cloud2BearColor); } set { Cloud2BearColor = Serialize.StringToBrush(value); } }

		[Range(0, 100)]
		[Display(Name = "Opacity", GroupName = "Cloud 2 (Fast-Slow)", Order = 3)]
		public int Cloud2Opacity { get; set; }

		// === Output series (for strategies / other indicators) ===
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> FastEMA { get { return fastSeries; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MidEMA { get { return midSeries; } }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> SlowEMA { get { return slowSeries; } }

		#endregion
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ADICLOUD[] cacheADICLOUD;
		public ADICLOUD ADICLOUD(int fastPeriod, int midPeriod, int slowPeriod)
		{
			return ADICLOUD(Input, fastPeriod, midPeriod, slowPeriod);
		}

		public ADICLOUD ADICLOUD(ISeries<double> input, int fastPeriod, int midPeriod, int slowPeriod)
		{
			if (cacheADICLOUD != null)
				for (int idx = 0; idx < cacheADICLOUD.Length; idx++)
					if (cacheADICLOUD[idx] != null && cacheADICLOUD[idx].FastPeriod == fastPeriod && cacheADICLOUD[idx].MidPeriod == midPeriod && cacheADICLOUD[idx].SlowPeriod == slowPeriod && cacheADICLOUD[idx].EqualsInput(input))
						return cacheADICLOUD[idx];
			return CacheIndicator<ADICLOUD>(new ADICLOUD(){ FastPeriod = fastPeriod, MidPeriod = midPeriod, SlowPeriod = slowPeriod }, input, ref cacheADICLOUD);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ADICLOUD ADICLOUD(int fastPeriod, int midPeriod, int slowPeriod)
		{
			return indicator.ADICLOUD(Input, fastPeriod, midPeriod, slowPeriod);
		}

		public Indicators.ADICLOUD ADICLOUD(ISeries<double> input , int fastPeriod, int midPeriod, int slowPeriod)
		{
			return indicator.ADICLOUD(input, fastPeriod, midPeriod, slowPeriod);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ADICLOUD ADICLOUD(int fastPeriod, int midPeriod, int slowPeriod)
		{
			return indicator.ADICLOUD(Input, fastPeriod, midPeriod, slowPeriod);
		}

		public Indicators.ADICLOUD ADICLOUD(ISeries<double> input , int fastPeriod, int midPeriod, int slowPeriod)
		{
			return indicator.ADICLOUD(input, fastPeriod, midPeriod, slowPeriod);
		}
	}
}

#endregion
