#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion

// =============================================================================
//  ADITRADYBANDEXPAND  (NinjaTrader 8 port of the TradingView "Band Expand" indicator)
//
//  - 20-period, 2-SD Bollinger Bands, NO middle line.
//  - Each band is colored independently by its own slope (rising / falling).
//  - Wait for the bands to contract into a squeeze (bandwidth rank below a
//    threshold), then fire when they start expanding again
//    (upper rising AND lower falling).
//  - On the trigger, draw a rectangle over the squeeze "small space" and
//    extend it N bars to the right, plus a triangle marker under the bar.
//
//  Runs on bar close (state machine is bar-by-bar, so don't switch to OnEachTick).
// =============================================================================

namespace NinjaTrader.NinjaScript.Indicators
{
	public class ADITRADYBANDEXPAND : Indicator
	{
		private SMA				sma;
		private StdDev			stdDev;
		private MIN				minBw;
		private MAX				maxBw;
		private Series<double>	bandwidth;

		// Squeeze state machine (mirrors the Pine `var` variables)
		private bool	sawSqueeze;
		private double	sqzTop;
		private double	sqzBot;
		private double	minW;
		private int		lastBoxBar;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= @"Bollinger Bands squeeze -> expansion trigger with boxes over the squeeze range.";
				Name						= "ADITRADYBANDEXPAND";
				Calculate					= Calculate.OnBarClose;
				IsOverlay					= true;
				DisplayInDataBox			= true;
				DrawOnPricePanel			= true;
				PaintPriceMarkers			= false;
				IsAutoScale					= false;
				IsSuspendedWhileInactive	= true;

				// Bollinger
				Period						= 20;
				NumStdDev					= 2.0;

				// Squeeze detection
				SqueezeLookback				= 120;
				SqueezeThreshold			= 0.25;

				// Box
				BoxExtend					= 7;
				BoxFromBandsAtTrigger		= false;	// false = squeeze band range, true = bands at trigger
				MinGap						= 7;
				DrawBehindBars				= true;
				BoxOpacity					= 38;		// % (Pine used 62 transparency)

				// Marker / alert
				MarkerOffset				= 3;
				AlertOnSignal				= false;
				SoundFiles					= "Alert2.wav";

				// Colors
				RisingColor					= MakeBrush(0x26, 0xA6, 0x9A);
				FallingColor				= MakeBrush(0xEF, 0x53, 0x50);
				BoxFill						= Brushes.Purple;
				BoxBorder					= Brushes.MediumPurple;
				MarkerColor					= Brushes.MediumOrchid;

				AddPlot(Brushes.Teal, "BB Upper");
				AddPlot(Brushes.Teal, "BB Lower");
				AddPlot(Brushes.Transparent, "ExpansionSignal");	// 1 on trigger bar (handy for strategies / Data Box)
			}
			else if (State == State.Configure)
			{
				Plots[0].Width = 2;
				Plots[1].Width = 2;
			}
			else if (State == State.DataLoaded)
			{
				sma			= SMA(Input, Period);
				stdDev		= StdDev(Input, Period);
				bandwidth	= new Series<double>(this);
				minBw		= MIN(bandwidth, SqueezeLookback);
				maxBw		= MAX(bandwidth, SqueezeLookback);

				sawSqueeze	= false;
				sqzTop		= double.NaN;
				sqzBot		= double.NaN;
				minW		= double.NaN;
				lastBoxBar	= -1;
			}
		}

		private static Brush MakeBrush(byte r, byte g, byte b)
		{
			SolidColorBrush br = new SolidColorBrush(Color.FromRgb(r, g, b));
			br.Freeze();
			return br;
		}

		protected override void OnBarUpdate()
		{
			// Not enough bars for the Bollinger Bands yet
			if (CurrentBar < Period - 1)
			{
				bandwidth[0]			= 0;
				ExpansionSignal[0]		= 0;
				return;
			}

			double basis	= sma[0];
			double dev		= NumStdDev * stdDev[0];
			double upper	= basis + dev;
			double lower	= basis - dev;

			Upper[0]		= upper;
			Lower[0]		= lower;
			bandwidth[0]	= upper - lower;
			ExpansionSignal[0] = 0;

			if (CurrentBar < Period)
				return;

			// Each band colored by its own slope
			PlotBrushes[0][0] = upper >= Upper[1] ? RisingColor : FallingColor;
			PlotBrushes[1][0] = lower >= Lower[1] ? RisingColor : FallingColor;

			// Need a full lookback window of valid bandwidth values before ranking
			if (CurrentBar < Period + SqueezeLookback - 2)
				return;

			// 0 = tightest, 1 = widest over the lookback
			double lo		= minBw[0];
			double hi		= maxBw[0];
			double rank		= (bandwidth[0] - lo) / Math.Max(hi - lo, 1e-10);
			bool isSqueeze	= rank < SqueezeThreshold;

			// Track the tightest band range within the current squeeze episode
			if (isSqueeze)
			{
				if (!sawSqueeze || bandwidth[0] < minW)
				{
					minW	= bandwidth[0];
					sqzTop	= upper;
					sqzBot	= lower;
				}
				sawSqueeze = true;
			}

			// Bands separating: upper rising AND lower falling
			bool bothExpanding	= upper > Upper[1] && lower < Lower[1];
			bool trigger		= sawSqueeze && bothExpanding;

			// Only the first trigger of a cluster draws
			bool firstOfRun		= lastBoxBar < 0 || (CurrentBar - lastBoxBar) >= MinGap;
			bool drewBox		= trigger && firstOfRun;

			if (trigger)
				sawSqueeze = false;		// one box per squeeze episode

			if (drewBox)
			{
				double top = BoxFromBandsAtTrigger ? upper : sqzTop;
				double bot = BoxFromBandsAtTrigger ? lower : sqzBot;

				// Same pattern EngulfingBarsBB uses: start at current bar (0), end N bars into the future (-N)
				Rectangle box = Draw.Rectangle(this, "ADITRADYBANDEXPANDBox" + CurrentBar, false, 0, top, -BoxExtend, bot, BoxBorder, BoxFill, BoxOpacity);

				// Draw objects paint on top of price bars by default (tinting the candles). Push the box behind them.
				if (DrawBehindBars)
				{
					box.IsSeparateZOrder	= true;
					box.ZOrder				= -10000;
				}

				Draw.TriangleUp(this, "ADITRADYBANDEXPANDTri" + CurrentBar, false, 0, Low[0] - (MarkerOffset * TickSize), MarkerColor);

				ExpansionSignal[0]	= 1;
				lastBoxBar			= CurrentBar;

				if (AlertOnSignal && State == State.Realtime)
					Alert("ADITRADYBANDEXPANDAlert" + CurrentBar, Priority.High, "Squeeze -> Expansion",
						NinjaTrader.Core.Globals.InstallDir + @"\sounds\" + SoundFiles, 10, Brushes.Black, Brushes.White);
			}
		}

		#region Properties

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Upper
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Lower
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ExpansionSignal
		{
			get { return Values[2]; }
		}

		// ---- 1. Bollinger Bands ----
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "BB Length", Order = 1, GroupName = "1. Bollinger Bands")]
		public int Period
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.1, double.MaxValue)]
		[Display(Name = "BB StdDev", Order = 2, GroupName = "1. Bollinger Bands")]
		public double NumStdDev
		{ get; set; }

		// ---- 2. Squeeze detection ----
		[NinjaScriptProperty]
		[Range(20, int.MaxValue)]
		[Display(Name = "Squeeze rank lookback", Description = "Bars used to rank how tight the bands are (0 = tightest, 1 = widest).", Order = 1, GroupName = "2. Squeeze Detection")]
		public int SqueezeLookback
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.01, 1.0)]
		[Display(Name = "Squeeze threshold", Description = "Bandwidth rank below this counts as 'contracted into a small space'.", Order = 2, GroupName = "2. Squeeze Detection")]
		public double SqueezeThreshold
		{ get; set; }

		// ---- 3. Box ----
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Extend box (bars)", Order = 1, GroupName = "3. Box")]
		public int BoxExtend
		{ get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Box height from bands at trigger", Description = "Off = box spans the tightest squeeze band range. On = box spans the bands on the trigger bar.", Order = 2, GroupName = "3. Box")]
		public bool BoxFromBandsAtTrigger
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Min bars between boxes", Description = "If triggers cluster, only the first draws; later ones within this many bars are skipped.", Order = 3, GroupName = "3. Box")]
		public int MinGap
		{ get; set; }

		[Display(Name = "Draw boxes behind candles", Description = "On = boxes sit behind the price bars (like TradingView). Off = boxes paint over the bars.", Order = 7, GroupName = "3. Box")]
		public bool DrawBehindBars
		{ get; set; }

		[Range(0, 100)]
		[Display(Name = "Box fill opacity (%)", Order = 4, GroupName = "3. Box")]
		public int BoxOpacity
		{ get; set; }

		[XmlIgnore]
		[Display(Name = "Box fill", Order = 5, GroupName = "3. Box")]
		public Brush BoxFill
		{ get; set; }

		[Browsable(false)]
		public string BoxFillSerialize
		{
			get { return Serialize.BrushToString(BoxFill); }
			set { BoxFill = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Box border", Order = 6, GroupName = "3. Box")]
		public Brush BoxBorder
		{ get; set; }

		[Browsable(false)]
		public string BoxBorderSerialize
		{
			get { return Serialize.BrushToString(BoxBorder); }
			set { BoxBorder = Serialize.StringToBrush(value); }
		}

		// ---- 4. Band colors ----
		[XmlIgnore]
		[Display(Name = "Rising color", Order = 1, GroupName = "4. Colors / Marker")]
		public Brush RisingColor
		{ get; set; }

		[Browsable(false)]
		public string RisingColorSerialize
		{
			get { return Serialize.BrushToString(RisingColor); }
			set { RisingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Falling color", Order = 2, GroupName = "4. Colors / Marker")]
		public Brush FallingColor
		{ get; set; }

		[Browsable(false)]
		public string FallingColorSerialize
		{
			get { return Serialize.BrushToString(FallingColor); }
			set { FallingColor = Serialize.StringToBrush(value); }
		}

		[XmlIgnore]
		[Display(Name = "Marker color", Order = 3, GroupName = "4. Colors / Marker")]
		public Brush MarkerColor
		{ get; set; }

		[Browsable(false)]
		public string MarkerColorSerialize
		{
			get { return Serialize.BrushToString(MarkerColor); }
			set { MarkerColor = Serialize.StringToBrush(value); }
		}

		[Range(0, int.MaxValue)]
		[Display(Name = "Marker offset (ticks)", Order = 4, GroupName = "4. Colors / Marker")]
		public int MarkerOffset
		{ get; set; }

		// ---- 5. Alert ----
		[Display(Name = "Alert on signal", Order = 1, GroupName = "5. Alert")]
		public bool AlertOnSignal
		{ get; set; }

		[Display(Name = "Alert sound", Description = "Sound played when a squeeze -> expansion box is drawn (realtime).", Order = 2, GroupName = "5. Alert")]
		[TypeConverter(typeof(NinjaTrader.NinjaScript.Indicators.ADITRADYBANDEXPANDSoundConverter))]
		public string SoundFiles
		{ get; set; }

		#endregion
	}
}

namespace NinjaTrader.NinjaScript.Indicators
{
	#region Sound Converter
	public class ADITRADYBANDEXPANDSoundConverter : TypeConverter
	{
		public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			if (context == null)
				return null;

			List<string> list = new List<string>();

			DirectoryInfo dir = new DirectoryInfo(NinjaTrader.Core.Globals.InstallDir + @"\sounds\");
			if (dir.Exists)
			{
				FileInfo[] files = dir.GetFiles("*.wav");
				foreach (FileInfo file in files)
					list.Add(file.Name);
			}

			return new TypeConverter.StandardValuesCollection(list);
		}

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;
		}
	}
	#endregion
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ADITRADYBANDEXPAND[] cacheADITRADYBANDEXPAND;
		public ADITRADYBANDEXPAND ADITRADYBANDEXPAND(int period, double numStdDev, int squeezeLookback, double squeezeThreshold, int boxExtend, bool boxFromBandsAtTrigger, int minGap)
		{
			return ADITRADYBANDEXPAND(Input, period, numStdDev, squeezeLookback, squeezeThreshold, boxExtend, boxFromBandsAtTrigger, minGap);
		}

		public ADITRADYBANDEXPAND ADITRADYBANDEXPAND(ISeries<double> input, int period, double numStdDev, int squeezeLookback, double squeezeThreshold, int boxExtend, bool boxFromBandsAtTrigger, int minGap)
		{
			if (cacheADITRADYBANDEXPAND != null)
				for (int idx = 0; idx < cacheADITRADYBANDEXPAND.Length; idx++)
					if (cacheADITRADYBANDEXPAND[idx] != null && cacheADITRADYBANDEXPAND[idx].Period == period && cacheADITRADYBANDEXPAND[idx].NumStdDev == numStdDev && cacheADITRADYBANDEXPAND[idx].SqueezeLookback == squeezeLookback && cacheADITRADYBANDEXPAND[idx].SqueezeThreshold == squeezeThreshold && cacheADITRADYBANDEXPAND[idx].BoxExtend == boxExtend && cacheADITRADYBANDEXPAND[idx].BoxFromBandsAtTrigger == boxFromBandsAtTrigger && cacheADITRADYBANDEXPAND[idx].MinGap == minGap && cacheADITRADYBANDEXPAND[idx].EqualsInput(input))
						return cacheADITRADYBANDEXPAND[idx];
			return CacheIndicator<ADITRADYBANDEXPAND>(new ADITRADYBANDEXPAND(){ Period = period, NumStdDev = numStdDev, SqueezeLookback = squeezeLookback, SqueezeThreshold = squeezeThreshold, BoxExtend = boxExtend, BoxFromBandsAtTrigger = boxFromBandsAtTrigger, MinGap = minGap }, input, ref cacheADITRADYBANDEXPAND);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ADITRADYBANDEXPAND ADITRADYBANDEXPAND(int period, double numStdDev, int squeezeLookback, double squeezeThreshold, int boxExtend, bool boxFromBandsAtTrigger, int minGap)
		{
			return indicator.ADITRADYBANDEXPAND(Input, period, numStdDev, squeezeLookback, squeezeThreshold, boxExtend, boxFromBandsAtTrigger, minGap);
		}

		public Indicators.ADITRADYBANDEXPAND ADITRADYBANDEXPAND(ISeries<double> input , int period, double numStdDev, int squeezeLookback, double squeezeThreshold, int boxExtend, bool boxFromBandsAtTrigger, int minGap)
		{
			return indicator.ADITRADYBANDEXPAND(input, period, numStdDev, squeezeLookback, squeezeThreshold, boxExtend, boxFromBandsAtTrigger, minGap);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ADITRADYBANDEXPAND ADITRADYBANDEXPAND(int period, double numStdDev, int squeezeLookback, double squeezeThreshold, int boxExtend, bool boxFromBandsAtTrigger, int minGap)
		{
			return indicator.ADITRADYBANDEXPAND(Input, period, numStdDev, squeezeLookback, squeezeThreshold, boxExtend, boxFromBandsAtTrigger, minGap);
		}

		public Indicators.ADITRADYBANDEXPAND ADITRADYBANDEXPAND(ISeries<double> input , int period, double numStdDev, int squeezeLookback, double squeezeThreshold, int boxExtend, bool boxFromBandsAtTrigger, int minGap)
		{
			return indicator.ADITRADYBANDEXPAND(input, period, numStdDev, squeezeLookback, squeezeThreshold, boxExtend, boxFromBandsAtTrigger, minGap);
		}
	}
}

#endregion
