#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class EngulfingBarsBB : Indicator
	{
		private const string SystemVersion 					= " V1.1";
        private const string SystemName 					= "EngulfingBarsBB";
		
		
		private bool currentBodyEngulfGreen;
		private bool currentBodyEngulfRed;
		
		private bool currentOBGreen;
		private bool currentOBRed;
		
		private Bollinger Bollinger1;
		
		
		
		
		
		
		
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Will color Outside/Engulfing bars";
				Name										= @"EngulfingBarsBB v1.1";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				BBPeriod					= 20;
				BBStdDev					= 2;
				
				Offset						= 10;
				
		
				///Default colors for Outside Bars
				GreenOutsideBar 							= Brushes.RoyalBlue;
				RedOutsideBar								= Brushes.DarkMagenta;
				
				UpArrow			 							= Brushes.RoyalBlue;
				DnArrow										= Brushes.DarkMagenta;
				
				
				
				///Current or Previous Outside Bars condition is true
				currentOBGreen								= false;
				currentOBRed								= false;
				
				currentBodyEngulfGreen						= false;
				currentBodyEngulfRed						= false;
				
				
					
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{				
				Bollinger1			= Bollinger(Close, BBStdDev, Convert.ToInt32(BBPeriod));
			}
			
			
		
			
		}
		
		public override string DisplayName
			{
  				get { return "" + Name; }
			}
		
		protected override void OnBarUpdate()
		{
			
			if(CurrentBar < 2) return;
			
			BarBrush	= null;
			BackBrushes = null;
			
	
		
	#region Current Outside Bar Logic
		
		///Current Outside Bars 'Without' Engulf Body Selected	
			
			//Bullish Engulfing
			if (Open[1] > Close[1] //Red (Down) Candle
					&& Close[0] > Open[0] //Green (Up) Candle
					&& Close[0] > Open[1]
					&& Close[1] >= Open[0])
					
			
			{
				currentOBGreen = true;
			}
				else
			{
				currentOBGreen = false;	
			}
			
			
			//Bearish Engulfing	
			if (Close[1] > Open[1] //Green (Up) Candle
					&& Open[0] > Close[0] //Red (Down) Candle
					&& Open[0] >= Close[1]
					&& Open[1] > Close[0])
			
			{
				currentOBRed = true;
			}
				else
			{
				currentOBRed = false;	
			}

	#endregion
	
			
			
	#region Engulfing Candle off Upper/Lower Bollinger Bands
			
			//Short off Upper Band
			if ((High[0] >= Bollinger1.Upper[0] || High[1] >= Bollinger1.Upper[1])
				&& currentOBRed == true)
				{
					BarBrush = RedOutsideBar;
					Draw.ArrowDown(this, @"Short_Setup" + CurrentBar, false, 0, (High[0] + (Offset * TickSize)) , DnArrow);
					PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\" + SoundFiles);
				}
				
				
			//Long off Lower Band
			if ((Low[0] <= Bollinger1.Lower[0] || Low[1] <= Bollinger1.Lower[1])
				&& currentOBGreen == true)
				{
					BarBrush = GreenOutsideBar;
					Draw.ArrowUp(this, @"Long_Setup" + CurrentBar, false, 0, (Low[0] + (-Offset * TickSize)) , UpArrow);
					PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\" + SoundFiles);
				}
	#endregion
				
	
		}
			
		
	
		#region Properties
	
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BB Period", Description="Bollinger Band Period", Order=1, GroupName="1. Bollinger Band Parameters")]
		public int BBPeriod
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.5, double.MaxValue)]
		[Display(Name="BB Standard Deviations", Description="Bollinger Band Standard Deviations", Order=1, GroupName="1. Bollinger Band Parameters")]
		public double BBStdDev
		{ get; set; }
		
		
		
		#region Arrow Visuals
		[XmlIgnore()]
		[Display(Name = "Color Up Arrow", GroupName = "3. Arrow Visuals", Order = 1)]
		public Brush UpArrow
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string UpArrowSerialize
		{
			get { return Serialize.BrushToString(UpArrow); }
   			set { UpArrow = Serialize.StringToBrush(value); }
		}
		
			[XmlIgnore()]
		[Display(Name = "Color Down Arrow", GroupName = "3. Arrow Visuals", Order = 2)]
		public Brush DnArrow
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string DnArrowSerialize
		{
			get { return Serialize.BrushToString(DnArrow); }
   			set { DnArrow = Serialize.StringToBrush(value); }
		}
		
				
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Arrow Offset", Description="Tick Offset for Up/Down Arrows", Order=3, GroupName="3. Arrow Visuals")]
		public int Offset
		{ get; set; }
		
		#endregion
		
		
		#region Color Outside Bars
		
		[XmlIgnore()]
		[Display(Name = "Bullish Engulfing Candle", GroupName = "2. Engulfing Candle Visuals", Order = 1)]
		public Brush GreenOutsideBar
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string GreenOutsideBarSerialize
		{
			get { return Serialize.BrushToString(GreenOutsideBar); }
   			set { GreenOutsideBar = Serialize.StringToBrush(value); }
		}
		
			[XmlIgnore()]
		[Display(Name = "Bearish Engulfing Candle", GroupName = "2. Engulfing Candle Visuals", Order = 2)]
		public Brush RedOutsideBar
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string RedOutsideBarSerialize
		{
			get { return Serialize.BrushToString(RedOutsideBar); }
   			set { RedOutsideBar = Serialize.StringToBrush(value); }
		}
		
		#endregion
		
		
		[NinjaScriptProperty]
		[Display(Name="Alert Sound", Description="Sound for Entry Signals", Order=1, GroupName="4. Sounds")]
		[TypeConverter(typeof(NinjaTrader.NinjaScript.Indicators.EngBBSoundConverter))] 
		public string SoundFiles
		{get;set;}
		
		#endregion
		
	}
	
	#region Sound Converter	
		public class EngBBSoundConverter : TypeConverter
	{
		
		public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			if (context == null)
			{
				return null;
			}
			//List <string> list;
			List <string> list = new List <string> ();
			
			
			DirectoryInfo dir = new DirectoryInfo(NinjaTrader.Core.Globals.InstallDir+@"\sounds\");
			
			FileInfo[] files= dir.GetFiles("*.wav");
			
			foreach (FileInfo file in files)
			{
				list.Add(file.Name);
			}
				
			
			return new TypeConverter.StandardValuesCollection(list);
		}
		
	

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;
		}
	}
#endregion
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private EngulfingBarsBB[] cacheEngulfingBarsBB;
		public EngulfingBarsBB EngulfingBarsBB(int bBPeriod, double bBStdDev, int offset, string soundFiles)
		{
			return EngulfingBarsBB(Input, bBPeriod, bBStdDev, offset, soundFiles);
		}

		public EngulfingBarsBB EngulfingBarsBB(ISeries<double> input, int bBPeriod, double bBStdDev, int offset, string soundFiles)
		{
			if (cacheEngulfingBarsBB != null)
				for (int idx = 0; idx < cacheEngulfingBarsBB.Length; idx++)
					if (cacheEngulfingBarsBB[idx] != null && cacheEngulfingBarsBB[idx].BBPeriod == bBPeriod && cacheEngulfingBarsBB[idx].BBStdDev == bBStdDev && cacheEngulfingBarsBB[idx].Offset == offset && cacheEngulfingBarsBB[idx].SoundFiles == soundFiles && cacheEngulfingBarsBB[idx].EqualsInput(input))
						return cacheEngulfingBarsBB[idx];
			return CacheIndicator<EngulfingBarsBB>(new EngulfingBarsBB(){ BBPeriod = bBPeriod, BBStdDev = bBStdDev, Offset = offset, SoundFiles = soundFiles }, input, ref cacheEngulfingBarsBB);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.EngulfingBarsBB EngulfingBarsBB(int bBPeriod, double bBStdDev, int offset, string soundFiles)
		{
			return indicator.EngulfingBarsBB(Input, bBPeriod, bBStdDev, offset, soundFiles);
		}

		public Indicators.EngulfingBarsBB EngulfingBarsBB(ISeries<double> input , int bBPeriod, double bBStdDev, int offset, string soundFiles)
		{
			return indicator.EngulfingBarsBB(input, bBPeriod, bBStdDev, offset, soundFiles);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.EngulfingBarsBB EngulfingBarsBB(int bBPeriod, double bBStdDev, int offset, string soundFiles)
		{
			return indicator.EngulfingBarsBB(Input, bBPeriod, bBStdDev, offset, soundFiles);
		}

		public Indicators.EngulfingBarsBB EngulfingBarsBB(ISeries<double> input , int bBPeriod, double bBStdDev, int offset, string soundFiles)
		{
			return indicator.EngulfingBarsBB(input, bBPeriod, bBStdDev, offset, soundFiles);
		}
	}
}

#endregion
