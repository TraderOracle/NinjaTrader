#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class EngulfingBarsBB : Indicator
	{
		private const string SystemVersion 					= " V1.6";
        private const string SystemName 					= "EngulfingBarsBB";
		
		
		private bool currentBodyEngulfGreen;
		private bool currentBodyEngulfRed;
		
		private bool currentOBGreen;
		private bool currentOBRed;
		
		private SMA		sma;
		private StdDev	stdDev;
		
		private double BarSize;
		
		//Entry Line Parameters
		private Brush	  lineColor1 = Brushes.RoyalBlue;	// Line Color above price
		private Brush	  lineColor2 = Brushes.DarkMagenta;		// Line Color below price
		private int		  lineWidth1 = 3;				// Line Width above price
		private int		  lineWidth2 = 3;				// Line Width below price
		private DashStyleHelper lineStyle = DashStyleHelper.Solid;
		private int rayLength		= 2;
		
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Will color Outside/Engulfing bars";
				Name										= @"EngulfingBarsBB v1.6";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				IsAutoScale 								= false;
				PaintPriceMarkers 							= false;
				
				NumStdDev					= 2;
				Period						= 20;

				AddPlot(Brushes.MediumPurple, NinjaTrader.Custom.Resource.BollingerUpperBand);
				AddPlot(Brushes.Transparent, NinjaTrader.Custom.Resource.BollingerMiddleBand);
				AddPlot(Brushes.MediumPurple, NinjaTrader.Custom.Resource.BollingerLowerBand);
				
				Offset						= 10;
				
				MinTick						= 10;
				BarSize						= 0;
				
				Zones						= true; // Show Zones
				ZoneOp						= 25;   // Zone Opacity
				ZnBars						= 10;   // Candles to Draw Zones
				
		
				///Default colors for Outside Bars
				GreenOutsideBar 							= Brushes.RoyalBlue;
				RedOutsideBar								= Brushes.DarkMagenta;
				
				// Arrow Color
				UpArrow			 							= Brushes.RoyalBlue;
				DnArrow										= Brushes.DarkMagenta;
				
				// Arrow Outline Color
				UpArrowOL		 							= Brushes.RoyalBlue;
				DnArrowOL									= Brushes.DarkMagenta;
				
				// Zone Colors
				LtZone										= Brushes.LightGray;
				LtZoneBr									= Brushes.Transparent;
				
				ShZone										= Brushes.SkyBlue;
				ShZoneBr									= Brushes.Transparent;
								
				///Current or Previous Outside Bars condition is true
				currentOBGreen								= false;
				currentOBRed								= false;
				
				currentBodyEngulfGreen						= false;
				currentBodyEngulfRed						= false;
				
				
					
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{				
				sma		= SMA(Period);
				stdDev	= StdDev(Period);
			}
			
			
		
			
		}
		
		public override string DisplayName
			{
  				get { return "" + Name; }
			}
		
		protected override void OnBarUpdate()
		{
			
			if(CurrentBar < 2) return;
			
			double sma0		= sma[0];
			double stdDev0	= stdDev[0];

			Upper[0]		= sma0 + NumStdDev * stdDev0;
			Middle[0]		= sma0;
			Lower[0]		= sma0 - NumStdDev * stdDev0;
			
			BarBrush	= null;
			BackBrushes = null;
			
			BarSize = ((High[0] - Low[0]) * (1 / TickSize));
			//Print ("Bar Size is " + BarSize);
			
	
		
	#region Current Outside Bar Logic
		
		///Current Outside Bars 'Without' Engulf Body Selected	
			
			//Bullish Engulfing
			if (Open[1] > Close[1] //Red (Down) Candle
					&& Close[0] > Open[0] //Green (Up) Candle
					&& Close[0] >= Open[1]
					&& Close[1] >= Open[0]
					&& (Close[0] - Open[0]) > (Open[1] - Close[1]))
					
			
			{
				currentOBGreen = true;
			}
				else
			{
				currentOBGreen = false;	
			}
			
			
			//Bearish Engulfing	
			if (Close[1] > Open[1] //Green (Up) Candle
					&& Open[0] > Close[0] //Red (Down) Candle
					&& Open[0] >= Close[1]
					&& Open[1] >= Close[0]
					&& (Open[0] - Close[0]) > (Close[1] - Open[1]))
			
			{
				currentOBRed = true;
			}
				else
			{
				currentOBRed = false;	
			}

	#endregion
	
			
			
	#region Engulfing Candle off Upper/Lower Bollinger Bands
			
			//Short off Upper Band
			if ((High[0] + (-2 * TickSize) >= Upper[0] || High[1] >= Upper[1])
				&& currentOBRed == true
				&& BarSize >= MinTick)
				{
					BarBrush = RedOutsideBar;
					Draw.Line(this,"ShortEntry" + CurrentBar, false, -rayLength, Low[0] + (-1 * TickSize), 0, Low[0] + (-1 * TickSize), lineColor2, lineStyle, lineWidth2);
					ArrowDown myArrowDown = Draw.ArrowDown(this, @"Short_Setup" + CurrentBar, false, 0, (High[0] + (Offset * TickSize)) , DnArrow);
					myArrowDown.OutlineBrush = DnArrowOL;
					PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\" + SoundFiles);
					if (Zones)
					{
						Draw.Rectangle(this, @"Light Zone S" + CurrentBar, false, 0, High[0], -ZnBars, Low[0], LtZoneBr, LtZone, ZoneOp);
						Draw.Rectangle(this, @"Shadow Zone S" + CurrentBar, false, 0, High[0], -ZnBars, High[0] + (High[0]-Low[0]), ShZoneBr, ShZone, ZoneOp);
					}
				}
				
				
			//Long off Lower Band
			if ((Low[0] + (2 * TickSize) <= Lower[0] || Low[1] <= Lower[1])
				&& currentOBGreen == true
				&& BarSize >= MinTick)
				{
					BarBrush = GreenOutsideBar;
					Draw.Line(this,"LongEntry" + CurrentBar, false, -rayLength, High[0] + (1 * TickSize), 0, High[0] + (1 * TickSize), lineColor1, lineStyle, lineWidth1);
					ArrowUp myArrowUp = Draw.ArrowUp(this, @"Long_Setup" + CurrentBar, false,  0, (Low[0] + (-Offset * TickSize)) , UpArrow);
					myArrowUp.OutlineBrush = UpArrowOL;
					PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\" + SoundFiles);
					if (Zones)
					{
						Draw.Rectangle(this, @"Light Zone L" + CurrentBar, false, 0, High[0], -ZnBars, Low[0], LtZoneBr, LtZone, ZoneOp);
						Draw.Rectangle(this, @"Shadow Zone L" + CurrentBar, false, 0, Low[0], -ZnBars, Low[0] - (High[0]-Low[0]), ShZoneBr, ShZone, ZoneOp);
					}
				}
	#endregion
				
	
		}
			
		
	
		#region Properties
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Upper
		{
			get { return Values[0]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Middle
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> Lower
		{
			get { return Values[2]; }
		}
	
		[Range(0, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "NumStdDev", GroupName = "1. Bollinger Band Parameters", Order = 0)]
		public double NumStdDev
		{ get; set; }

		[Range(1, int.MaxValue), NinjaScriptProperty]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "1. Bollinger Band Parameters", Order = 1)]
		public int Period
		{ get; set; }
		
		
		
		#region Arrow Visuals
		[XmlIgnore()]
		[Display(Name = "Color - Up Arrow", GroupName = "3. Arrow Visuals", Order = 1)]
		public Brush UpArrow
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string UpArrowSerialize
		{
			get { return Serialize.BrushToString(UpArrow); }
   			set { UpArrow = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore()]
		[Display(Name = "Color - Down Arrow", GroupName = "3. Arrow Visuals", Order = 2)]
		public Brush DnArrow
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string DnArrowSerialize
		{
			get { return Serialize.BrushToString(DnArrow); }
   			set { DnArrow = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore()]
		[Display(Name = "Outline Color - Up Arrow", GroupName = "3. Arrow Visuals", Order = 3)]
		public Brush UpArrowOL
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string UpArrowOLSerialize
		{
			get { return Serialize.BrushToString(UpArrowOL); }
   			set { UpArrowOL = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore()]
		[Display(Name = "Outline Color - Down Arrow", GroupName = "3. Arrow Visuals", Order = 4)]
		public Brush DnArrowOL
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string DnArrowOLSerialize
		{
			get { return Serialize.BrushToString(DnArrowOL); }
   			set { DnArrowOL = Serialize.StringToBrush(value); }
		}
		
				
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Arrow Offset", Description="Tick Offset for Up/Down Arrows", Order=5, GroupName="3. Arrow Visuals")]
		public int Offset
		{ get; set; }
		
		#endregion
		
		
		#region Color Outside Bars
		
		[XmlIgnore()]
		[Display(Name = "Bullish Engulfing Candle", GroupName = "2. Engulfing Candle Visuals", Order = 1)]
		public Brush GreenOutsideBar
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string GreenOutsideBarSerialize
		{
			get { return Serialize.BrushToString(GreenOutsideBar); }
   			set { GreenOutsideBar = Serialize.StringToBrush(value); }
		}
		
			[XmlIgnore()]
		[Display(Name = "Bearish Engulfing Candle", GroupName = "2. Engulfing Candle Visuals", Order = 2)]
		public Brush RedOutsideBar
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string RedOutsideBarSerialize
		{
			get { return Serialize.BrushToString(RedOutsideBar); }
   			set { RedOutsideBar = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Min Candle Size (Ticks)", Description="Minimum Candle Size (Ticks)", Order=3, GroupName="2. Engulfing Candle Visuals")]
		public int MinTick
		{ get; set; }
		
		#endregion
		
		
		#region Entry Line Plots
		[NinjaScriptProperty]						
		[Display(Name = "1. Entry Line Style", Description = "Line Style for all Lines", GroupName = "5. Entry Plots", Order = 1)]						
		public DashStyleHelper LineStyle
        {
            get { return lineStyle; }
            set { lineStyle = value; }
        }
		 
	    [XmlIgnore()]
		 
	    [NinjaScriptProperty]		 
	    [Display(Name = "2. Entry Line Color Long Entry", Description = "Color of the Line for Long Entry", GroupName = "5. Entry Plots", Order = 2)]
        public Brush LineColor1
        {
            get { return lineColor1; }
            set { lineColor1 = value; }
        }
			[Browsable(false)]
			public string LineColor1Serialize
			{
				get { return Serialize.BrushToString(lineColor1); }//SerializableColor
				set { lineColor1 = Serialize.StringToBrush(value); }
			}
			
		[XmlIgnore()]
		
		[NinjaScriptProperty]			
		[Display(Name = "3. Entry Line Color Short Entry", Description = "Color of the Line for Short Entry", GroupName = "5. Entry Plots", Order = 3)]
        public Brush LineColor2
        {
            get { return lineColor2; }
            set { lineColor2 = value; }
        }
			[Browsable(false)]
			public string LineColor3Serialize
			{
				get { return Serialize.BrushToString(lineColor2); }//SerializableColor
				set { lineColor2 = Serialize.StringToBrush(value); }
			}	

			
    	[NinjaScriptProperty]
			
    	[Display(Name = "4. Entry Line Width Long Entry", Description = "Width of Line for Long Entry", GroupName = "5. Entry Plots", Order = 4)]
			
    	public int LineWidth1
        {
            get { return lineWidth1; }
			set { lineWidth1 = Math.Max(1, value); }
        }
		
		[NinjaScriptProperty]		
		[Display(Name = "5. Entry Line Width Short Entry", Description = "Width of Line for Short Entry", GroupName = "5. Entry Plots", Order = 5)]		
		public int LineWidth2
        {
            get { return lineWidth2; }
			set { lineWidth2 = Math.Max(1, value); }
        }
		
		
		
     	[NinjaScriptProperty]		
     	[Display(Name = "6. Entry Line Length", Description = "Line Length", GroupName = "5. Entry Plots", Order = 6)]		
     	public int RayLength
        {
            get { return rayLength; }
			set { rayLength = Math.Min(20,Math.Max(value,0)); }
        }
		#endregion
		
		
		#region Alert Sound
		[NinjaScriptProperty]
		[Display(Name="Alert Sound", Description="Sound for Entry Signals", Order=1, GroupName="4. Sounds")]
		[TypeConverter(typeof(NinjaTrader.NinjaScript.Indicators.EngBBSoundConverter))] 
		public string SoundFiles
		{get;set;}
		#endregion
		
		#region Shadow Zone Parameters
		[NinjaScriptProperty]
		[Display(Name="Show Shadow Zones", Description="Show Shadow Zones", Order=1, GroupName="6. Shadow Zone Parameters")]
		public bool Zones
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="# of Candles to Draw Zones", Description="# of Candles to Draw Zones", Order=2, GroupName="6. Shadow Zone Parameters")]
		public int ZnBars
		{ get; set; }
		
		[XmlIgnore()]
		[Display(Name = "Light Zone Color", GroupName = "6. Shadow Zone Parameters", Order = 3)]
		public Brush LtZone
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string LtZoneSerialize
		{
			get { return Serialize.BrushToString(LtZone); }
   			set { LtZone = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore()]
		[Display(Name = "Light Zone Border Color", GroupName = "6. Shadow Zone Parameters", Order = 4)]
		public Brush LtZoneBr
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string LtZoneBrSerialize
		{
			get { return Serialize.BrushToString(LtZoneBr); }
   			set { LtZoneBr = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore()]
		[Display(Name = "Shadow Zone Color", GroupName = "6. Shadow Zone Parameters", Order = 5)]
		public Brush ShZone
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string ShZoneSerialize
		{
			get { return Serialize.BrushToString(ShZone); }
   			set { ShZone = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore()]
		[Display(Name = "Shadow Zone Border Color", GroupName = "6. Shadow Zone Parameters", Order = 6)]
		public Brush ShZoneBr
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string ShZoneBrSerialize
		{
			get { return Serialize.BrushToString(ShZoneBr); }
   			set { ShZoneBr = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Zone Opacity", Description="Zone Opacity", Order=7, GroupName="6. Shadow Zone Parameters")]
		public int ZoneOp
		{ get; set; }
		#endregion
		
		#endregion
		
	}
	
	#region Sound Converter	
		public class EngBBSoundConverter : TypeConverter
	{
		
		public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			if (context == null)
			{
				return null;
			}
			//List <string> list;
			List <string> list = new List <string> ();
			
			
			DirectoryInfo dir = new DirectoryInfo(NinjaTrader.Core.Globals.InstallDir+@"\sounds\");
			
			FileInfo[] files= dir.GetFiles("*.wav");
			
			foreach (FileInfo file in files)
			{
				list.Add(file.Name);
			}
				
			
			return new TypeConverter.StandardValuesCollection(list);
		}
		
	

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;
		}
	}
#endregion
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private EngulfingBarsBB[] cacheEngulfingBarsBB;
		public EngulfingBarsBB EngulfingBarsBB(double numStdDev, int period, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles, bool zones, int znBars, int zoneOp)
		{
			return EngulfingBarsBB(Input, numStdDev, period, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles, zones, znBars, zoneOp);
		}

		public EngulfingBarsBB EngulfingBarsBB(ISeries<double> input, double numStdDev, int period, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles, bool zones, int znBars, int zoneOp)
		{
			if (cacheEngulfingBarsBB != null)
				for (int idx = 0; idx < cacheEngulfingBarsBB.Length; idx++)
					if (cacheEngulfingBarsBB[idx] != null && cacheEngulfingBarsBB[idx].NumStdDev == numStdDev && cacheEngulfingBarsBB[idx].Period == period && cacheEngulfingBarsBB[idx].Offset == offset && cacheEngulfingBarsBB[idx].MinTick == minTick && cacheEngulfingBarsBB[idx].LineStyle == lineStyle && cacheEngulfingBarsBB[idx].LineColor1 == lineColor1 && cacheEngulfingBarsBB[idx].LineColor2 == lineColor2 && cacheEngulfingBarsBB[idx].LineWidth1 == lineWidth1 && cacheEngulfingBarsBB[idx].LineWidth2 == lineWidth2 && cacheEngulfingBarsBB[idx].RayLength == rayLength && cacheEngulfingBarsBB[idx].SoundFiles == soundFiles && cacheEngulfingBarsBB[idx].Zones == zones && cacheEngulfingBarsBB[idx].ZnBars == znBars && cacheEngulfingBarsBB[idx].ZoneOp == zoneOp && cacheEngulfingBarsBB[idx].EqualsInput(input))
						return cacheEngulfingBarsBB[idx];
			return CacheIndicator<EngulfingBarsBB>(new EngulfingBarsBB(){ NumStdDev = numStdDev, Period = period, Offset = offset, MinTick = minTick, LineStyle = lineStyle, LineColor1 = lineColor1, LineColor2 = lineColor2, LineWidth1 = lineWidth1, LineWidth2 = lineWidth2, RayLength = rayLength, SoundFiles = soundFiles, Zones = zones, ZnBars = znBars, ZoneOp = zoneOp }, input, ref cacheEngulfingBarsBB);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.EngulfingBarsBB EngulfingBarsBB(double numStdDev, int period, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles, bool zones, int znBars, int zoneOp)
		{
			return indicator.EngulfingBarsBB(Input, numStdDev, period, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles, zones, znBars, zoneOp);
		}

		public Indicators.EngulfingBarsBB EngulfingBarsBB(ISeries<double> input , double numStdDev, int period, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles, bool zones, int znBars, int zoneOp)
		{
			return indicator.EngulfingBarsBB(input, numStdDev, period, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles, zones, znBars, zoneOp);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.EngulfingBarsBB EngulfingBarsBB(double numStdDev, int period, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles, bool zones, int znBars, int zoneOp)
		{
			return indicator.EngulfingBarsBB(Input, numStdDev, period, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles, zones, znBars, zoneOp);
		}

		public Indicators.EngulfingBarsBB EngulfingBarsBB(ISeries<double> input , double numStdDev, int period, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles, bool zones, int znBars, int zoneOp)
		{
			return indicator.EngulfingBarsBB(input, numStdDev, period, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles, zones, znBars, zoneOp);
		}
	}
}

#endregion
