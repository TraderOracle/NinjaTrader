#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class EngulfingBarsBB : Indicator
	{
		private const string SystemVersion 					= " V1.3";
        private const string SystemName 					= "EngulfingBarsBB";
		
		
		private bool currentBodyEngulfGreen;
		private bool currentBodyEngulfRed;
		
		private bool currentOBGreen;
		private bool currentOBRed;
		
		private Bollinger Bollinger1;
		
		private double BarSize;
		
		//Entry Line Parameters
		private Brush	  lineColor1 = Brushes.Lime;	// Line Color above price
		private Brush	  lineColor2 = Brushes.Red;		// Line Color below price
		private int		  lineWidth1 = 3;				// Line Width above price
		private int		  lineWidth2 = 3;				// Line Width below price
		private DashStyleHelper lineStyle = DashStyleHelper.Solid;
		private int rayLength		= 2;
		
		
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Will color Outside/Engulfing bars";
				Name										= @"EngulfingBarsBB v1.3";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				
				BBPeriod					= 20;
				BBStdDev					= 2;
				
				Offset						= 10;
				
				MinTick						= 10;
				BarSize						= 0;
				
		
				///Default colors for Outside Bars
				GreenOutsideBar 							= Brushes.RoyalBlue;
				RedOutsideBar								= Brushes.DarkMagenta;
				
				// Arrow Color
				UpArrow			 							= Brushes.RoyalBlue;
				DnArrow										= Brushes.DarkMagenta;
				
				// Arrow Outline Color
				UpArrowOL		 							= Brushes.RoyalBlue;
				DnArrowOL									= Brushes.DarkMagenta;
				
				
				
				///Current or Previous Outside Bars condition is true
				currentOBGreen								= false;
				currentOBRed								= false;
				
				currentBodyEngulfGreen						= false;
				currentBodyEngulfRed						= false;
				
				
					
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{				
				Bollinger1			= Bollinger(Close, BBStdDev, Convert.ToInt32(BBPeriod));
			}
			
			
		
			
		}
		
		public override string DisplayName
			{
  				get { return "" + Name; }
			}
		
		protected override void OnBarUpdate()
		{
			
			if(CurrentBar < 2) return;
			
			BarBrush	= null;
			BackBrushes = null;
			
			BarSize = ((High[0] - Low[0]) * (1 / TickSize));
			//Print ("Bar Size is " + BarSize);
			
	
		
	#region Current Outside Bar Logic
		
		///Current Outside Bars 'Without' Engulf Body Selected	
			
			//Bullish Engulfing
			if (Open[1] > Close[1] //Red (Down) Candle
					&& Close[0] > Open[0] //Green (Up) Candle
					&& Close[0] > Open[1]
					&& Close[1] >= Open[0])
					
			
			{
				currentOBGreen = true;
			}
				else
			{
				currentOBGreen = false;	
			}
			
			
			//Bearish Engulfing	
			if (Close[1] > Open[1] //Green (Up) Candle
					&& Open[0] > Close[0] //Red (Down) Candle
					&& Open[0] >= Close[1]
					&& Open[1] > Close[0])
			
			{
				currentOBRed = true;
			}
				else
			{
				currentOBRed = false;	
			}

	#endregion
	
			
			
	#region Engulfing Candle off Upper/Lower Bollinger Bands
			
			//Short off Upper Band
			if ((High[0] >= Bollinger1.Upper[0] || High[1] >= Bollinger1.Upper[1])
				&& currentOBRed == true
				&& BarSize >= MinTick)
				{
					BarBrush = RedOutsideBar;
					Draw.Line(this,"ShortEntry" + CurrentBar, false, -rayLength, Low[0] + (-1 * TickSize), 0, Low[0] + (-1 * TickSize), lineColor2, lineStyle, lineWidth2);
					ArrowDown myArrowDown = Draw.ArrowDown(this, @"Short_Setup" + CurrentBar, false, 0, (High[0] + (Offset * TickSize)) , DnArrow);
					myArrowDown.OutlineBrush = DnArrowOL;
					PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\" + SoundFiles);
				}
				
				
			//Long off Lower Band
			if ((Low[0] <= Bollinger1.Lower[0] || Low[1] <= Bollinger1.Lower[1])
				&& currentOBGreen == true
				&& BarSize >= MinTick)
				{
					BarBrush = GreenOutsideBar;
					Draw.Line(this,"LongEntry" + CurrentBar, false, -rayLength, High[0] + (1 * TickSize), 0, High[0] + (1 * TickSize), lineColor1, lineStyle, lineWidth1);
					ArrowUp myArrowUp = Draw.ArrowUp(this, @"Long_Setup" + CurrentBar, false,  0, (Low[0] + (-Offset * TickSize)) , UpArrow);
					myArrowUp.OutlineBrush = UpArrowOL;
					PlaySound(NinjaTrader.Core.Globals.InstallDir + @"\sounds\" + SoundFiles);
				}
	#endregion
				
	
		}
			
		
	
		#region Properties
	
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="BB Period", Description="Bollinger Band Period", Order=1, GroupName="1. Bollinger Band Parameters")]
		public int BBPeriod
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.5, double.MaxValue)]
		[Display(Name="BB Standard Deviations", Description="Bollinger Band Standard Deviations", Order=1, GroupName="1. Bollinger Band Parameters")]
		public double BBStdDev
		{ get; set; }
		
		
		
		#region Arrow Visuals
		[XmlIgnore()]
		[Display(Name = "Color - Up Arrow", GroupName = "3. Arrow Visuals", Order = 1)]
		public Brush UpArrow
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string UpArrowSerialize
		{
			get { return Serialize.BrushToString(UpArrow); }
   			set { UpArrow = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore()]
		[Display(Name = "Color - Down Arrow", GroupName = "3. Arrow Visuals", Order = 2)]
		public Brush DnArrow
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string DnArrowSerialize
		{
			get { return Serialize.BrushToString(DnArrow); }
   			set { DnArrow = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore()]
		[Display(Name = "Outline Color - Up Arrow", GroupName = "3. Arrow Visuals", Order = 3)]
		public Brush UpArrowOL
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string UpArrowOLSerialize
		{
			get { return Serialize.BrushToString(UpArrowOL); }
   			set { UpArrowOL = Serialize.StringToBrush(value); }
		}
		
		[XmlIgnore()]
		[Display(Name = "Outline Color - Down Arrow", GroupName = "3. Arrow Visuals", Order = 4)]
		public Brush DnArrowOL
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string DnArrowOLSerialize
		{
			get { return Serialize.BrushToString(DnArrowOL); }
   			set { DnArrowOL = Serialize.StringToBrush(value); }
		}
		
				
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Arrow Offset", Description="Tick Offset for Up/Down Arrows", Order=5, GroupName="3. Arrow Visuals")]
		public int Offset
		{ get; set; }
		
		#endregion
		
		
		#region Color Outside Bars
		
		[XmlIgnore()]
		[Display(Name = "Bullish Engulfing Candle", GroupName = "2. Engulfing Candle Visuals", Order = 1)]
		public Brush GreenOutsideBar
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string GreenOutsideBarSerialize
		{
			get { return Serialize.BrushToString(GreenOutsideBar); }
   			set { GreenOutsideBar = Serialize.StringToBrush(value); }
		}
		
			[XmlIgnore()]
		[Display(Name = "Bearish Engulfing Candle", GroupName = "2. Engulfing Candle Visuals", Order = 2)]
		public Brush RedOutsideBar
		{ get; set; }
		
		// Serialize our Color object
		[Browsable(false)]
		public string RedOutsideBarSerialize
		{
			get { return Serialize.BrushToString(RedOutsideBar); }
   			set { RedOutsideBar = Serialize.StringToBrush(value); }
		}
		
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Min Candle Size (Ticks)", Description="Minimum Candle Size (Ticks)", Order=3, GroupName="2. Engulfing Candle Visuals")]
		public int MinTick
		{ get; set; }
		
		#endregion
		
		
		#region Entry Line Plots
		[NinjaScriptProperty]						
		[Display(Name = "1. Entry Line Style", Description = "Line Style for all Lines", GroupName = "Entry Plots", Order = 1)]						
		public DashStyleHelper LineStyle
        {
            get { return lineStyle; }
            set { lineStyle = value; }
        }
		 
	    [XmlIgnore()]
		 
	    [NinjaScriptProperty]		 
	    [Display(Name = "2. Entry Line Color Long Entry", Description = "Color of the Line for Long Entry", GroupName = "Entry Plots", Order = 2)]
        public Brush LineColor1
        {
            get { return lineColor1; }
            set { lineColor1 = value; }
        }
			[Browsable(false)]
			public string LineColor1Serialize
			{
				get { return Serialize.BrushToString(lineColor1); }//SerializableColor
				set { lineColor1 = Serialize.StringToBrush(value); }
			}
			
		[XmlIgnore()]
		
		[NinjaScriptProperty]			
		[Display(Name = "3. Entry Line Color Short Entry", Description = "Color of the Line for Short Entry", GroupName = "Entry Plots", Order = 3)]
        public Brush LineColor2
        {
            get { return lineColor2; }
            set { lineColor2 = value; }
        }
			[Browsable(false)]
			public string LineColor3Serialize
			{
				get { return Serialize.BrushToString(lineColor2); }//SerializableColor
				set { lineColor2 = Serialize.StringToBrush(value); }
			}	

			
    	[NinjaScriptProperty]
			
    	[Display(Name = "4. Entry Line Width Long Entry", Description = "Width of Line for Long Entry", GroupName = "Entry Plots", Order = 4)]
			
    	public int LineWidth1
        {
            get { return lineWidth1; }
			set { lineWidth1 = Math.Max(1, value); }
        }
		
		[NinjaScriptProperty]		
		[Display(Name = "5. Entry Line Width Short Entry", Description = "Width of Line for Short Entry", GroupName = "Entry Plots", Order = 5)]		
		public int LineWidth2
        {
            get { return lineWidth2; }
			set { lineWidth2 = Math.Max(1, value); }
        }
		
		
		
     	[NinjaScriptProperty]		
     	[Display(Name = "6. Entry Line Length", Description = "Line Length", GroupName = "Entry Plots", Order = 6)]		
     	public int RayLength
        {
            get { return rayLength; }
			set { rayLength = Math.Min(20,Math.Max(value,0)); }
        }
		#endregion
		
		
		#region Alert Sound
		[NinjaScriptProperty]
		[Display(Name="Alert Sound", Description="Sound for Entry Signals", Order=1, GroupName="4. Sounds")]
		[TypeConverter(typeof(NinjaTrader.NinjaScript.Indicators.EngBBSoundConverter))] 
		public string SoundFiles
		{get;set;}
		#endregion
		
		#endregion
		
	}
	
	#region Sound Converter	
		public class EngBBSoundConverter : TypeConverter
	{
		
		public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			if (context == null)
			{
				return null;
			}
			//List <string> list;
			List <string> list = new List <string> ();
			
			
			DirectoryInfo dir = new DirectoryInfo(NinjaTrader.Core.Globals.InstallDir+@"\sounds\");
			
			FileInfo[] files= dir.GetFiles("*.wav");
			
			foreach (FileInfo file in files)
			{
				list.Add(file.Name);
			}
				
			
			return new TypeConverter.StandardValuesCollection(list);
		}
		
	

		public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
		{
			return true;
		}
	}
#endregion
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private EngulfingBarsBB[] cacheEngulfingBarsBB;
		public EngulfingBarsBB EngulfingBarsBB(int bBPeriod, double bBStdDev, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles)
		{
			return EngulfingBarsBB(Input, bBPeriod, bBStdDev, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles);
		}

		public EngulfingBarsBB EngulfingBarsBB(ISeries<double> input, int bBPeriod, double bBStdDev, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles)
		{
			if (cacheEngulfingBarsBB != null)
				for (int idx = 0; idx < cacheEngulfingBarsBB.Length; idx++)
					if (cacheEngulfingBarsBB[idx] != null && cacheEngulfingBarsBB[idx].BBPeriod == bBPeriod && cacheEngulfingBarsBB[idx].BBStdDev == bBStdDev && cacheEngulfingBarsBB[idx].Offset == offset && cacheEngulfingBarsBB[idx].MinTick == minTick && cacheEngulfingBarsBB[idx].LineStyle == lineStyle && cacheEngulfingBarsBB[idx].LineColor1 == lineColor1 && cacheEngulfingBarsBB[idx].LineColor2 == lineColor2 && cacheEngulfingBarsBB[idx].LineWidth1 == lineWidth1 && cacheEngulfingBarsBB[idx].LineWidth2 == lineWidth2 && cacheEngulfingBarsBB[idx].RayLength == rayLength && cacheEngulfingBarsBB[idx].SoundFiles == soundFiles && cacheEngulfingBarsBB[idx].EqualsInput(input))
						return cacheEngulfingBarsBB[idx];
			return CacheIndicator<EngulfingBarsBB>(new EngulfingBarsBB(){ BBPeriod = bBPeriod, BBStdDev = bBStdDev, Offset = offset, MinTick = minTick, LineStyle = lineStyle, LineColor1 = lineColor1, LineColor2 = lineColor2, LineWidth1 = lineWidth1, LineWidth2 = lineWidth2, RayLength = rayLength, SoundFiles = soundFiles }, input, ref cacheEngulfingBarsBB);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.EngulfingBarsBB EngulfingBarsBB(int bBPeriod, double bBStdDev, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles)
		{
			return indicator.EngulfingBarsBB(Input, bBPeriod, bBStdDev, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles);
		}

		public Indicators.EngulfingBarsBB EngulfingBarsBB(ISeries<double> input , int bBPeriod, double bBStdDev, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles)
		{
			return indicator.EngulfingBarsBB(input, bBPeriod, bBStdDev, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.EngulfingBarsBB EngulfingBarsBB(int bBPeriod, double bBStdDev, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles)
		{
			return indicator.EngulfingBarsBB(Input, bBPeriod, bBStdDev, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles);
		}

		public Indicators.EngulfingBarsBB EngulfingBarsBB(ISeries<double> input , int bBPeriod, double bBStdDev, int offset, int minTick, DashStyleHelper lineStyle, Brush lineColor1, Brush lineColor2, int lineWidth1, int lineWidth2, int rayLength, string soundFiles)
		{
			return indicator.EngulfingBarsBB(input, bBPeriod, bBStdDev, offset, minTick, lineStyle, lineColor1, lineColor2, lineWidth1, lineWidth2, rayLength, soundFiles);
		}
	}
}

#endregion
