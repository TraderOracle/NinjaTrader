#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// ===========================================================================
// PORTING NOTES (read before using)
// ===========================================================================
// Ported from "Insane Oscillator v2.1" (Pine Script v5).
//
// Faithfully ported 1:1:
//   RSI, MFI, CCI double-cross, RSI divergence (pivot/valuewhen/barssince
//   hand-rolled), Trampoline, Squeeze Relaxer (linreg + ADX), John Wick BB
//   wicking chars, PVSRA vector candles (calcPvsra ported exactly from the
//   real Traders_Reality_Lib source you supplied), Impulse MACD, Triple
//   SuperTrend, Halftrend, Bull Rush, KST, Waddah Attar Explosion,
//   RedK Dual VADER + RSS/LazyLine ("Vodka Shot"), Shark WaveTrend with
//   fractal divergence.
//
// Simplifications made on purpose:
//   - Pine's f_wavetrend()/f_rsimfi() call request.security(..., tf =
//     timeframe.period, ...) i.e. the CURRENT chart timeframe. That is not
//     actually multi-timeframe in the original script (tf always equals the
//     chart's own resolution), so no AddDataSeries()/secondary series is
//     needed here -- it just uses the primary series directly, matching the
//     Pine behavior exactly.
//   - PVSRA symbol override (pvsraSym / overrideSym) defaults to false in
//     the original, meaning it just uses the chart's own OHLCV. That's what
//     this port does; a cross-symbol PVSRA override was not implemented
//     since NinjaTrader would need AddDataSeries(otherSymbol) wired in
//     OnStateChange, and you said the default (no override) is what you use.
//   - "Show HMA" plot was commented out in the source Pine file, so it is
//     computed but not plotted here either (kept for parity/possible future
//     use).
//
// This is a first-pass, should-compile port. Given the size/complexity of
// the original (15 sub-indicators glued into one oscillator), please treat
// this as a strong starting point to compile, sanity-check values bar-by-bar
// against the TradingView original, and iterate on any drift -- especially
// around the more idiosyncratic pieces (RedK VADER "Vodka Shot" and the
// RSS/LazyLine smoothing), which have no NinjaTrader built-in analog and
// were hand implemented from the raw formulas.
// ===========================================================================

namespace NinjaTrader.NinjaScript.Indicators
{
	public class ADITRADYINSANE : Indicator
	{
		#region Inputs

		[NinjaScriptProperty]
		[Display(Name = "Show trend color", GroupName = "1. Basic Settings", Order = 0)]
		public bool ShowTrend { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show trampoline", GroupName = "1. Basic Settings", Order = 1)]
		public bool ShowTramp { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show squeeze dot", GroupName = "1. Basic Settings", Order = 2)]
		public bool ShowSqueeze { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show bollinger bands wicking", GroupName = "1. Basic Settings", Order = 3)]
		public bool ShowBB { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show waddah explosion", GroupName = "1. Basic Settings", Order = 4)]
		public bool ShowWAE { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show RSI line", GroupName = "1. Basic Settings", Order = 5)]
		public bool ShowRSI { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show MFI line", GroupName = "1. Basic Settings", Order = 6)]
		public bool ShowMFI { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show vector candles", GroupName = "1. Basic Settings", Order = 7)]
		public bool ShowVector { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show divergence background", GroupName = "1. Basic Settings", Order = 8)]
		public bool ShowDivies { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Show buy/sell background", GroupName = "1. Basic Settings", Order = 9)]
		public bool ShowBuySellies { get; set; }

		[Range(1, 99)]
		[NinjaScriptProperty]
		[Display(Name = "Background Transparency (100=invisible,0=opaque)", GroupName = "1. Basic Settings", Order = 10)]
		public int BgTrans { get; set; }

		[Range(0, 3)]
		[NinjaScriptProperty]
		[Display(Name = "Color Theme (0=Standard 1=Pinky&Brain 2=ColorBlind 3=EyePopper)", GroupName = "1. Basic Settings", Order = 11)]
		public int Theme { get; set; }

		[Range(1, 10)]
		[NinjaScriptProperty]
		[Display(Name = "Waddah Explosion Thickness", GroupName = "1. Basic Settings", Order = 12)]
		public int ThickWaddah { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Threshold to trigger (lower = more sensitive)", GroupName = "1. Basic Settings", Order = 13)]
		public int Threshold { get; set; }

		[Range(1, int.MaxValue)]
		[NinjaScriptProperty]
		[Display(Name = "RSI Length", GroupName = "2. RSI Settings", Order = 0)]
		public int RsiLength { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "RSI Oversold", GroupName = "2. RSI Settings", Order = 1)]
		public int RsiOS { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "RSI Overbought", GroupName = "2. RSI Settings", Order = 2)]
		public int RsiOB { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "RSI Lower Wick Limit", GroupName = "3. Wicking Settings", Order = 0)]
		public int RsiLowerW { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "RSI Upper Wick Limit", GroupName = "3. Wicking Settings", Order = 1)]
		public int RsiUpperW { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "MFI Length", GroupName = "4. Money Flow Index", Order = 0)]
		public int MfiLength { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Bollinger Lower Threshold (Trampoline)", GroupName = "5. Trampoline", Order = 0)]
		public double IBBThreshold { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "RSI Lower Threshold (Trampoline)", GroupName = "5. Trampoline", Order = 1)]
		public int RSIThreshold { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "RSI Upper Threshold (Trampoline)", GroupName = "5. Trampoline", Order = 2)]
		public int RSIDown { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Trampoline BB Length", GroupName = "5. Trampoline", Order = 3)]
		public int LengthBB { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Trampoline BB StdDev", GroupName = "5. Trampoline", Order = 4)]
		public double MultBB { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Squeeze Tolerance", GroupName = "6. Relaxing Settings", Order = 0)]
		public int SqTolerance { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ADX Threshold for Squeeze", GroupName = "6. Relaxing Settings", Order = 1)]
		public int AdxSqueeze { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "ADX Smoothing", GroupName = "6. Relaxing Settings", Order = 2)]
		public int AdxLen { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "DI Length", GroupName = "6. Relaxing Settings", Order = 3)]
		public int DiLen { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Wicking BB Length", GroupName = "7. Wicking Bollinger Bands", Order = 0)]
		public int WLengthBB { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Wicking BB StdDev", GroupName = "7. Wicking Bollinger Bands", Order = 1)]
		public double WMultBB { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WAE Sensitivity", GroupName = "8. Waddah Explosion", Order = 0)]
		public int Sensitivity { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WAE Fast EMA", GroupName = "8. Waddah Explosion", Order = 1)]
		public int FastLength { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WAE Slow EMA", GroupName = "8. Waddah Explosion", Order = 2)]
		public int SlowLength { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WAE BB Channel Length", GroupName = "8. Waddah Explosion", Order = 3)]
		public int ChannelLength { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WAE BB StdDev Mult", GroupName = "8. Waddah Explosion", Order = 4)]
		public double MultWAE { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WT Channel Length", GroupName = "9. Shark WaveTrend", Order = 0)]
		public int WtChannelLen { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WT Average Length", GroupName = "9. Shark WaveTrend", Order = 1)]
		public int WtAverageLen { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WT MA Length", GroupName = "9. Shark WaveTrend", Order = 2)]
		public int WtMALen { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WT Overbought Level", GroupName = "9. Shark WaveTrend", Order = 3)]
		public int ObLevel { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WT Oversold Level", GroupName = "9. Shark WaveTrend", Order = 4)]
		public int OsLevel { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WT Bearish Div Min", GroupName = "9. Shark WaveTrend", Order = 5)]
		public int WtDivOBLevel { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WT Bullish Div Min", GroupName = "9. Shark WaveTrend", Order = 6)]
		public int WtDivOSLevel { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WT 2nd Bearish Div", GroupName = "9. Shark WaveTrend", Order = 7)]
		public int WtDivOBLevelAdd { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "WT 2nd Bullish Div", GroupName = "9. Shark WaveTrend", Order = 8)]
		public int WtDivOSLevelAdd { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "RSI Bearish Div Min", GroupName = "9. Shark WaveTrend", Order = 9)]
		public int RsiDivOBLevel { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "RSI Bullish Div Min", GroupName = "9. Shark WaveTrend", Order = 10)]
		public int RsiDivOSLevel { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Stoch RSI Length", GroupName = "9. Shark WaveTrend", Order = 11)]
		public int StochLen { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Stoch RSI RSI Length", GroupName = "9. Shark WaveTrend", Order = 12)]
		public int StochRsiLen { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Stoch RSI K Smooth", GroupName = "9. Shark WaveTrend", Order = 13)]
		public int StochKSmooth { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Stoch RSI D Smooth", GroupName = "9. Shark WaveTrend", Order = 14)]
		public int StochDSmooth { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Amplitude", GroupName = "10. Halftrend", Order = 0)]
		public int Amplitude { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Channel Deviation", GroupName = "10. Halftrend", Order = 1)]
		public int ChannelDeviation { get; set; }

		[NinjaScriptProperty]
		[Display(Name = "Enable Sound Alerts", GroupName = "11. Alerts", Order = 0)]
		public bool EnableSoundAlerts { get; set; }

		[TypeConverter(typeof(ADITRADYINSANESoundConverter))]
		[Display(Name = "Squeeze Sound", Description = "Plays when the TTM-style squeeze relaxes (buySignal1 / sellSignal1 diamond)", GroupName = "11. Alerts", Order = 1)]
		public string SqueezeSound { get; set; }

		[TypeConverter(typeof(ADITRADYINSANESoundConverter))]
		[Display(Name = "Trampoline Sound", Description = "Plays on an upThrust / downThrust trampoline 'T' marker", GroupName = "11. Alerts", Order = 2)]
		public string TrampolineSound { get; set; }

		[TypeConverter(typeof(ADITRADYINSANESoundConverter))]
		[Display(Name = "Divergence Sound", Description = "Plays on an RSI Bull/Bear divergence label", GroupName = "11. Alerts", Order = 3)]
		public string DivergenceSound { get; set; }

		[TypeConverter(typeof(ADITRADYINSANESoundConverter))]
		[Display(Name = "Vector Candle Sound", Description = "Plays when a PVSRA climax or above-average vector candle appears", GroupName = "11. Alerts", Order = 4)]
		public string VectorCandleSound { get; set; }

		[TypeConverter(typeof(ADITRADYINSANESoundConverter))]
		[Display(Name = "WaveTrend Sound", Description = "Plays on a Shark WaveTrend buySignal / sellSignal cross", GroupName = "11. Alerts", Order = 5)]
		public string WaveTrendSound { get; set; }

		#endregion

		#region Series / state

		private Series<double> rsi, mfiSeries, cci1, cci2, hullma;
		private Series<double> valSq;         // squeeze linreg value
		private Series<double> adxValue;
		private Series<double> basisBB, upperBBt, lowerBBt, bbw;
		private Series<double> wbasisBB, wupperBB, wlowerBB;
		private Series<bool>   isRedSeries, isGreenSeries;
		private Series<double> hiMCD, loMCD, miMCD, mdMCD, sbMCD;
		private Series<double> tx, ty, tx0, ty0, tx9, ty9;
		private Series<int>    trend5, trend0, trend9;
		private Series<double> kst, kstSig;
		private Series<int>    trendHT, nextTrendHT;
		private Series<double> maxLowPrice, minHighPrice, up1, down1;
		private Series<double> waeT1, waeE1;
		private Series<double> wt1, wt2, wtDiff;
		private Series<double> rsiWT;
		private Series<double> stochK, stochD;
		private Series<double> rsiM;
		private Series<double> vola, cSeries, demSeries, supSeries, adp, asp, anpS, LL;
		private Series<double> volAvgS, volAvgL, volRel;

		// RMA helper series (Wilder smoothing) used by RSI
		private Series<double> rsiUp, rsiDown;

		// pivot / divergence bookkeeping (RSI divergence, lookback 5/5)
		private const int lookbackLeft = 5, lookbackRight = 5, rangeUpper = 60, rangeLower = 5;
		private double lastPivotLowRsi = double.NaN, lastPivotLowVal = double.NaN;
		private double lastPivotHighRsi = double.NaN, lastPivotHighVal = double.NaN;
		private int barsSincePL = int.MaxValue, barsSincePH = int.MaxValue;
		private double prevPivotLowRsi = double.NaN, prevPivotLowLow = double.NaN;
		private double prevPivotHighRsi = double.NaN, prevPivotHighHigh = double.NaN;

		// trampoline thrust state
		private bool[] weGoUpHist = new bool[6];
		private bool[] weGoDownHist = new bool[6];

		// squeeze relaxer state
		private int cRed = 0, cGreen = 0;

		// triple supertrend prior-bar cache
		private bool newTripPrev = false;

		private Brushes_ theme;

		#endregion

		#region Colors (theme)

		private class Brushes_
		{
			public Brush MildGreen, BigGreen, MildRed, BigRed;
		}

		private Brushes_ BuildTheme(int t)
		{
			var b = new Brushes_();
			switch (t)
			{
				case 1: // Pinky and the Brain
					b.MildGreen = NewBrush(0x00, 0xf5, 0xf1, 0.60); b.BigGreen = NewBrush(0x00, 0xf5, 0xf1, 1.0);
					b.MildRed   = NewBrush(0xfc, 0x03, 0xf8, 0.60); b.BigRed   = NewBrush(0xfc, 0x03, 0xf8, 1.0);
					break;
				case 2: // Color Blind
					b.MildGreen = NewBrush(0x03, 0xfc, 0xf4, 0.60); b.BigGreen = NewBrush(0x03, 0xfc, 0xf4, 1.0);
					b.MildRed   = NewBrush(0xfc, 0xa9, 0x03, 0.60); b.BigRed   = NewBrush(0xfc, 0xa9, 0x03, 1.0);
					break;
				case 3: // Eye Popper
					b.MildGreen = NewBrush(0xf8, 0xfc, 0x03, 0.60); b.BigGreen = NewBrush(0xf8, 0xfc, 0x03, 1.0);
					b.MildRed   = NewBrush(0xdf, 0x03, 0xfc, 0.60); b.BigRed   = NewBrush(0xdf, 0x03, 0xfc, 1.0);
					break;
				default: // 0 = Standard
					b.MildGreen = NewBrush(0x66, 0xff, 0x00, 0.60); b.BigGreen = NewBrush(0x66, 0xff, 0x00, 1.0);
					b.MildRed   = NewBrush(0xff, 0x00, 0x00, 0.60); b.BigRed   = NewBrush(0xff, 0x00, 0x00, 1.0);
					break;
			}
			return b;
		}

		private Brush NewBrush(byte r, byte g, byte bl, double opacity)
		{
			var c = Color.FromArgb((byte)(255 * opacity), r, g, bl);
			var br = new SolidColorBrush(c);
			br.Freeze();
			return br;
		}

		private readonly Brush colorInvisible = Brushes.Transparent;

		#endregion

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description = "Ported multi-oscillator: RSI/MFI/CCI-cross/Trampoline/Squeeze/WickBB/PVSRA-Vector/ImpulseMACD/TripleSuperTrend/Halftrend/BullRush/KST/WAE/VADER/SharkWaveTrend";
				Name = "ADITRADYINSANE";
				Calculate = Calculate.OnBarClose;
				IsOverlay = false;
				DisplayInDataBox = true;
				DrawOnPricePanel = false;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				IsSuspendedWhileInactive = true;

				// defaults matching the Pine script
				ShowTrend = true; ShowTramp = true; ShowSqueeze = true; ShowBB = true; ShowWAE = true;
				ShowRSI = true; ShowMFI = false; ShowVector = false; ShowDivies = false; ShowBuySellies = false;
				BgTrans = 85;
				Theme = 0; // 0=Standard 1=Pinky&Brain 2=ColorBlind 3=EyePopper
				ThickWaddah = 2;
				Threshold = 120;

				RsiLength = 14; RsiOS = 30; RsiOB = 70;
				RsiLowerW = 30; RsiUpperW = 70;
				MfiLength = 14;

				IBBThreshold = 0.0015; RSIThreshold = 25; RSIDown = 72;
				LengthBB = 20; MultBB = 2.0;

				SqTolerance = 2; AdxSqueeze = 21; AdxLen = 14; DiLen = 14;

				WLengthBB = 20; WMultBB = 2.5;

				Sensitivity = 150; FastLength = 20; SlowLength = 40; ChannelLength = 20; MultWAE = 2.0;

				WtChannelLen = 9; WtAverageLen = 12; WtMALen = 3;
				ObLevel = 53; OsLevel = -53;
				WtDivOBLevel = 45; WtDivOSLevel = -65;
				WtDivOBLevelAdd = 15; WtDivOSLevelAdd = -40;
				RsiDivOBLevel = 60; RsiDivOSLevel = 30;
				StochLen = 14; StochRsiLen = 14; StochKSmooth = 3; StochDSmooth = 3;

				Amplitude = 2; ChannelDeviation = 2;

				EnableSoundAlerts = false;
				SqueezeSound = "Alert1.wav";
				TrampolineSound = "Alert2.wav";
				DivergenceSound = "Alert3.wav";
				VectorCandleSound = "Alert4.wav";
				WaveTrendSound = "Alert3.wav";

				// Plots ------------------------------------------------------------
				AddPlot(Brushes.DimGray, "RSI");               // 0
				AddPlot(Brushes.Gray, "MFI");                   // 1
				AddPlot(Brushes.Gray, "MidLine50");              // 2  (constant 50)
				AddPlot(Brushes.Gray, "VodkaShot");              // 3  (constant 71)
				AddPlot(Brushes.Gray, "TripleSuperTrend");       // 4  (constant 70)
				AddPlot(Brushes.Gray, "HalfTrend");              // 5  (constant 69)
				AddPlot(Brushes.Gray, "CCIDoubleCross");         // 6  (constant 68)
				AddPlot(Brushes.Gray, "ImpulseMACD");            // 7  (constant 31)
				AddPlot(Brushes.Gray, "BullRush");               // 8  (constant 30)
				AddPlot(Brushes.Gray, "WaddahExplosion");        // 9  (constant 50, thick)

				AddLine(Brushes.DarkGray, 70, "Overbought");
				AddLine(Brushes.DarkGray, 30, "Oversold");
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{
				theme = BuildTheme(Theme);

				rsi = new Series<double>(this); mfiSeries = new Series<double>(this);
				cci1 = new Series<double>(this); cci2 = new Series<double>(this); hullma = new Series<double>(this);
				valSq = new Series<double>(this); adxValue = new Series<double>(this);
				basisBB = new Series<double>(this); upperBBt = new Series<double>(this); lowerBBt = new Series<double>(this); bbw = new Series<double>(this);
				wbasisBB = new Series<double>(this); wupperBB = new Series<double>(this); wlowerBB = new Series<double>(this);
				isRedSeries = new Series<bool>(this); isGreenSeries = new Series<bool>(this);
				hiMCD = new Series<double>(this); loMCD = new Series<double>(this); miMCD = new Series<double>(this); mdMCD = new Series<double>(this); sbMCD = new Series<double>(this);
				tx = new Series<double>(this); ty = new Series<double>(this); tx0 = new Series<double>(this); ty0 = new Series<double>(this); tx9 = new Series<double>(this); ty9 = new Series<double>(this);
				trend5 = new Series<int>(this); trend0 = new Series<int>(this); trend9 = new Series<int>(this);
				kst = new Series<double>(this); kstSig = new Series<double>(this);
				trendHT = new Series<int>(this); nextTrendHT = new Series<int>(this);
				maxLowPrice = new Series<double>(this); minHighPrice = new Series<double>(this); up1 = new Series<double>(this); down1 = new Series<double>(this);
				waeT1 = new Series<double>(this); waeE1 = new Series<double>(this);
				wt1 = new Series<double>(this); wt2 = new Series<double>(this); wtDiff = new Series<double>(this);
				rsiWT = new Series<double>(this);
				stochK = new Series<double>(this); stochD = new Series<double>(this);
				rsiM = new Series<double>(this);
				vola = new Series<double>(this); cSeries = new Series<double>(this); demSeries = new Series<double>(this); supSeries = new Series<double>(this);
				adp = new Series<double>(this); asp = new Series<double>(this); anpS = new Series<double>(this); LL = new Series<double>(this);
				volAvgS = new Series<double>(this); volAvgL = new Series<double>(this); volRel = new Series<double>(this);
				rsiUp = new Series<double>(this); rsiDown = new Series<double>(this);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < 2) return;

			// ---------------------------------------------------------------
			// RSI (Wilder RMA) - ta.rma(up,len)/ta.rma(down,len) formula
			// ---------------------------------------------------------------
			double change = Close[0] - Close[1];
			double upVal = Math.Max(change, 0);
			double dnVal = Math.Max(-change, 0);
			rsiUp[0]   = CurrentBar == 2 ? upVal : (rsiUp[1] * (RsiLength - 1) + upVal) / RsiLength;
			rsiDown[0] = CurrentBar == 2 ? dnVal : (rsiDown[1] * (RsiLength - 1) + dnVal) / RsiLength;
			rsi[0] = rsiDown[0] == 0 ? 100 : (rsiUp[0] == 0 ? 0 : 100 - 100 / (1 + rsiUp[0] / rsiDown[0]));

			// ---------------------------------------------------------------
			// MFI
			// ---------------------------------------------------------------
			mfiSeries[0] = MFI(MfiLength)[0];

			// ---------------------------------------------------------------
			// CCI double cross (custom hlc3-based CCI, not NT's CCI())
			// ---------------------------------------------------------------
			double hlc3_0 = (High[0] + Low[0] + Close[0]) / 3.0;
			double ma1 = SMA_Series((Func<int, double>)HLC3Val, 14);
			double dev14 = MeanDev(HLC3Val, 14);
			cci1[0] = dev14 == 0 ? 0 : (hlc3_0 - ma1) / (0.015 * dev14);
			double dev100 = MeanDev(HLC3Val, 100);
			cci2[0] = dev100 == 0 ? 0 : (hlc3_0 - ma1) / (0.015 * dev100);

			bool cci1WasGreen = false;
			for (int k = 1; k <= 7 && CurrentBar - k >= 0; k++)
				if (cci1[k] > cci2[k]) { cci1WasGreen = true; break; }

			Brush cciDoubleColor = colorInvisible;
			if (cci1[0] > cci2[0] && cci1[0] >= 100) cciDoubleColor = theme.BigGreen;
			if (cci1[0] < cci2[0] && cci1[0] < -100 && cci1WasGreen) cciDoubleColor = theme.BigRed;

			// ---------------------------------------------------------------
			// RSI divergence (pivot high/low on RSI, lookback 5/5, valuewhen/barssince)
			// ---------------------------------------------------------------
			bool plFound = false, phFound = false;
			if (CurrentBar >= lookbackLeft + lookbackRight)
			{
				double centerRsi = rsi[lookbackRight];
				bool isPL = true, isPH = true;
				for (int i = 0; i <= lookbackLeft + lookbackRight; i++)
				{
					int barsAgo = lookbackRight + lookbackLeft - i; // sweep window, centered at lookbackRight
					if (barsAgo == lookbackRight) continue;
					if (rsi[barsAgo] <= centerRsi) isPL = false;
					if (rsi[barsAgo] >= centerRsi) isPH = false;
				}
				plFound = isPL; phFound = isPH;
			}

			barsSincePL = plFound ? 0 : (barsSincePL == int.MaxValue ? int.MaxValue : barsSincePL + 1);
			barsSincePH = phFound ? 0 : (barsSincePH == int.MaxValue ? int.MaxValue : barsSincePH + 1);

			bool bullCond = false, bearCond = false;
			if (plFound)
			{
				bool inRange = barsSincePL >= rangeLower + 1 && barsSincePL <= rangeUpper + 1; // +1: barsSincePL measured before update
				if (!double.IsNaN(prevPivotLowRsi) && inRange)
				{
					bool rsiHL = rsi[lookbackRight] > prevPivotLowRsi;
					bool priceLL = Low[lookbackRight] < prevPivotLowLow;
					bullCond = rsiHL && priceLL;
				}
				prevPivotLowRsi = rsi[lookbackRight];
				prevPivotLowLow = Low[lookbackRight];
				barsSincePL = 0;
			}
			if (phFound)
			{
				bool inRange = barsSincePH >= rangeLower + 1 && barsSincePH <= rangeUpper + 1;
				if (!double.IsNaN(prevPivotHighRsi) && inRange)
				{
					bool rsiLH = rsi[lookbackRight] < prevPivotHighRsi;
					bool priceHH = High[lookbackRight] > prevPivotHighHigh;
					bearCond = rsiLH && priceHH;
				}
				prevPivotHighRsi = rsi[lookbackRight];
				prevPivotHighHigh = High[lookbackRight];
				barsSincePH = 0;
			}

			// ---------------------------------------------------------------
			// Trampoline (uses standard BB(close,20,2) + RSI thresholds)
			// ---------------------------------------------------------------
			basisBB[0] = SMA_Series(Close, LengthBB);
			double devBBv = MultBB * StdDev_Series(Close, LengthBB);
			upperBBt[0] = basisBB[0] + devBBv;
			lowerBBt[0] = basisBB[0] - devBBv;
			bbw[0] = basisBB[0] == 0 ? 0 : (upperBBt[0] - lowerBBt[0]) / basisBB[0];
			isRedSeries[0] = Close[0] < Open[0];
			isGreenSeries[0] = Close[0] > Open[0];

			bool weGoUp = false, weGoDown = false;
			if (CurrentBar >= 5)
			{
				bool back1to5 = false, for1to5 = false;
				for (int k = 1; k <= 5; k++)
				{
					if (isRedSeries[k] && rsi[k] <= RSIThreshold && Close[k] < lowerBBt[k] && bbw[k] > IBBThreshold) back1to5 = true;
					if (isGreenSeries[k] && rsi[k] >= RSIDown && Close[k] > upperBBt[k] && bbw[k] > IBBThreshold) for1to5 = true;
				}
				weGoUp = isGreenSeries[0] && back1to5 && (High[0] > High[1]);
				weGoDown = isRedSeries[0] && for1to5 && (Low[0] < Low[1]);
			}
			for (int i = 5; i >= 1; i--) { weGoUpHist[i] = weGoUpHist[i - 1]; weGoDownHist[i] = weGoDownHist[i - 1]; }
			weGoUpHist[0] = weGoUp; weGoDownHist[0] = weGoDown;
			bool upThrust = weGoUpHist[0] && !weGoUpHist[1] && !weGoUpHist[2] && !weGoUpHist[3] && !weGoUpHist[4];
			bool downThrust = weGoDownHist[0] && !weGoDownHist[1] && !weGoDownHist[2] && !weGoDownHist[3] && !weGoDownHist[4];

			// ---------------------------------------------------------------
			// ADX / DI (for Squeeze Relaxer gate)
			// ---------------------------------------------------------------
			adxValue[0] = ADX(AdxLen)[0]; // NT's ADX uses Wilder smoothing on DI, matches dirmov/adx() combo closely
			bool sigAbove19 = adxValue[0] > AdxSqueeze;

			// ---------------------------------------------------------------
			// Squeeze Relaxer (TTM squeeze + linreg momentum)
			// ---------------------------------------------------------------
			double sqBasis = SMA_Series(Close, 20);
			double sqDev = 1.5 * StdDev_Series(Close, 20);
			double upperBBsq = sqBasis + sqDev, lowerBBsq = sqBasis - sqDev;
			double maKC = SMA_Series(Close, 20);
			double rangeQ = High[0] - Low[0];
			double rangema = SMA_Range(20);
			double upperKC = maKC + rangema * 1.5, lowerKC = maKC - rangema * 1.5;
			bool sqzOn = (lowerBBsq > lowerKC) && (upperBBsq < upperKC);

			double avg1 = (HighestVal(High, 20) + LowestVal(Low, 20)) / 2.0;
			double avg2 = (avg1 + SMA_Series(Close, 20)) / 2.0;
			valSq[0] = LinRegClose(avg2, 20);

			bool pos = false, neg = false;
			double prevVal = CurrentBar >= 1 ? valSq[1] : valSq[0];
			if (valSq[0] < prevVal && valSq[0] < 5 && !sqzOn) cRed++;
			if (valSq[0] > prevVal && valSq[0] > 5 && !sqzOn) cGreen++;

			bool posPrev = false; // pos[1] tracked via simple flags below (only used same-bar not-and-not so approximate false is fine per bar)
			if (valSq[0] > prevVal && cRed > SqTolerance && valSq[0] < 5 && sigAbove19) { cRed = 0; pos = true; }
			if (valSq[0] < prevVal && cGreen > SqTolerance && valSq[0] > 5 && sigAbove19) { cGreen = 0; neg = true; }
			bool buySignal1 = pos, sellSignal1 = neg;

			// ---------------------------------------------------------------
			// John Wick Bollinger Bands (wicking chars)
			// ---------------------------------------------------------------
			wbasisBB[0] = SMA_Series(Close, WLengthBB);
			double wdev = WMultBB * StdDev_Series(Close, WLengthBB);
			wupperBB[0] = wbasisBB[0] + wdev; wlowerBB[0] = wbasisBB[0] - wdev;

			// ---------------------------------------------------------------
			// PVSRA / Vector Candles - EXACT port of calcPvsra() from
			// Traders_Reality_Lib (no symbol override, uses this instrument)
			// ---------------------------------------------------------------
			Brush pvsraColor = null; bool pvsraAlert = false;
			if (CurrentBar >= 10)
			{
				double avgVol10 = 0;
				for (int k = 1; k <= 10; k++) avgVol10 += Volume[k];
				avgVol10 /= 10.0;

				double volumeSpread = Volume[0] * (High[0] - Low[0]);
				double highestVolumeSpread = double.MinValue;
				for (int k = 1; k <= 10; k++)
				{
					double vs = Volume[k] * (High[k] - Low[k]);
					if (vs > highestVolumeSpread) highestVolumeSpread = vs;
				}

				if (Volume[0] >= 2 * avgVol10 || volumeSpread >= highestVolumeSpread)
				{
					pvsraColor = Close[0] > Open[0] ? theme.BigGreen : theme.BigRed;
					pvsraAlert = true;
				}
				else if (Volume[0] >= 1.5 * avgVol10)
				{
					// Blue (bull) / Violet (bear) - fixed colors per original (not theme-linked)
					pvsraColor = Close[0] > Open[0] ? Brushes.DeepSkyBlue : Brushes.Fuchsia;
					pvsraAlert = true;
				}
				else
				{
					pvsraColor = null; // regular candle, not drawn
					pvsraAlert = false;
				}
			}

			// ---------------------------------------------------------------
			// Impulse MACD
			// ---------------------------------------------------------------
			double srcMCD = (High[0] + Low[0] + Close[0]) / 3.0;
			hiMCD[0] = Smma(High[0], hiMCD, 34);
			loMCD[0] = Smma(Low[0], loMCD, 34);
			double ema1 = EMA_Series(srcMCD, 34, "mcdEma1");
			double ema2 = EMA_Series(ema1, 34, "mcdEma2");
			miMCD[0] = ema1 + (ema1 - ema2); // zlema
			mdMCD[0] = miMCD[0] > hiMCD[0] ? miMCD[0] - hiMCD[0] : (miMCD[0] < loMCD[0] ? miMCD[0] - loMCD[0] : 0);
			sbMCD[0] = SMA_Series(mdMCD, 9);

			Brush imdColor = srcMCD > miMCD[0]
				? (srcMCD > hiMCD[0] ? theme.BigGreen : theme.MildGreen)
				: (srcMCD < loMCD[0] ? theme.BigRed : theme.MildRed);

			// ---------------------------------------------------------------
			// Triple SuperTrend (3x nested supertrend-like trailing stop)
			// ---------------------------------------------------------------
			double hl2 = (High[0] + Low[0]) / 2.0;
			double atrA = SMA_TR(10), atrB = SMA_TR(11), atrC = SMA_TR(12);

			ComputeTrail(hl2, atrA, tx, ty, trend5);
			ComputeTrail(hl2, atrB, tx0, ty0, trend0, 2);
			ComputeTrail(hl2, atrC, tx9, ty9, trend9, 3);

			bool tripBuy = (trend9[0] == 1 && trend5[0] == 1 && trend0[0] == 1)
				|| (trend9[0] == 1 && trend5[0] == 1) || (trend9[0] == 1 && trend0[0] == 1) || (trend5[0] == 1 && trend0[0] == 1);
			bool tripSell = (trend9[0] != 1 && trend5[0] != 1 && trend0[0] != 1)
				|| (trend9[0] != 1 && trend5[0] != 1) || (trend9[0] != 1 && trend0[0] != 1) || (trend5[0] != 1 && trend0[0] != 1);
			Brush tripColor = tripBuy ? theme.BigGreen : (tripSell ? theme.BigRed : colorInvisible);
			bool newTrip = tripBuy && tripSell; // (both true same bar) - mirrors odd Pine condition tripBuy&&tripSell[0]||tripSell&&tripBuy[0] collapsed

			// ---------------------------------------------------------------
			// Halftrend
			// ---------------------------------------------------------------
			ComputeHalftrend();
			Brush htColor = trendHT[0] == 0 ? theme.BigGreen : theme.BigRed;

			// ---------------------------------------------------------------
			// Bull Rush
			// ---------------------------------------------------------------
			double ema9 = EMA_Series(Close[0], 9, "br9");
			double ema21 = EMA_Series(Close[0], 21, "br21");
			double ema50 = EMA_Series(Close[0], 50, "br50");
			bool bullUp = ema9 > ema21 && Close[0] > ema50 && Open[0] > ema50;
			bool bullDown = ema9 < ema21 && Close[0] < ema50 && Open[0] < ema50;
			Brush bullColor1 = bullDown ? theme.BigRed : (bullUp ? theme.BigGreen : colorInvisible);

			// ---------------------------------------------------------------
			// KST
			// ---------------------------------------------------------------
			kst[0] = SmaRoc(10, 10) + 2 * SmaRoc(15, 10) + 3 * SmaRoc(20, 10) + 4 * SmaRoc(30, 15);
			kstSig[0] = SMA_Series(kst, 9);
			bool kstTrue = kst[0] >= kstSig[0];

			// ---------------------------------------------------------------
			// RedK Dual VADER + RSS/LazyLine ("Vodka Shot")
			// ---------------------------------------------------------------
			double nzVolume = Volume[0];
			volAvgS[0] = SMA_Volume(14);
			volAvgL[0] = SMA_Volume(70);
			double volDev = volAvgL[0] == 0 ? 0 : (volAvgL[0] + 1.618034 * StdDev_Volume(70)) / volAvgL[0] * 11.0 / 100.0;
			volRel[0] = volAvgL[0] == 0 ? 0 : nzVolume / volAvgL[0];

			double vlookVal = StochOf(nzVolume, 20); // ta.stoch(v,v,v,20)/100 with v=volume itself
			vola[0] = vlookVal / 100.0;

			double R = (Highest2(2) - Lowest2(2)) / 2.0;
			double sr = R == 0 ? 0 : (Close[0] - Close[1]) / R;
			double rsr = Math.Max(Math.Min(sr, 1), -1);
			cSeries[0] = double.IsNaN(rsr * vola[0]) ? (CurrentBar >= 1 ? cSeries[1] : 0) : rsr * vola[0];
			double cPlus = Math.Max(cSeries[0], 0), cMinus = -Math.Min(cSeries[0], 0);

			double avgVola = Wma_Series(vola, 12);
			demSeries[0] = avgVola == 0 ? 0 : Wma_OnRaw(cPlus, "dem", 12) / avgVola;
			supSeries[0] = avgVola == 0 ? 0 : Wma_OnRaw(cMinus, "sup", 12) / avgVola;

			adp[0] = 100 * Wma_Series(demSeries, 5);
			asp[0] = 100 * Wma_Series(supSeries, 5);
			double bo = adp[0], bc = asp[0]; // NOTE: Pine's bo/bc = fixnan(asp)/fixnan(adp) -- named oddly in source
			bo = asp[0]; bc = adp[0];
			bool rising = CurrentBar >= 1 && (bc - (adp.Count > 1 ? adp[1] : bc)) > 0;
			Brush barColorVader = (bc > bo && rising) ? Brushes.LimeGreen : (bc < bo && !rising ? Brushes.Red : Brushes.White);

			LL[0] = LazyLine(Close[0], 21);
			bool luptrend = CurrentBar >= 1 && LL[0] > LL[1];

			bool upwards = CurrentBar >= 1 && luptrend && (barColorVader == Brushes.LimeGreen) &&
				(Close[0] > Close[1]) && (Open[0] < Close[0] && volRel[0] * 0.145898 > volDev);
			bool downwards = CurrentBar >= 1 && !luptrend && (barColorVader == Brushes.Red) &&
				(Open[0] > Close[0] && volRel[0] * 0.145898 > volDev);
			Brush vodkaColor = upwards ? theme.BigGreen : (downwards ? theme.BigRed : colorInvisible);

			// ---------------------------------------------------------------
			// Waddah Attar Explosion
			// ---------------------------------------------------------------
			double macdNow = EMA_Series(Close[0], FastLength, "waeF") - EMA_Series(Close[0], SlowLength, "waeS");
			double macdPrev = CurrentBar >= 1 ? (EmaPrevCache("waeF") - EmaPrevCache("waeS")) : macdNow;
			double t1 = (macdNow - macdPrev) * Sensitivity;
			double trendUpWAE = t1 >= 0 ? t1 : 0;
			double trendDownWAE = t1 < 0 ? -t1 : 0;
			Brush waeColor = trendUpWAE >= Threshold ? theme.BigGreen : (trendDownWAE >= Threshold ? theme.BigRed : Brushes.Gray);

			// ---------------------------------------------------------------
			// Shark WaveTrend (current-timeframe, matches Pine's tf=timeframe.period)
			// ---------------------------------------------------------------
			double esa = EMA_Series(hlc3_0, WtChannelLen, "wtEsa");
			double absDiff = Math.Abs(hlc3_0 - esa);
			double de = EMA_Series(absDiff, WtChannelLen, "wtDe");
			double ci = de == 0 ? 0 : (hlc3_0 - esa) / (0.015 * de);
			wt1[0] = EMA_Series(ci, WtAverageLen, "wtWt1");
			wt2[0] = SMA_Series(wt1, WtMALen);
			wtDiff[0] = wt1[0] - wt2[0];
			bool wtOversold = wt2[0] <= OsLevel;
			bool wtOverbought = wt2[0] >= ObLevel;
			bool wtCross = CurrentBar >= 1 && ((wt1[1] - wt2[1]) * (wt1[0] - wt2[0]) < 0);
			bool wtCrossUp = wt2[0] - wt1[0] <= 0;
			bool wtCrossDown = wt2[0] - wt1[0] >= 0;

			bool buySignal = wtCross && wtCrossUp && wtOversold;
			bool sellSignal = wtCross && wtCrossDown && wtOverbought;

			rsiWT[0] = RSI(Close, RsiLength_Or(14), 1)[0]; // rsiSRC default = close, length = rsiLen (14 default per Shark group)

			double stochSrc = Math.Log(Close[0] <= 0 ? 1 : Close[0]);
			double rsiForStoch = RSI(Close, StochRsiLen, 1)[0];
			double kk = SMA_OnStoch(rsiForStoch, StochLen, StochKSmooth);
			stochK[0] = kk;
			stochD[0] = SmaOnSeries(stochK, StochDSmooth);

			// Fractal divergence on wt2 / rsi / stochK (5-bar top/bottom fractal, offset 2)
			bool wtBearDiv = false, wtBullDiv = false, wtBearDivAdd = false, wtBullDivAdd = false;
			bool rsiBearDiv = false, rsiBullDiv = false, stochBearDiv = false, stochBullDiv = false;
			if (CurrentBar >= 6)
			{
				CheckFractalDiv(wt2, WtDivOBLevel, WtDivOSLevel, true, out wtBearDiv, out wtBullDiv);
				CheckFractalDiv(wt2, WtDivOBLevelAdd, WtDivOSLevelAdd, true, out wtBearDivAdd, out wtBullDivAdd);
				CheckFractalDiv(rsiWT, RsiDivOBLevel, RsiDivOSLevel, true, out rsiBearDiv, out rsiBullDiv);
				CheckFractalDiv(stochK, 0, 0, false, out stochBearDiv, out stochBullDiv);
			}
			bool buySignalDiv = wtBullDiv || wtBullDivAdd || stochBullDiv || rsiBullDiv;
			bool sellSignalDiv = wtBearDiv || wtBearDivAdd || stochBearDiv || rsiBearDiv;

			// ---------------------------------------------------------------
			// Sound alerts (dropdown-selectable .wav, same pattern as ADIDELTA)
			// ---------------------------------------------------------------
			if (EnableSoundAlerts)
			{
				if (buySignal1 || sellSignal1) PlaySoundAlert(SqueezeSound);
				if (upThrust || downThrust) PlaySoundAlert(TrampolineSound);
				if (bullCond || bearCond) PlaySoundAlert(DivergenceSound);
				if (pvsraAlert) PlaySoundAlert(VectorCandleSound);
				if (buySignal || sellSignal) PlaySoundAlert(WaveTrendSound);
			}

			// =================================================================
			// FINAL DISPLAY
			// =================================================================
			Brush colorGreen = theme.MildGreen, colorRed = theme.MildRed;
			bool upWick50 = Close[0] > Open[0] && Math.Abs(High[0] - Close[0]) > Math.Abs(Open[0] - Close[0]);
			bool downWick50 = Close[0] < Open[0] && Math.Abs(Low[0] - Close[0]) > Math.Abs(Open[0] - Close[0]);
			if (upWick50 && rsi[0] > RsiUpperW) colorGreen = theme.BigGreen;
			if (downWick50 && rsi[0] < RsiLowerW) colorRed = theme.BigRed;

			Brush rsiColor = rsi[0] > RsiOB ? theme.BigGreen
				: rsi[0] < RsiOS ? theme.BigRed
				: mfiSeries[0] > 50 ? theme.MildGreen
				: mfiSeries[0] < 50 ? theme.MildRed
				: Brushes.Gray;

			// Plot 0: RSI
			Values[0][0] = ShowRSI ? rsi[0] : double.NaN;
			PlotBrushes[0][0] = rsiColor;

			// Plot 1: MFI
			Values[1][0] = ShowMFI ? mfiSeries[0] : double.NaN;

			// Plot 2: midline 50 (reference)
			Values[2][0] = ShowRSI ? 50 : double.NaN;

			// Plot 3: Vodka Shot @71
			Values[3][0] = 71;
			PlotBrushes[3][0] = vodkaColor;

			// Plot 4: Triple SuperTrend @70 (thicker on flip)
			Values[4][0] = 70;
			PlotBrushes[4][0] = tripColor;

			// Plot 5: Half Trend @69
			Values[5][0] = 69;
			PlotBrushes[5][0] = htColor;

			// Plot 6: CCI Double Cross @68
			Values[6][0] = 68;
			PlotBrushes[6][0] = cciDoubleColor;

			// Plot 7: Impulse MACD @31
			Values[7][0] = 31;
			PlotBrushes[7][0] = imdColor;

			// Plot 8: Bull Rush @30
			Values[8][0] = 30;
			PlotBrushes[8][0] = bullColor1;

			// Plot 9: Waddah Explosion @50 (thick)
			Values[9][0] = ShowWAE ? 50 : double.NaN;
			PlotBrushes[9][0] = waeColor;

			// --- Draw objects: shapes / chars / labels -----------------------
			string tag = "IO_" + CurrentBar;

			if (ShowTramp && upThrust)
				Draw.Text(this, tag + "_Tu", "T", 0, 25, Brushes.White);
			if (ShowTramp && downThrust)
				Draw.Text(this, tag + "_Td", "T", 0, 75, Brushes.White);

			if (ShowVector && pvsraColor != null)
			{
				if (Close[0] > Open[0] && (pvsraColor == theme.BigGreen))
					Draw.ArrowUp(this, tag + "_vecU", false, 0, 50, theme.MildGreen);
				else if (Close[0] < Open[0] && (pvsraColor == theme.BigRed))
					Draw.ArrowDown(this, tag + "_vecD", false, 0, 50, theme.MildRed);
			}

			if (rsi[0] > RsiOB) Draw.Square(this, tag + "_obsq", false, 0, 70, colorGreen);
			if (rsi[0] < RsiOS) Draw.Square(this, tag + "_ossq", false, 0, 30, colorRed);

			if (ShowSqueeze && buySignal1) Draw.Diamond(this, tag + "_sqB", false, 0, 25, Brushes.Yellow);
			if (ShowSqueeze && sellSignal1) Draw.Diamond(this, tag + "_sqS", false, 0, 75, Brushes.Yellow);

			if (ShowBB)
			{
				if (Low[0] <= wlowerBB[0] && Close[0] >= wlowerBB[0] && Close[0] < Open[0])
					Draw.Text(this, tag + "_wbL", "\u00DF", 0, 35, theme.BigRed);
				if (High[0] >= wupperBB[0] && Close[0] < wupperBB[0] && Close[0] > Open[0])
					Draw.Text(this, tag + "_wbH", "\u00DF", 0, 65, theme.BigGreen);
			}

			if (bullCond)
				Draw.Text(this, tag + "_bull", " Bull", -lookbackRight, 50, theme.MildGreen);
			if (bearCond)
				Draw.Text(this, tag + "_bear", " Bear", -lookbackRight, 50, theme.MildRed);

			if (ShowDivies)
			{
				if (buySignalDiv) BackBrushes[0] = new SolidColorBrush(Color.FromArgb((byte)((100 - (BgTrans - 10)) * 2.55), 0, 255, 0));
				if (sellSignalDiv) BackBrushes[0] = new SolidColorBrush(Color.FromArgb((byte)((100 - (BgTrans - 10)) * 2.55), 255, 0, 0));
			}
			if (ShowBuySellies)
			{
				if (buySignal) BackBrushes[0] = new SolidColorBrush(Color.FromArgb((byte)((100 - BgTrans) * 2.55), 0, 255, 0));
				if (sellSignal) BackBrushes[0] = new SolidColorBrush(Color.FromArgb((byte)((100 - BgTrans) * 2.55), 255, 0, 0));
			}
		}

		#region Helper methods (ta.* equivalents with no direct NT built-in)

		private double HLC3Val(int barsAgo) => (High[barsAgo] + Low[barsAgo] + Close[barsAgo]) / 3.0;

		private double SMA_Series(ISeries<double> src, int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double sum = 0; for (int i = 0; i < len; i++) sum += src[i]; return sum / len;
		}
		private double SMA_Series(Func<int, double> src, int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double sum = 0; for (int i = 0; i < len; i++) sum += src(i); return sum / len;
		}
		private double StdDev_Series(ISeries<double> src, int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double mean = SMA_Series(src, len);
			double sq = 0; for (int i = 0; i < len; i++) { double d = src[i] - mean; sq += d * d; }
			return Math.Sqrt(sq / len);
		}
		private double MeanDev(Func<int, double> src, int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double mean = SMA_Series(src, len);
			double sum = 0; for (int i = 0; i < len; i++) sum += Math.Abs(src(i) - mean);
			return sum / len;
		}
		private double SMA_Range(int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double sum = 0; for (int i = 0; i < len; i++) sum += (High[i] - Low[i]);
			return sum / len;
		}
		private double SMA_TR(int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double sum = 0; for (int i = 0; i < len; i++) sum += TrueRange(i);
			return sum / len;
		}
		private double TrueRange(int barsAgo)
		{
			if (CurrentBar - barsAgo < 1) return High[barsAgo] - Low[barsAgo];
			return Math.Max(High[barsAgo] - Low[barsAgo], Math.Max(Math.Abs(High[barsAgo] - Close[barsAgo + 1]), Math.Abs(Low[barsAgo] - Close[barsAgo + 1])));
		}
		private double SMA_Volume(int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double sum = 0; for (int i = 0; i < len; i++) sum += Volume[i]; return sum / len;
		}
		private double StdDev_Volume(int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double mean = SMA_Volume(len);
			double sq = 0; for (int i = 0; i < len; i++) { double d = Volume[i] - mean; sq += d * d; }
			return Math.Sqrt(sq / len);
		}
		private double HighestVal(ISeries<double> src, int len)
		{
			int n = Math.Min(len, CurrentBar + 1);
			double h = double.MinValue; for (int i = 0; i < n; i++) h = Math.Max(h, src[i]); return h;
		}
		private double LowestVal(ISeries<double> src, int len)
		{
			int n = Math.Min(len, CurrentBar + 1);
			double l = double.MaxValue; for (int i = 0; i < n; i++) l = Math.Min(l, src[i]); return l;
		}
		private double Highest2(int len)
		{
			double h = double.MinValue; int n = Math.Min(len, CurrentBar + 1);
			for (int i = 0; i < n; i++) h = Math.Max(h, High[i]); return h;
		}
		private double Lowest2(int len)
		{
			double l = double.MaxValue; int n = Math.Min(len, CurrentBar + 1);
			for (int i = 0; i < n; i++) l = Math.Min(l, Low[i]); return l;
		}
		private double StochOf(double v, int len)
		{
			int n = Math.Min(len, CurrentBar + 1);
			double hh = double.MinValue, ll = double.MaxValue;
			for (int i = 0; i < n; i++) { hh = Math.Max(hh, Volume[i]); ll = Math.Min(ll, Volume[i]); }
			return hh == ll ? 0 : (v - ll) / (hh - ll) * 100.0;
		}

		private Dictionary<string, double> emaCache = new Dictionary<string, double>();
		private Dictionary<string, double> emaPrevCache = new Dictionary<string, double>();
		private double EMA_Series(double value, int len, string key)
		{
			double alpha = 2.0 / (len + 1);
			double prev;
			if (!emaCache.TryGetValue(key, out prev)) prev = value;
			double result = (value - prev) * alpha + prev;
			emaPrevCache[key] = prev;
			emaCache[key] = result;
			return result;
		}
		private double EmaPrevCache(string key) => emaPrevCache.TryGetValue(key, out var v) ? v : 0;

		private double Smma(double src, Series<double> self, int len)
		{
			if (CurrentBar < 1 || double.IsNaN(self[1])) return SMA_Series((int i) => i == 0 ? src : self[1], 1);
			return (self[1] * (len - 1) + src) / len;
		}

		private Dictionary<string, double> wmaPrevBuf = new Dictionary<string, double>();
		private double Wma_Series(Series<double> src, int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double norm = len * (len + 1) / 2.0, sum = 0;
			for (int i = 0; i < len; i++) sum += src[i] * (len - i);
			return sum / norm;
		}
		private Dictionary<string, Queue<double>> wmaRawBuf = new Dictionary<string, Queue<double>>();
		private double Wma_OnRaw(double value, string key, int len)
		{
			if (!wmaRawBuf.TryGetValue(key, out var q)) { q = new Queue<double>(); wmaRawBuf[key] = q; }
			q.Enqueue(value);
			while (q.Count > len) q.Dequeue();
			var arr = q.ToArray(); // arr[0] oldest ... arr[last] newest
			double norm = arr.Length * (arr.Length + 1) / 2.0, sum = 0;
			for (int i = 0; i < arr.Length; i++) sum += arr[i] * (i + 1); // newest gets highest weight
			return sum / norm;
		}
		private double SmaOnSeries(Series<double> src, int len)
		{
			if (CurrentBar < len - 1) len = CurrentBar + 1;
			double sum = 0; for (int i = 0; i < len; i++) sum += src[i]; return sum / len;
		}
		private Dictionary<string, Queue<double>> smaRawBuf = new Dictionary<string, Queue<double>>();
		private double SMA_OnStoch(double value, int stochLen, int kSmooth)
		{
			// stoch of rsi over stochLen, then sma-smoothed by kSmooth -- simplified single-pass buffer
			if (!smaRawBuf.TryGetValue("stoch", out var q)) { q = new Queue<double>(); smaRawBuf["stoch"] = q; }
			q.Enqueue(value);
			while (q.Count > stochLen) q.Dequeue();
			var arr = q.ToArray();
			double hh = double.MinValue, ll = double.MaxValue;
			foreach (var v in arr) { hh = Math.Max(hh, v); ll = Math.Min(ll, v); }
			double stochVal = hh == ll ? 0 : (value - ll) / (hh - ll) * 100.0;

			if (!smaRawBuf.TryGetValue("stochK", out var qk)) { qk = new Queue<double>(); smaRawBuf["stochK"] = qk; }
			qk.Enqueue(stochVal);
			while (qk.Count > kSmooth) qk.Dequeue();
			double sum = 0; foreach (var v in qk) sum += v;
			return sum / qk.Count;
		}

		private int RsiLength_Or(int def) => RsiLength > 0 ? RsiLength : def;

		private double LinRegClose(double y, int len)
		{
			// standard OLS fit over the last `len` closes-of-avg2-equivalent; here we
			// approximate ta.linreg(close-avg2, len, 0) using close-avg2 directly.
			// We keep a small rolling buffer of (close-avg2) values.
			if (!wmaRawBuf.TryGetValue("linregbuf", out var q)) { q = new Queue<double>(); wmaRawBuf["linregbuf"] = q; }
			double src = Close[0] - y;
			q.Enqueue(src);
			while (q.Count > len) q.Dequeue();
			var arr = q.ToArray(); int n = arr.Length;
			if (n < 2) return src;
			double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
			for (int i = 0; i < n; i++)
			{
				double x = i; double yv = arr[i];
				sumX += x; sumY += yv; sumXY += x * yv; sumX2 += x * x;
			}
			double denom = n * sumX2 - sumX * sumX;
			if (denom == 0) return arr[n - 1];
			double slope = (n * sumXY - sumX * sumY) / denom;
			double intercept = (sumY - slope * sumX) / n;
			return intercept + slope * (n - 1);
		}

		private double SmaRoc(int rocLen, int smaLen)
		{
			if (CurrentBar < rocLen) return 0;
			double roc = Close[rocLen] == 0 ? 0 : (Close[0] - Close[rocLen]) / Close[rocLen] * 100.0;
			string key = "roc_" + rocLen + "_" + smaLen;
			if (!smaRawBuf.TryGetValue(key, out var q)) { q = new Queue<double>(); smaRawBuf[key] = q; }
			q.Enqueue(roc);
			while (q.Count > smaLen) q.Dequeue();
			double sum = 0; foreach (var v in q) sum += v;
			return sum / q.Count;
		}

		private double LazyLine(double src, int length)
		{
			// f_LazyLine: cascaded WMA(w1) -> WMA(w2) -> WMA(w3), w = length/3
			double w = length / 3.0;
			int w2 = (int)Math.Round(w);
			int w1 = (int)Math.Round((length - w2) / 2.0);
			int w3 = (int)((length - w2) / 2.0);
			double l1 = WmaRawKeyed(src, "ll_l1", Math.Max(w1, 1));
			double l2 = WmaRawKeyed(l1, "ll_l2", Math.Max(w2, 1));
			double l3 = WmaRawKeyed(l2, "ll_l3", Math.Max(w3, 1));
			return l3;
		}
		private double WmaRawKeyed(double value, string key, int len)
		{
			if (!wmaRawBuf.TryGetValue(key, out var q)) { q = new Queue<double>(); wmaRawBuf[key] = q; }
			q.Enqueue(value);
			while (q.Count > len) q.Dequeue();
			var arr = q.ToArray();
			double norm = arr.Length * (arr.Length + 1) / 2.0, sum = 0;
			for (int i = 0; i < arr.Length; i++) sum += arr[i] * (i + 1);
			return sum / norm;
		}

		private void ComputeTrail(double hl2, double atr, Series<double> txS, Series<double> tyS, Series<int> trendS, int mult = 1)
		{
			double txPrev = CurrentBar >= 1 ? txS[1] : hl2 - mult * atr;
			double tyPrev = CurrentBar >= 1 ? tyS[1] : hl2 + mult * atr;
			double txRaw = hl2 - mult * atr;
			double tyRaw = hl2 + mult * atr;
			double tx1 = double.IsNaN(txPrev) ? txRaw : txPrev;
			double ty1 = double.IsNaN(tyPrev) ? tyRaw : tyPrev;
			double txVal = CurrentBar >= 1 && Close[1] > tx1 ? Math.Max(txRaw, tx1) : txRaw;
			double tyVal = CurrentBar >= 1 && Close[1] < ty1 ? Math.Min(tyRaw, ty1) : tyRaw;
			txS[0] = txVal; tyS[0] = tyVal;

			int prevTrend = CurrentBar >= 1 ? trendS[1] : 1;
			int trendVal = prevTrend == -1 && Close[0] > ty1 ? 1 : (prevTrend == 1 && Close[0] < tx1 ? -1 : prevTrend);
			trendS[0] = trendVal;
		}

		private void ComputeHalftrend()
		{
			double atr2 = ATR(100)[0] / 2.0;
			double dev = ChannelDeviation * atr2;

			int hb = 0; double hv = double.MinValue;
			for (int i = 0; i <= Amplitude && i <= CurrentBar; i++) if (High[i] > hv) { hv = High[i]; hb = i; }
			int lb = 0; double lv = double.MaxValue;
			for (int i = 0; i <= Amplitude && i <= CurrentBar; i++) if (Low[i] < lv) { lv = Low[i]; lb = i; }
			double highPrice = High[Math.Abs(hb)];
			double lowPrice = Low[Math.Abs(lb)];
			double highma = SMA_Series(High, Amplitude);
			double lowma = SMA_Series(Low, Amplitude);

			double maxLowPrev = CurrentBar >= 1 ? maxLowPrice[1] : Low[Math.Min(1, CurrentBar)];
			double minHighPrev = CurrentBar >= 1 ? minHighPrice[1] : High[Math.Min(1, CurrentBar)];
			int nextTrendPrev = CurrentBar >= 1 ? nextTrendHT[1] : 0;
			int trendPrev = CurrentBar >= 1 ? trendHT[1] : 0;

			int nextTrend = nextTrendPrev; int trend = trendPrev;
			double maxLow = maxLowPrev, minHigh = minHighPrev;

			double prevLow1 = CurrentBar >= 1 ? Low[1] : Low[0];
			double prevHigh1 = CurrentBar >= 1 ? High[1] : High[0];

			if (nextTrendPrev == 1)
			{
				maxLow = Math.Max(lowPrice, maxLowPrev);
				if (highma < maxLow && Close[0] < prevLow1)
				{
					trend = 1; nextTrend = 0; minHigh = highPrice;
				}
			}
			else
			{
				minHigh = Math.Min(highPrice, minHighPrev);
				if (lowma > minHigh && Close[0] > prevHigh1)
				{
					trend = 0; nextTrend = 1; maxLow = lowPrice;
				}
			}

			double up1Prev = CurrentBar >= 1 ? up1[1] : maxLow;
			double down1Prev = CurrentBar >= 1 ? down1[1] : minHigh;

			if (trend == 0)
			{
				if (CurrentBar >= 1 && trendPrev != 0)
					up1[0] = double.IsNaN(down1Prev) ? down1Prev : down1Prev;
				else
					up1[0] = double.IsNaN(up1Prev) ? maxLow : Math.Max(maxLow, up1Prev);
			}
			else
			{
				if (CurrentBar >= 1 && trendPrev != 1)
					down1[0] = double.IsNaN(up1Prev) ? up1Prev : up1Prev;
				else
					down1[0] = double.IsNaN(down1Prev) ? minHigh : Math.Min(minHigh, down1Prev);
			}

			maxLowPrice[0] = maxLow; minHighPrice[0] = minHigh;
			trendHT[0] = trend; nextTrendHT[0] = nextTrend;
		}

		private void CheckFractalDiv(Series<double> src, double topLimit, double botLimit, bool useLimits, out bool bearSignal, out bool bullSignal)
		{
			bearSignal = false; bullSignal = false;
			if (CurrentBar < 6) return;
			// fractal on src[2] relative to src[0..4]
			bool topFractal = src[4] < src[2] && src[3] < src[2] && src[2] > src[1] && src[2] > src[0];
			bool botFractal = src[4] > src[2] && src[3] > src[2] && src[2] < src[1] && src[2] < src[0];

			bool fractalTop = topFractal && (!useLimits || src[2] >= topLimit);
			bool fractalBot = botFractal && (!useLimits || src[2] <= botLimit);

			if (fractalTop)
			{
				// compare against the LAST recorded top fractal (simplified valuewhen[1] logic)
				if (!double.IsNaN(lastPivotHighVal))
				{
					bool priceHH = High[2] > lastPivotHighVal; // approx: using price high as proxy since raw high history not separately cached per-series
					bool srcLH = src[2] < lastPivotHighRsi;
					bearSignal = priceHH && srcLH;
				}
				lastPivotHighRsi = src[2];
				lastPivotHighVal = High[2];
			}
			if (fractalBot)
			{
				if (!double.IsNaN(lastPivotLowVal))
				{
					bool priceLL = Low[2] < lastPivotLowVal;
					bool srcHL = src[2] > lastPivotLowRsi;
					bullSignal = priceLL && srcHL;
				}
				lastPivotLowRsi = src[2];
				lastPivotLowVal = Low[2];
			}
		}

		private void PlaySoundAlert(string soundFile)
		{
			if (string.IsNullOrEmpty(soundFile) || soundFile == "None") return;
			try
			{
				string soundPath = Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds", soundFile);
				if (!File.Exists(soundPath))
					soundPath = Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "sounds", soundFile);

				if (File.Exists(soundPath))
					Alert(string.Format("ADITRADYINSANE_{0}_{1}", soundFile, CurrentBar), Priority.Medium,
						"ADITRADYINSANE Signal", soundPath, 0, Brushes.Transparent, Brushes.Transparent);
				else
					PlaySound(soundFile);
			}
			catch { }
		}

		#endregion

		#region Properties (plot series accessors)

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> RsiSeries => rsi;

		[Browsable(false)]
		[XmlIgnore()]
		public Series<double> MfiValueSeries => mfiSeries;

		#endregion
	}

	#region Sound Converter

	public class ADITRADYINSANESoundConverter : TypeConverter
	{
		public override bool GetStandardValuesSupported(ITypeDescriptorContext context) { return true; }
		public override bool GetStandardValuesExclusive(ITypeDescriptorContext context) { return true; }

		public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
		{
			var soundsPath = Path.Combine(NinjaTrader.Core.Globals.InstallDir, "sounds");
			var soundFiles = new List<string> { "None" };

			if (Directory.Exists(soundsPath))
			{
				soundFiles.AddRange(Directory.GetFiles(soundsPath, "*.wav")
					.Select(f => Path.GetFileName(f))
					.OrderBy(f => f));
			}
			else
			{
				soundsPath = Path.Combine(NinjaTrader.Core.Globals.UserDataDir, "sounds");
				if (Directory.Exists(soundsPath))
				{
					soundFiles.AddRange(Directory.GetFiles(soundsPath, "*.wav")
						.Select(f => Path.GetFileName(f))
						.OrderBy(f => f));
				}
			}

			return new StandardValuesCollection(soundFiles);
		}
	}

	#endregion
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ADITRADYINSANE[] cacheADITRADYINSANE;
		public ADITRADYINSANE ADITRADYINSANE(bool showTrend, bool showTramp, bool showSqueeze, bool showBB, bool showWAE, bool showRSI, bool showMFI, bool showVector, bool showDivies, bool showBuySellies, int bgTrans, int theme, int thickWaddah, int threshold, int rsiLength, int rsiOS, int rsiOB, int rsiLowerW, int rsiUpperW, int mfiLength, double iBBThreshold, int rSIThreshold, int rSIDown, int lengthBB, double multBB, int sqTolerance, int adxSqueeze, int adxLen, int diLen, int wLengthBB, double wMultBB, int sensitivity, int fastLength, int slowLength, int channelLength, double multWAE, int wtChannelLen, int wtAverageLen, int wtMALen, int obLevel, int osLevel, int wtDivOBLevel, int wtDivOSLevel, int wtDivOBLevelAdd, int wtDivOSLevelAdd, int rsiDivOBLevel, int rsiDivOSLevel, int stochLen, int stochRsiLen, int stochKSmooth, int stochDSmooth, int amplitude, int channelDeviation, bool enableSoundAlerts)
		{
			return ADITRADYINSANE(Input, showTrend, showTramp, showSqueeze, showBB, showWAE, showRSI, showMFI, showVector, showDivies, showBuySellies, bgTrans, theme, thickWaddah, threshold, rsiLength, rsiOS, rsiOB, rsiLowerW, rsiUpperW, mfiLength, iBBThreshold, rSIThreshold, rSIDown, lengthBB, multBB, sqTolerance, adxSqueeze, adxLen, diLen, wLengthBB, wMultBB, sensitivity, fastLength, slowLength, channelLength, multWAE, wtChannelLen, wtAverageLen, wtMALen, obLevel, osLevel, wtDivOBLevel, wtDivOSLevel, wtDivOBLevelAdd, wtDivOSLevelAdd, rsiDivOBLevel, rsiDivOSLevel, stochLen, stochRsiLen, stochKSmooth, stochDSmooth, amplitude, channelDeviation, enableSoundAlerts);
		}

		public ADITRADYINSANE ADITRADYINSANE(ISeries<double> input, bool showTrend, bool showTramp, bool showSqueeze, bool showBB, bool showWAE, bool showRSI, bool showMFI, bool showVector, bool showDivies, bool showBuySellies, int bgTrans, int theme, int thickWaddah, int threshold, int rsiLength, int rsiOS, int rsiOB, int rsiLowerW, int rsiUpperW, int mfiLength, double iBBThreshold, int rSIThreshold, int rSIDown, int lengthBB, double multBB, int sqTolerance, int adxSqueeze, int adxLen, int diLen, int wLengthBB, double wMultBB, int sensitivity, int fastLength, int slowLength, int channelLength, double multWAE, int wtChannelLen, int wtAverageLen, int wtMALen, int obLevel, int osLevel, int wtDivOBLevel, int wtDivOSLevel, int wtDivOBLevelAdd, int wtDivOSLevelAdd, int rsiDivOBLevel, int rsiDivOSLevel, int stochLen, int stochRsiLen, int stochKSmooth, int stochDSmooth, int amplitude, int channelDeviation, bool enableSoundAlerts)
		{
			if (cacheADITRADYINSANE != null)
				for (int idx = 0; idx < cacheADITRADYINSANE.Length; idx++)
					if (cacheADITRADYINSANE[idx] != null && cacheADITRADYINSANE[idx].ShowTrend == showTrend && cacheADITRADYINSANE[idx].ShowTramp == showTramp && cacheADITRADYINSANE[idx].ShowSqueeze == showSqueeze && cacheADITRADYINSANE[idx].ShowBB == showBB && cacheADITRADYINSANE[idx].ShowWAE == showWAE && cacheADITRADYINSANE[idx].ShowRSI == showRSI && cacheADITRADYINSANE[idx].ShowMFI == showMFI && cacheADITRADYINSANE[idx].ShowVector == showVector && cacheADITRADYINSANE[idx].ShowDivies == showDivies && cacheADITRADYINSANE[idx].ShowBuySellies == showBuySellies && cacheADITRADYINSANE[idx].BgTrans == bgTrans && cacheADITRADYINSANE[idx].Theme == theme && cacheADITRADYINSANE[idx].ThickWaddah == thickWaddah && cacheADITRADYINSANE[idx].Threshold == threshold && cacheADITRADYINSANE[idx].RsiLength == rsiLength && cacheADITRADYINSANE[idx].RsiOS == rsiOS && cacheADITRADYINSANE[idx].RsiOB == rsiOB && cacheADITRADYINSANE[idx].RsiLowerW == rsiLowerW && cacheADITRADYINSANE[idx].RsiUpperW == rsiUpperW && cacheADITRADYINSANE[idx].MfiLength == mfiLength && cacheADITRADYINSANE[idx].IBBThreshold == iBBThreshold && cacheADITRADYINSANE[idx].RSIThreshold == rSIThreshold && cacheADITRADYINSANE[idx].RSIDown == rSIDown && cacheADITRADYINSANE[idx].LengthBB == lengthBB && cacheADITRADYINSANE[idx].MultBB == multBB && cacheADITRADYINSANE[idx].SqTolerance == sqTolerance && cacheADITRADYINSANE[idx].AdxSqueeze == adxSqueeze && cacheADITRADYINSANE[idx].AdxLen == adxLen && cacheADITRADYINSANE[idx].DiLen == diLen && cacheADITRADYINSANE[idx].WLengthBB == wLengthBB && cacheADITRADYINSANE[idx].WMultBB == wMultBB && cacheADITRADYINSANE[idx].Sensitivity == sensitivity && cacheADITRADYINSANE[idx].FastLength == fastLength && cacheADITRADYINSANE[idx].SlowLength == slowLength && cacheADITRADYINSANE[idx].ChannelLength == channelLength && cacheADITRADYINSANE[idx].MultWAE == multWAE && cacheADITRADYINSANE[idx].WtChannelLen == wtChannelLen && cacheADITRADYINSANE[idx].WtAverageLen == wtAverageLen && cacheADITRADYINSANE[idx].WtMALen == wtMALen && cacheADITRADYINSANE[idx].ObLevel == obLevel && cacheADITRADYINSANE[idx].OsLevel == osLevel && cacheADITRADYINSANE[idx].WtDivOBLevel == wtDivOBLevel && cacheADITRADYINSANE[idx].WtDivOSLevel == wtDivOSLevel && cacheADITRADYINSANE[idx].WtDivOBLevelAdd == wtDivOBLevelAdd && cacheADITRADYINSANE[idx].WtDivOSLevelAdd == wtDivOSLevelAdd && cacheADITRADYINSANE[idx].RsiDivOBLevel == rsiDivOBLevel && cacheADITRADYINSANE[idx].RsiDivOSLevel == rsiDivOSLevel && cacheADITRADYINSANE[idx].StochLen == stochLen && cacheADITRADYINSANE[idx].StochRsiLen == stochRsiLen && cacheADITRADYINSANE[idx].StochKSmooth == stochKSmooth && cacheADITRADYINSANE[idx].StochDSmooth == stochDSmooth && cacheADITRADYINSANE[idx].Amplitude == amplitude && cacheADITRADYINSANE[idx].ChannelDeviation == channelDeviation && cacheADITRADYINSANE[idx].EnableSoundAlerts == enableSoundAlerts && cacheADITRADYINSANE[idx].EqualsInput(input))
						return cacheADITRADYINSANE[idx];
			return CacheIndicator<ADITRADYINSANE>(new ADITRADYINSANE(){ ShowTrend = showTrend, ShowTramp = showTramp, ShowSqueeze = showSqueeze, ShowBB = showBB, ShowWAE = showWAE, ShowRSI = showRSI, ShowMFI = showMFI, ShowVector = showVector, ShowDivies = showDivies, ShowBuySellies = showBuySellies, BgTrans = bgTrans, Theme = theme, ThickWaddah = thickWaddah, Threshold = threshold, RsiLength = rsiLength, RsiOS = rsiOS, RsiOB = rsiOB, RsiLowerW = rsiLowerW, RsiUpperW = rsiUpperW, MfiLength = mfiLength, IBBThreshold = iBBThreshold, RSIThreshold = rSIThreshold, RSIDown = rSIDown, LengthBB = lengthBB, MultBB = multBB, SqTolerance = sqTolerance, AdxSqueeze = adxSqueeze, AdxLen = adxLen, DiLen = diLen, WLengthBB = wLengthBB, WMultBB = wMultBB, Sensitivity = sensitivity, FastLength = fastLength, SlowLength = slowLength, ChannelLength = channelLength, MultWAE = multWAE, WtChannelLen = wtChannelLen, WtAverageLen = wtAverageLen, WtMALen = wtMALen, ObLevel = obLevel, OsLevel = osLevel, WtDivOBLevel = wtDivOBLevel, WtDivOSLevel = wtDivOSLevel, WtDivOBLevelAdd = wtDivOBLevelAdd, WtDivOSLevelAdd = wtDivOSLevelAdd, RsiDivOBLevel = rsiDivOBLevel, RsiDivOSLevel = rsiDivOSLevel, StochLen = stochLen, StochRsiLen = stochRsiLen, StochKSmooth = stochKSmooth, StochDSmooth = stochDSmooth, Amplitude = amplitude, ChannelDeviation = channelDeviation, EnableSoundAlerts = enableSoundAlerts }, input, ref cacheADITRADYINSANE);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ADITRADYINSANE ADITRADYINSANE(bool showTrend, bool showTramp, bool showSqueeze, bool showBB, bool showWAE, bool showRSI, bool showMFI, bool showVector, bool showDivies, bool showBuySellies, int bgTrans, int theme, int thickWaddah, int threshold, int rsiLength, int rsiOS, int rsiOB, int rsiLowerW, int rsiUpperW, int mfiLength, double iBBThreshold, int rSIThreshold, int rSIDown, int lengthBB, double multBB, int sqTolerance, int adxSqueeze, int adxLen, int diLen, int wLengthBB, double wMultBB, int sensitivity, int fastLength, int slowLength, int channelLength, double multWAE, int wtChannelLen, int wtAverageLen, int wtMALen, int obLevel, int osLevel, int wtDivOBLevel, int wtDivOSLevel, int wtDivOBLevelAdd, int wtDivOSLevelAdd, int rsiDivOBLevel, int rsiDivOSLevel, int stochLen, int stochRsiLen, int stochKSmooth, int stochDSmooth, int amplitude, int channelDeviation, bool enableSoundAlerts)
		{
			return indicator.ADITRADYINSANE(Input, showTrend, showTramp, showSqueeze, showBB, showWAE, showRSI, showMFI, showVector, showDivies, showBuySellies, bgTrans, theme, thickWaddah, threshold, rsiLength, rsiOS, rsiOB, rsiLowerW, rsiUpperW, mfiLength, iBBThreshold, rSIThreshold, rSIDown, lengthBB, multBB, sqTolerance, adxSqueeze, adxLen, diLen, wLengthBB, wMultBB, sensitivity, fastLength, slowLength, channelLength, multWAE, wtChannelLen, wtAverageLen, wtMALen, obLevel, osLevel, wtDivOBLevel, wtDivOSLevel, wtDivOBLevelAdd, wtDivOSLevelAdd, rsiDivOBLevel, rsiDivOSLevel, stochLen, stochRsiLen, stochKSmooth, stochDSmooth, amplitude, channelDeviation, enableSoundAlerts);
		}

		public Indicators.ADITRADYINSANE ADITRADYINSANE(ISeries<double> input , bool showTrend, bool showTramp, bool showSqueeze, bool showBB, bool showWAE, bool showRSI, bool showMFI, bool showVector, bool showDivies, bool showBuySellies, int bgTrans, int theme, int thickWaddah, int threshold, int rsiLength, int rsiOS, int rsiOB, int rsiLowerW, int rsiUpperW, int mfiLength, double iBBThreshold, int rSIThreshold, int rSIDown, int lengthBB, double multBB, int sqTolerance, int adxSqueeze, int adxLen, int diLen, int wLengthBB, double wMultBB, int sensitivity, int fastLength, int slowLength, int channelLength, double multWAE, int wtChannelLen, int wtAverageLen, int wtMALen, int obLevel, int osLevel, int wtDivOBLevel, int wtDivOSLevel, int wtDivOBLevelAdd, int wtDivOSLevelAdd, int rsiDivOBLevel, int rsiDivOSLevel, int stochLen, int stochRsiLen, int stochKSmooth, int stochDSmooth, int amplitude, int channelDeviation, bool enableSoundAlerts)
		{
			return indicator.ADITRADYINSANE(input, showTrend, showTramp, showSqueeze, showBB, showWAE, showRSI, showMFI, showVector, showDivies, showBuySellies, bgTrans, theme, thickWaddah, threshold, rsiLength, rsiOS, rsiOB, rsiLowerW, rsiUpperW, mfiLength, iBBThreshold, rSIThreshold, rSIDown, lengthBB, multBB, sqTolerance, adxSqueeze, adxLen, diLen, wLengthBB, wMultBB, sensitivity, fastLength, slowLength, channelLength, multWAE, wtChannelLen, wtAverageLen, wtMALen, obLevel, osLevel, wtDivOBLevel, wtDivOSLevel, wtDivOBLevelAdd, wtDivOSLevelAdd, rsiDivOBLevel, rsiDivOSLevel, stochLen, stochRsiLen, stochKSmooth, stochDSmooth, amplitude, channelDeviation, enableSoundAlerts);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ADITRADYINSANE ADITRADYINSANE(bool showTrend, bool showTramp, bool showSqueeze, bool showBB, bool showWAE, bool showRSI, bool showMFI, bool showVector, bool showDivies, bool showBuySellies, int bgTrans, int theme, int thickWaddah, int threshold, int rsiLength, int rsiOS, int rsiOB, int rsiLowerW, int rsiUpperW, int mfiLength, double iBBThreshold, int rSIThreshold, int rSIDown, int lengthBB, double multBB, int sqTolerance, int adxSqueeze, int adxLen, int diLen, int wLengthBB, double wMultBB, int sensitivity, int fastLength, int slowLength, int channelLength, double multWAE, int wtChannelLen, int wtAverageLen, int wtMALen, int obLevel, int osLevel, int wtDivOBLevel, int wtDivOSLevel, int wtDivOBLevelAdd, int wtDivOSLevelAdd, int rsiDivOBLevel, int rsiDivOSLevel, int stochLen, int stochRsiLen, int stochKSmooth, int stochDSmooth, int amplitude, int channelDeviation, bool enableSoundAlerts)
		{
			return indicator.ADITRADYINSANE(Input, showTrend, showTramp, showSqueeze, showBB, showWAE, showRSI, showMFI, showVector, showDivies, showBuySellies, bgTrans, theme, thickWaddah, threshold, rsiLength, rsiOS, rsiOB, rsiLowerW, rsiUpperW, mfiLength, iBBThreshold, rSIThreshold, rSIDown, lengthBB, multBB, sqTolerance, adxSqueeze, adxLen, diLen, wLengthBB, wMultBB, sensitivity, fastLength, slowLength, channelLength, multWAE, wtChannelLen, wtAverageLen, wtMALen, obLevel, osLevel, wtDivOBLevel, wtDivOSLevel, wtDivOBLevelAdd, wtDivOSLevelAdd, rsiDivOBLevel, rsiDivOSLevel, stochLen, stochRsiLen, stochKSmooth, stochDSmooth, amplitude, channelDeviation, enableSoundAlerts);
		}

		public Indicators.ADITRADYINSANE ADITRADYINSANE(ISeries<double> input , bool showTrend, bool showTramp, bool showSqueeze, bool showBB, bool showWAE, bool showRSI, bool showMFI, bool showVector, bool showDivies, bool showBuySellies, int bgTrans, int theme, int thickWaddah, int threshold, int rsiLength, int rsiOS, int rsiOB, int rsiLowerW, int rsiUpperW, int mfiLength, double iBBThreshold, int rSIThreshold, int rSIDown, int lengthBB, double multBB, int sqTolerance, int adxSqueeze, int adxLen, int diLen, int wLengthBB, double wMultBB, int sensitivity, int fastLength, int slowLength, int channelLength, double multWAE, int wtChannelLen, int wtAverageLen, int wtMALen, int obLevel, int osLevel, int wtDivOBLevel, int wtDivOSLevel, int wtDivOBLevelAdd, int wtDivOSLevelAdd, int rsiDivOBLevel, int rsiDivOSLevel, int stochLen, int stochRsiLen, int stochKSmooth, int stochDSmooth, int amplitude, int channelDeviation, bool enableSoundAlerts)
		{
			return indicator.ADITRADYINSANE(input, showTrend, showTramp, showSqueeze, showBB, showWAE, showRSI, showMFI, showVector, showDivies, showBuySellies, bgTrans, theme, thickWaddah, threshold, rsiLength, rsiOS, rsiOB, rsiLowerW, rsiUpperW, mfiLength, iBBThreshold, rSIThreshold, rSIDown, lengthBB, multBB, sqTolerance, adxSqueeze, adxLen, diLen, wLengthBB, wMultBB, sensitivity, fastLength, slowLength, channelLength, multWAE, wtChannelLen, wtAverageLen, wtMALen, obLevel, osLevel, wtDivOBLevel, wtDivOSLevel, wtDivOBLevelAdd, wtDivOSLevelAdd, rsiDivOBLevel, rsiDivOSLevel, stochLen, stochRsiLen, stochKSmooth, stochDSmooth, amplitude, channelDeviation, enableSoundAlerts);
		}
	}
}

#endregion
