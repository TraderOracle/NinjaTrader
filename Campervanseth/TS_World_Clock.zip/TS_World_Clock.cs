#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private TSWorldClock[] cacheTSWorldClock;

		
		public TSWorldClock TSWorldClock()
		{
			return TSWorldClock(Input);
		}


		
		public TSWorldClock TSWorldClock(ISeries<double> input)
		{
			if (cacheTSWorldClock != null)
				for (int idx = 0; idx < cacheTSWorldClock.Length; idx++)
					if ( cacheTSWorldClock[idx].EqualsInput(input))
						return cacheTSWorldClock[idx];
			return CacheIndicator<TSWorldClock>(new TSWorldClock(), input, ref cacheTSWorldClock);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.TSWorldClock TSWorldClock()
		{
			return indicator.TSWorldClock(Input);
		}


		
		public Indicators.TSWorldClock TSWorldClock(ISeries<double> input )
		{
			return indicator.TSWorldClock(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.TSWorldClock TSWorldClock()
		{
			return indicator.TSWorldClock(Input);
		}


		
		public Indicators.TSWorldClock TSWorldClock(ISeries<double> input )
		{
			return indicator.TSWorldClock(input);
		}

	}
}

#endregion
